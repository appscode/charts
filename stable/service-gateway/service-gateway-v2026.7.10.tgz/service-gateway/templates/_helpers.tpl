{{/*
Expand the name of the chart.
*/}}
{{- define "service-gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "service-gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "service-gateway.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "service-gateway.labels" -}}
helm.sh/chart: {{ include "service-gateway.chart" . }}
{{ include "service-gateway.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "service-gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "service-gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
The name of the tenant.
*/}}
{{- define "tenant.name" -}}
{{- ternary (trimSuffix "-gw" .Release.Namespace) .Release.Namespace (hasSuffix "-gw" .Release.Namespace) }}
{{- end }}

{{/*
The domain name used for the gateway.
<clusterName>.<orgName / "ace">.<domain>
*/}}
{{- define "gateway.domain" -}}
{{- if eq (dig "mode" "" (.Values.gatewayClass.annotations | default dict)) "hosted" -}}
{{- .Values.infra.host -}}
{{- else -}}
{{- $ns := trimSuffix "-gw" .Release.Namespace -}}
{{- $useClusterName := or (eq $ns "ace") (eq .Values.infra.tenantSpreadPolicy "multi") -}}
{{- $prefix := ternary (printf "%s.%s" .Values.clusterMetadata.name $ns) $ns $useClusterName -}}
{{- printf "%s.%s" $prefix .Values.infra.host -}}
{{- end -}}
{{- end }}

{{/*
Returns whether the OpenShift distribution is used
*/}}
{{- define "distro.openshift" -}}
{{- or (.Capabilities.APIVersions.Has "project.openshift.io/v1/Project") .Values.global.distro.openshift (and .Values.distro .Values.distro.openshift) -}}
{{- end }}

{{/*
Returns if ubi images are to be used
*/}}
{{- define "operator.ubi" -}}
{{ ternary "-ubi" "" (list "operator" "all" | has (default (dig "ubi" "" (default dict .Values.distro)) .Values.global.distro.ubi)) }}
{{- end }}
