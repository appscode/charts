# Stash Metrics

[Stash Metrics](https://github.com/stashed) - Stash State Metrics

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/stash-metrics --version=v2025.10.17
$ helm upgrade -i stash-metrics appscode/stash-metrics -n stash --create-namespace --version=v2025.10.17
```

## Introduction

This chart deploys Stash metrics configurations on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.16+

## Installing the Chart

To install/upgrade the chart with the release name `stash-metrics`:

```bash
$ helm upgrade -i stash-metrics appscode/stash-metrics -n stash --create-namespace --version=v2025.10.17
```

The command deploys Stash metrics configurations on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `stash-metrics`:

```bash
$ helm uninstall stash-metrics -n stash
```

The command removes all the Kubernetes components associated with the chart and deletes the release.


