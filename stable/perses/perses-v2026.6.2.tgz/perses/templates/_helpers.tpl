{{/*
Expand the name of the chart.
*/}}
{{- define "perses.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "perses.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "perses.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "perses.labels" -}}
helm.sh/chart: {{ include "perses.chart" . }}
{{ include "perses.selectorLabels" . }}
app.kubernetes.io/version: {{ default .Chart.AppVersion .Values.image.version }}
app.kubernetes.io/part-of: {{ include "perses.name" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if not (empty .Values.additionalLabels) }}
{{ toYaml .Values.additionalLabels }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "perses.selectorLabels" -}}
app.kubernetes.io/name: {{ include "perses.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "perses.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "perses.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "perses.dns" -}}
http://{{ include "perses.fullname" . }}.{{ .Release.Namespace }}.svc.cluster.local:{{ .Values.service.targetPort }}
{{- end -}}

{{/*
Returns whether the OpenShift distribution is used
*/}}
{{- define "distro.openshift" -}}
{{- or (.Capabilities.APIVersions.Has "project.openshift.io/v1/Project") .Values.distro.openshift -}}
{{- end }}

{{- define "perses.dbHost" -}}
{{- (splitList ":" .Values.config.database.sql.addr) | first -}}
{{- end }}

{{- define "perses.dbPort" -}}
{{- $parts := splitList ":" .Values.config.database.sql.addr -}}
{{- if gt (len $parts) 1 }}{{ last $parts }}{{ else }}5432{{ end -}}
{{- end }}
