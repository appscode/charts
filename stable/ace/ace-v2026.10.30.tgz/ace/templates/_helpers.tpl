{{/*
Expand the name of the chart.
*/}}
{{- define "ace.name" -}}
{{- default .Chart.Name .Values.global.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ace.fullname" -}}
{{- if .Values.global.fullnameOverride }}
{{- .Values.global.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.global.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ace.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ace.labels" -}}
helm.sh/chart: {{ include "ace.chart" . }}
{{ include "ace.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ace.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ace.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Offshoot labels
*/}}
{{- define "ace.offshootLabels" -}}
helm.sh/chart: {{ include "ace.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "appscode.serviceAccountName" -}}
{{- if .Values.global.serviceAccount.create }}
{{- default (include "ace.fullname" .) .Values.global.serviceAccount.name }}
{{- else if .Values.serviceAccount }}
{{- default "default" .Values.serviceAccount.name }}
{{- else }}
{{- "default" }}
{{- end }}
{{- end }}

{{/*
Returns the appscode license
*/}}
{{- define "appscode.license" -}}
{{- default .Values.global.license .Values.license }}
{{- end }}

{{/*
Returns the registry used for app docker image
*/}}
{{- define "image.registry" -}}
{{- list .Values.global.registryFQDN (default .Values.image.registry .Values.global.registry) | compact | join "/" }}
{{- end }}

{{/*
Returns the registry used for kubectl docker image
*/}}
{{- define "kubectl.registry" -}}
{{- list .Values.global.registryFQDN (default .Values.kubectl.registry .Values.global.registry) | compact | join "/" }}
{{- end }}

{{- define "geoipdb.registry" -}}
{{- list .Values.global.registryFQDN (default .Values.geoipdb.registry .Values.global.registry) | compact | join "/" }}
{{- end }}

{{- define "gotenberg.registry" -}}
{{- list .Values.global.registryFQDN (default .Values.gotenberg.registry .Values.global.registry) | compact | join "/" }}
{{- end }}

{{/*
Returns the appscode image pull secrets
*/}}
{{- define "appscode.imagePullSecrets" -}}
{{- with .Values.global.imagePullSecrets -}}
imagePullSecrets:
{{- toYaml . | nindent 2 }}
{{- else -}}
imagePullSecrets:
{{- toYaml $.Values.imagePullSecrets | nindent 2 }}
{{- end }}
{{- end }}

{{/*
Returns the enabled monitoring agent name
*/}}
{{- define "monitoring.agent" -}}
{{- .Values.global.monitoring.agent -}}
{{- end }}

{{/*
Returns whether the ServiceMonitor will be labeled with custom label
*/}}
{{- define "monitoring.apply-servicemonitor-label" -}}
{{- ternary "false" "true" (empty .Values.global.monitoring.serviceMonitor.labels) -}}
{{- end }}

{{/*
Returns the ServiceMonitor labels
*/}}
{{- define "monitoring.servicemonitor-label" -}}
{{- range $key, $val := .Values.global.monitoring.serviceMonitor.labels }}
{{ $key }}: {{ $val }}
{{- end }}
{{- end }}

{{- define "settings.platformConfigSecretName" -}}
{{- printf "%s-config" (include "ace.fullname" .) -}}
{{- end }}

{{- define "settings.platformUserConfigSecretName" -}}
{{- printf "%s-user-config" (include "ace.fullname" .) -}}
{{- end }}

{{- define "settings.platformSystemConfigSecretName" -}}
{{- printf "%s-system-config" (include "ace.fullname" .) -}}
{{- end }}


{{- define "settings.grafanaConfigSecretName" -}}
{{- printf "%s-grafana-config" (include "ace.fullname" .) -}}
{{- end }}

{{- define "settings.objstoreSecretName" -}}
{{- if not (.Values.global.infra.objstore.enableCredLess) }}
{{- printf "%s-objstore-cred" (include "ace.fullname" .) -}}
{{- end }}
{{- end }}

{{- define "settings.natsSecretName" -}}
{{- printf "%s-nats-cred" (include "ace.fullname" .) -}}
{{- end }}

{{- define "settings.natsMountPath" -}}
{{- .Values.settings.nats.mountPath }}
{{- end }}

{{/*
Determine database host name
*/}}
{{- define "settings.database.host" -}}
{{- if .Values.settings.pgpool.enabled -}}
{{- printf "%s-pgpool.%s.svc:9999" (include "ace.fullname" .) .Release.Namespace -}}
{{- else -}}
{{- printf "%s-db.%s.svc:5432" (include "ace.fullname" .) .Release.Namespace -}}
{{- end -}}
{{- end -}}

{{- define  "settings.oauth2JWTSecret" -}}
{{ .Values.settings.security.oauth2JWTSecret | default (randAlphaNum 43) }}
{{- end -}}

{{- define  "settings.csrfSecretkey" -}}
{{ .Values.settings.security.csrfSecretKey | default (randAlphaNum 64) }}
{{- end -}}

{{- define "settings.cache.host" -}}
{{- printf "network=tcp,addr=%s-cache.%s.svc:6379,password='%s',db=1,pool_size=100,idle_timeout=180,prefix=cache-" (include "ace.fullname" .) .Release.Namespace .Values.settings.cache.auth.password -}}
{{- end -}}

{{- define "settings.session.host" -}}
{{- printf "network=tcp,addr=%s-cache.%s.svc:6379,password='%s',db=0,pool_size=100,idle_timeout=180,prefix=session-" (include "ace.fullname" .) .Release.Namespace .Values.settings.cache.auth.password -}}
{{- end -}}


{{- define "grafana.cache.host" -}}
{{- printf "addr=%s-cache.%s.svc:6379,password='%s',db=1,pool_size=100" (include "ace.fullname" .) .Release.Namespace .Values.settings.cache.auth.password -}}
{{- end -}}

{{- define "grafana.session.host" -}}
{{- printf "addr=%s-cache.%s.svc:6379,password='%s',db=0,pool_size=100" (include "ace.fullname" .) .Release.Namespace .Values.settings.cache.auth.password -}}
{{- end -}}

{{- define  "settings.kms.masterKeyURL" -}}
{{- if .Values.global.infra.kms.masterKeyURL -}}
{{- .Values.global.infra.kms.masterKeyURL -}}
{{- else -}}
{{- printf "base64key://%s" (randAlphaNum 64) -}}
{{- end -}}
{{- end -}}

{{/*
Replicates "cadence.fullname" of the cadence chart, so that the ace chart can
refer to the resources created by the cadence chart.
*/}}
{{- define "ace.cadenceFullname" -}}
{{- if .Values.cadence.fullnameOverride -}}
{{- .Values.cadence.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default "cadence" .Values.cadence.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Determine cadence frontend host name
*/}}
{{- define "settings.cadence.host" -}}
{{- .Values.settings.cadence.host | default (printf "%s-frontend.%s.svc" (include "ace.cadenceFullname" .) .Release.Namespace) -}}
{{- end -}}

{{/*
Overrides "cadence.databaseSecrets" of the cadence chart (the parent chart's
definition wins), so that the cadence chart does not create its
<cadence fullname>-<service>-secrets from config.persistence.database.sql.password.
templates/cadence/cadence-db-secret.yaml creates them from settings.db.auth.password.
*/}}
{{- define "cadence.databaseSecrets" -}}
{{- $_ := set . "databaseSecrets" list -}}
{{- end -}}

{{/*
Gateway-native FQDN for the ace deployment.
Only used during the ingress→gateway migration window so
phase-2 testers can hit the gateway directly while ingress still owns the main host.
*/}}
{{- define "ace.gateway.fqdn" -}}
{{- printf "ace.ace.%s" .Values.global.platform.host -}}
{{- end }}

{{/*
True iff both ingress and gateway are enabled — i.e. the chart is rendered for
ingress→gateway migration phase 2. Used to gate the inclusion of the gateway-native
FQDN in cert SANs and HTTPRoute hostnames; new gateway-only deployments and
ingress-only deployments do not need it.
*/}}
{{- define "ace.gateway.migrationActive" -}}
{{- and (index .Values "ingress-nginx" "enabled") (index .Values "gateway" "enabled") -}}
{{- end }}

{{/*
Returns whether the OpenShift distribution is used
*/}}
{{- define "distro.openshift" -}}
{{- or (.Capabilities.APIVersions.Has "project.openshift.io/v1/Project") .Values.global.distro.openshift (and .Values.distro .Values.distro.openshift) -}}
{{- end }}

{{/*
Returns if ubi images are to be used
*/}}
{{- define "operator.ubi" -}}
{{ ternary "-ubi" "" (list "operator" "all" | has (default (dig "ubi" "" (default dict .Values.distro)) .Values.global.distro.ubi)) }}
{{- end }}

{{/*
Gateway API kinds are served at different versions depending on which CRD bundle the cluster
vendor ships (v1.3–v1.7, standard or experimental), and some vendors (OpenShift) omit them.
Returns the first of .versions the cluster serves for .kind, or "" when the kind is absent.
*/}}
{{- define "gatewayAPI.servedVersion" -}}
{{- $ctx := .ctx -}}
{{- $kind := .kind -}}
{{- range .versions -}}
{{- if $ctx.Capabilities.APIVersions.Has (printf "gateway.networking.k8s.io/%s/%s" . $kind) -}}
{{- . -}}
{{- break -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "gatewayAPI.tcpRouteVersion" -}}
{{- include "gatewayAPI.servedVersion" (dict "ctx" . "kind" "TCPRoute" "versions" (list "v1" "v1alpha2")) -}}
{{- end -}}

{{- define "gatewayAPI.backendTLSPolicyVersion" -}}
{{- include "gatewayAPI.servedVersion" (dict "ctx" . "kind" "BackendTLSPolicy" "versions" (list "v1" "v1alpha3")) -}}
{{- end -}}
