{{/*
Expand the name of the chart.
*/}}
{{- define "cloud-platform.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cloud-platform.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Primary backend workload/service name.
*/}}
{{- define "cloud-platform.backendName" -}}
{{- default (include "cloud-platform.fullname" .) .Values.backend.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Backend headless service name used by the StatefulSet.
*/}}
{{- define "cloud-platform.backendHeadlessName" -}}
{{- default (printf "%s-headless" (include "cloud-platform.backendName" .)) .Values.backend.headlessServiceName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
UI workload/service name.
*/}}
{{- define "cloud-platform.uiName" -}}
{{- default (printf "%s-ui" (include "cloud-platform.fullname" .)) .Values.ui.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Worker workload name.
*/}}
{{- define "cloud-platform.workerName" -}}
{{- default (printf "%s-worker" (include "cloud-platform.fullname" .)) .Values.worker.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Compatibility alias used by installer patterns.
*/}}
{{- define "ace.fullname" -}}
{{- include "cloud-platform.fullname" . -}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cloud-platform.labels" -}}
helm.sh/chart: {{ include "cloud-platform.chart" . }}
{{ include "cloud-platform.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "ace.labels" -}}
{{- include "cloud-platform.labels" . -}}
{{- end }}

{{- define "ace.offshootLabels" -}}
{{- include "cloud-platform.labels" . -}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cloud-platform.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cloud-platform.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Chart label
*/}}
{{- define "cloud-platform.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
KubeDB Postgres service hostname (FQDN) used by cadence and the backend.
*/}}
{{- define "cloud-platform.dbHost" -}}
{{- printf "%s-db.%s.svc.cluster.local" (include "cloud-platform.fullname" .) .Release.Namespace -}}
{{- end }}

{{/*
HTTP scheme — "https" when gateway.tls.enabled, otherwise "http".
*/}}
{{- define "cloud-platform.scheme" -}}
{{- if .Values.gateway.tls.enabled -}}https{{- else -}}http{{- end -}}
{{- end }}

{{/*
Public base URL — single source of truth for all public-facing URLs.
Derived from gateway.hostname + TLS flag.  Result: http(s)://<hostname>
*/}}
{{- define "cloud-platform.publicBaseURL" -}}
{{- printf "%s://%s" (include "cloud-platform.scheme" .) (.Values.gateway.hostname | default "localhost") -}}
{{- end }}

{{/*
Whether gateway.hostname is a bare IPv4 address (vs a DNS name).
Browsers do NOT send TLS SNI when connecting to a bare IP, so an HTTPS
listener that pins `hostname` to an IP will never match — callers must omit
the listener hostname in that case. Returns the string "true" or "false".
*/}}
{{- define "cloud-platform.isIPHostname" -}}
{{- if regexMatch "^([0-9]{1,3}\\.){3}[0-9]{1,3}$" (.Values.gateway.hostname | default "") -}}true{{- else -}}false{{- end -}}
{{- end }}

{{- define "distro.openshift" -}}
{{- if .Capabilities.APIVersions.Has "security.openshift.io/v1" -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}



{{- /*
  Replicates the cadence subchart's "cadence.fullname" so we can build the exact
  Secret names its pods reference (cadence-<svc>-secrets). Keep in sync with the
  subchart's _helpers.tpl. The subchart uses its own .Chart.Name ("cadence").
*/ -}}
{{- define "cloud-platform.cadenceFullname" -}}
{{- $cv := .Values.cadence | default dict -}}
{{- if $cv.fullnameOverride -}}
{{- $cv.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := $cv.nameOverride | default "cadence" -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- /*
  OVERRIDE of the cadence subchart's "cadence.databaseSecrets" (named templates
  are global; the parent definition wins). We blank it so the subchart bakes NO
  POSTGRES_PWD and creates NO cadence-<svc>-secrets. Those secrets are instead
  rendered by templates/cadence/cadence-db-secret.yaml from the shared
  settings.db.auth.password, which the subchart itself cannot read.
*/ -}}
{{- define "cadence.databaseSecrets" -}}
{{- $_ := set . "databaseSecrets" list -}}
{{- end -}}

{{/*
Resolve one component's SMTP settings against the shared relay.

Call with a dict of the shared block and the component's own override:

    {{- $smtp := include "cloud-platform.smtp" (dict
          "shared"   (((.Values.global | default dict).settings | default dict).smtp)
          "override" .Values.casdoor.providers.email) | fromYaml }}
    host: {{ $smtp.host | quote }}

Two components need a relay — casdoor for signup and password-reset codes, the
backend for organization invitations — and in almost every deployment it is the
same relay. Configuring it twice invites the failure where one of them is updated
and the other keeps mailing through a decommissioned host, which shows up as
"invitations stopped arriving" long after the change that caused it.

So global.settings.smtp is the one an operator sets, and each component's own block
overrides it FIELD BY FIELD rather than wholesale: a deployment that only needs a
different sender for invitations sets that one key and inherits host, port and
credentials. An empty string in an override means "not set", so it falls back —
which is why an operator who wants a component to send as nobody has to change
the shared value rather than blank the override.

Both levels of the shared path are guarded with `| default dict` rather than
written as `.Values.global.settings.smtp`, so a values file that sets `global` or
`global.settings` to null yields an empty dict here instead of a nil-pointer
error at render time. (`dig` cannot be used for this: it wants a
map[string]interface{} and .Values is a chartutil.Values.)

Note that Helm merges `global` into every subchart's values, so the relay
credentials here are also visible to the gateway, cadence and cert-manager
subcharts. Supply the password with --set or from a secrets manager rather than
committing it to a values file.
*/}}
{{- define "cloud-platform.smtp" -}}
{{- $shared := .shared | default dict -}}
{{- $own := .override | default dict -}}
host: {{ $own.host | default $shared.host | default "" | quote }}
port: {{ $own.port | default $shared.port | default "587" | toString | quote }}
username: {{ $own.username | default $shared.username | default "" | quote }}
password: {{ $own.password | default $shared.password | default "" | quote }}
from: {{ $own.from | default $shared.from | default $own.username | default $shared.username | default "" | quote }}
{{- end }}

