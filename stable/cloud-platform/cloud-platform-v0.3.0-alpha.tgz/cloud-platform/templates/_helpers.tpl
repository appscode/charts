{{/*
Expand the name of the chart.
*/}}
{{- define "cloud-platform.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cloud-platform.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Primary backend workload/service name.
*/}}
{{- define "cloud-platform.backendName" -}}
{{- default (include "cloud-platform.fullname" .) .Values.backend.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Backend headless service name used by the StatefulSet.
*/}}
{{- define "cloud-platform.backendHeadlessName" -}}
{{- default (printf "%s-headless" (include "cloud-platform.backendName" .)) .Values.backend.headlessServiceName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
UI workload/service name.
*/}}
{{- define "cloud-platform.uiName" -}}
{{- default (printf "%s-ui" (include "cloud-platform.fullname" .)) .Values.ui.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Worker workload name.
*/}}
{{- define "cloud-platform.workerName" -}}
{{- default (printf "%s-worker" (include "cloud-platform.fullname" .)) .Values.worker.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Compatibility alias used by installer patterns.
*/}}
{{- define "ace.fullname" -}}
{{- include "cloud-platform.fullname" . -}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cloud-platform.labels" -}}
helm.sh/chart: {{ include "cloud-platform.chart" . }}
{{ include "cloud-platform.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "ace.labels" -}}
{{- include "cloud-platform.labels" . -}}
{{- end }}

{{- define "ace.offshootLabels" -}}
{{- include "cloud-platform.labels" . -}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cloud-platform.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cloud-platform.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Chart label
*/}}
{{- define "cloud-platform.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
KubeDB Postgres service hostname (FQDN) used by cadence and the backend.
*/}}
{{- define "cloud-platform.dbHost" -}}
{{- printf "%s-db.%s.svc.cluster.local" (include "cloud-platform.fullname" .) .Release.Namespace -}}
{{- end }}

{{/*
HTTP scheme — "https" when gateway.tls.enabled, otherwise "http".
*/}}
{{- define "cloud-platform.scheme" -}}
{{- if .Values.gateway.tls.enabled -}}https{{- else -}}http{{- end -}}
{{- end }}

{{/*
Public base URL — single source of truth for all public-facing URLs.
Derived from gateway.hostname + TLS flag.  Result: http(s)://<hostname>
*/}}
{{- define "cloud-platform.publicBaseURL" -}}
{{- printf "%s://%s" (include "cloud-platform.scheme" .) (.Values.gateway.hostname | default "localhost") -}}
{{- end }}

{{/*
Whether gateway.hostname is a bare IPv4 address (vs a DNS name).
Browsers do NOT send TLS SNI when connecting to a bare IP, so an HTTPS
listener that pins `hostname` to an IP will never match — callers must omit
the listener hostname in that case. Returns the string "true" or "false".
*/}}
{{- define "cloud-platform.isIPHostname" -}}
{{- if regexMatch "^([0-9]{1,3}\\.){3}[0-9]{1,3}$" (.Values.gateway.hostname | default "") -}}true{{- else -}}false{{- end -}}
{{- end }}

{{/*
Resolve the Redis this release connects to, and refuse to render without one.

    {{- $redis := include "cloud-platform.redis" . | fromYaml }}

Redis is REQUIRED from v0.3.0: the backend refuses to start without a reachable
Redis. So there is no "enabled" switch, and exactly one of two sources always
applies:

  external  settings.cache.external.addr is set. The KubeDB Redis and its auth
            Secret are not rendered; the backend and the wait-for-redis init
            containers point at the operator's Redis.
  kubedb    otherwise. The chart renders a KubeDB Redis from settings.cache.

The guards are the Redis counterpart of the SMTP ones in config-secret.yaml.
They live here, not there, because five templates consume this helper and Helm
renders templates/cache/ before templates/backend/: a guard in the config Secret
would lose to whatever nil-pointer error a cache template hit first. Every
consumer includes this helper before it reads a settings.cache value, and every
message names the value to set.

TLS is described the way the backend's own config describes it, so the wait
container and the backend connect alike: `verify` is enableHostVerification
(false means "encrypt, do not verify"), and a verified connection needs a CA
bundle that both of them read from the same Secret. The wait image is not the
backend image, so "whatever the system trusts" would not mean the same thing in
the two containers.
*/}}
{{- define "cloud-platform.redis" -}}
{{- $cache := (.Values.settings | default dict).cache | default dict -}}
{{- $ext := $cache.external | default dict -}}
{{- $ref := $ext.passwordSecretRef | default dict -}}
{{- $extTLS := $ext.tls | default dict -}}
{{- $ca := $extTLS.caSecretRef | default dict -}}
{{- $wait := $cache.wait | default dict -}}
{{- $app := ((.Values.backend | default dict).config | default dict).redis | default dict -}}
{{- $addr := $ext.addr | default "" | toString -}}
{{- $external := ne $addr "" -}}
{{- /* A flag may arrive as a string ("false" from --set-string or a quoted value); compare its text. */ -}}
{{- $extTLSEnabled := eq (toString ($extTLS.enabled | default false)) "true" -}}
{{- $host := "" -}}
{{- $port := "" -}}
{{- $db := 1 -}}
{{- $dbKey := "" -}}
{{- $username := "" -}}
{{- $authSecret := "" -}}
{{- $usernameKey := "" -}}
{{- $passwordKey := "password" -}}
{{- $tlsEnabled := false -}}
{{- $tlsVerify := false -}}
{{- $tlsServerName := "" -}}
{{- $caSecret := "" -}}
{{- $caKey := "" -}}
{{- $caFile := "" -}}
{{- if $external -}}
  {{- if not (regexMatch "^(\\[[0-9A-Fa-f:.]+\\]|[A-Za-z0-9._-]+):[0-9]{1,5}$" $addr) -}}
    {{- fail (printf "settings.cache.external.addr must be host:port (for example redis.example.com:6379, or [::1]:6379 for an IPv6 literal), got %q" $addr) -}}
  {{- end -}}
  {{- $port = regexFind "[0-9]+$" $addr -}}
  {{- $host = trimSuffix (printf ":%s" $port) $addr | trimPrefix "[" | trimSuffix "]" -}}
  {{- if and $ext.username (not $ref.name) -}}
    {{- fail "settings.cache.external.passwordSecretRef.name is required when settings.cache.external.username is set: a Redis ACL user cannot authenticate without a password" -}}
  {{- end -}}
  {{- $dbKey = "settings.cache.external.db" -}}
  {{- if not (or (kindIs "invalid" $ext.db) (eq (toString $ext.db) "")) -}}
    {{- $db = $ext.db -}}
  {{- end -}}
  {{- $username = $ext.username | default "" | toString -}}
  {{- $authSecret = $ref.name | default "" | toString -}}
  {{- $passwordKey = $ref.key | default "password" | toString -}}
  {{- $tlsEnabled = $extTLSEnabled -}}
  {{- if and (not $tlsEnabled) (or $extTLS.serverName $ca.name) -}}
    {{- fail "settings.cache.external.tls.enabled must be true when settings.cache.external.tls.serverName or settings.cache.external.tls.caSecretRef.name is set: without it the connection is plain text and those settings are ignored" -}}
  {{- end -}}
  {{- if $tlsEnabled -}}
    {{- $tlsVerify = true -}}
    {{- if not (or (kindIs "invalid" $extTLS.enableHostVerification) (eq (toString $extTLS.enableHostVerification) "")) -}}
      {{- $tlsVerify = eq (toString $extTLS.enableHostVerification) "true" -}}
    {{- end -}}
    {{- if and $tlsVerify (not $ca.name) -}}
      {{- fail "settings.cache.external.tls.caSecretRef.name is required when settings.cache.external.tls.enabled and settings.cache.external.tls.enableHostVerification are true: name a Secret that holds the CA bundle the Redis certificate chains to (kubectl create secret generic <name> --from-file=ca.crt=<bundle.pem>)" -}}
    {{- end -}}
    {{- $tlsServerName = $extTLS.serverName | default "" | toString -}}
    {{- if $ca.name -}}
      {{- $caSecret = $ca.name | toString -}}
      {{- $caKey = $ca.key | default "ca.crt" | toString -}}
      {{- $caFile = printf "/etc/cloud-platform/redis-ca/%s" $caKey -}}
    {{- end -}}
  {{- end -}}
{{- else -}}
  {{- if or $ext.username $ref.name $extTLSEnabled $extTLS.serverName $ca.name -}}
    {{- fail "settings.cache.external.addr is required to use an external Redis: settings.cache.external.username, .passwordSecretRef.name, .tls.enabled, .tls.serverName or .tls.caSecretRef.name is set, but there is no address to connect to. Set settings.cache.external.addr to host:port, or clear those values to use the KubeDB-managed Redis" -}}
  {{- end -}}
  {{- $_ := required "Redis is required and this release has none: keep settings.cache.version to let the chart run a KubeDB-managed Redis (the default), or set settings.cache.external.addr to host:port to use an existing one" $cache.version -}}
  {{- $host = printf "%s-cache.%s.svc.cluster.local" (include "cloud-platform.fullname" .) .Release.Namespace -}}
  {{- $port = "6379" -}}
  {{- $addr = printf "%s:%s" $host $port -}}
  {{- $dbKey = "backend.config.redis.db" -}}
  {{- if not (or (kindIs "invalid" $app.db) (eq (toString $app.db) "")) -}}
    {{- $db = $app.db -}}
  {{- end -}}
  {{- if ($cache.auth | default dict).password -}}
    {{- $authSecret = printf "%s-cache-auth" (include "cloud-platform.fullname" .) -}}
    {{- $usernameKey = "username" -}}
  {{- end -}}
  {{- $tlsEnabled = eq (toString (($app.tls | default dict).enabled | default false)) "true" -}}
{{- end -}}
{{- if or (lt (int $port) 1) (gt (int $port) 65535) -}}
  {{- fail (printf "settings.cache.external.addr must be host:port with a port between 1 and 65535, got %q" $addr) -}}
{{- end -}}
{{- if not (regexMatch "^[0-9]+$" (toString $db)) -}}
  {{- fail (printf "%s must be a Redis database number (0 or a positive integer), got %q" $dbKey (toString $db)) -}}
{{- end -}}
external: {{ $external }}
addr: {{ $addr | quote }}
host: {{ $host | quote }}
port: {{ $port | quote }}
db: {{ $db | toString | quote }}
username: {{ $username | quote }}
authSecret: {{ $authSecret | quote }}
usernameKey: {{ $usernameKey | quote }}
passwordKey: {{ $passwordKey | quote }}
tls:
  enabled: {{ $tlsEnabled }}
  verify: {{ $tlsVerify }}
  serverName: {{ $tlsServerName | quote }}
  caSecret: {{ $caSecret | quote }}
  caKey: {{ $caKey | quote }}
  caFile: {{ $caFile | quote }}
wait:
  image: {{ $wait.image | default "ghcr.io/appscode-images/redis:7.2.4-bookworm" | quote }}
  timeoutSeconds: {{ $wait.timeoutSeconds | default 300 | int | toString | quote }}
{{- end }}

{{/*
REDIS_* environment of a backend container, from the resolved Redis.

The credentials never enter the config Secret: base.yaml carries ${REDIS_USER:-}
and ${REDIS_PASSWORD:-}, single-quoted, and the loader fills them from these
variables. A single-quoted YAML string cannot carry a ' itself, so the
wait-for-redis init container refuses a user or password that holds one.
*/}}
{{- define "cloud-platform.redisEnv" -}}
{{- $redis := include "cloud-platform.redis" . | fromYaml -}}
- name: REDIS_ADDR
  value: {{ $redis.addr | quote }}
- name: REDIS_DB
  value: {{ $redis.db | quote }}
{{- if $redis.authSecret }}
- name: REDIS_USER
  {{- if $redis.usernameKey }}
  valueFrom:
    secretKeyRef:
      name: {{ $redis.authSecret | quote }}
      key: {{ $redis.usernameKey | quote }}
  {{- else }}
  value: {{ $redis.username | quote }}
  {{- end }}
- name: REDIS_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ $redis.authSecret | quote }}
      key: {{ $redis.passwordKey | quote }}
{{- end }}
{{- end }}

{{/*
The wait-for-redis init container, shared by the API StatefulSet and the worker
Deployment.

The backend tries Redis five times at start, two seconds apart, and then exits:
after about 16 seconds when the port refuses the connection, up to about 40 when
nothing answers. That is the backstop; this container is what keeps a first
install, where Redis is still being provisioned, in an init phase instead of a
crash loop — and what turns a Redis that never arrives into one line that says
so.

It connects the way the backend does: same address, database, user, password and
TLS settings. The password reaches redis-cli through REDISCLI_AUTH, from the
Secret, so it is never on a command line, in the pod spec or in the log; the
only thing printed about a failed attempt is redis-cli's own answer, which names
the error and not the credential.

Readiness is the literal answer PONG, not the exit status: redis-cli exits 0 for
an error reply such as NOAUTH.

Before it connects, it refuses a user or password that contains a single quote,
naming which, and exits 1. The backend reads both into its config as
single-quoted YAML (config-secret.yaml), which cannot carry one: without this
check the PING would succeed and the backend would then fail on its config. The
check is tested by common/config/chart_test.go, which runs this script.
*/}}
{{- define "cloud-platform.waitForRedis" -}}
{{- $redis := include "cloud-platform.redis" . | fromYaml -}}
- name: wait-for-redis
  image: {{ $redis.wait.image | quote }}
  command:
    - sh
    - -c
    - |
      set -u
      # The backend reads the user and the password into its config as
      # single-quoted YAML, which cannot carry a single quote.
      case "${REDIS_USERNAME:-}" in *\'*)
        echo "ERROR: the Redis username contains a single quote ('), which the backend's config cannot carry." >&2
        echo "Use a username without one (settings.cache.external.username)." >&2
        exit 1;;
      esac
      case "${REDISCLI_AUTH:-}" in *\'*)
        echo "ERROR: the Redis password contains a single quote ('), which the backend's config cannot carry." >&2
        echo "Use a password without one (the Secret that settings.cache.external.passwordSecretRef names)." >&2
        exit 1;;
      esac
      set -- -h "$REDIS_HOST" -p "$REDIS_PORT" -n "$REDIS_DB"
      if [ -n "${REDIS_USERNAME:-}" ]; then set -- "$@" --user "$REDIS_USERNAME"; fi
      if [ "${REDIS_TLS:-false}" = "true" ]; then
        set -- "$@" --tls
        if [ -n "${REDIS_TLS_SERVER_NAME:-}" ]; then set -- "$@" --sni "$REDIS_TLS_SERVER_NAME"; fi
        if [ -n "${REDIS_TLS_CA_FILE:-}" ]; then set -- "$@" --cacert "$REDIS_TLS_CA_FILE"; fi
        if [ "${REDIS_TLS_VERIFY:-true}" != "true" ]; then set -- "$@" --insecure; fi
      fi
      deadline=$(( $(date +%s) + REDIS_WAIT_TIMEOUT ))
      echo "Waiting for Redis at ${REDIS_HOST}:${REDIS_PORT} (up to ${REDIS_WAIT_TIMEOUT}s) ..."
      while :; do
        out=$(timeout 5 redis-cli "$@" ping 2>&1) || true
        if [ "$out" = "PONG" ]; then
          echo "Redis is ready."
          exit 0
        fi
        if [ "$(date +%s)" -ge "$deadline" ]; then
          echo "ERROR: Redis at ${REDIS_HOST}:${REDIS_PORT} did not answer PING within ${REDIS_WAIT_TIMEOUT}s." >&2
          echo "Last answer: ${out:-<none>}" >&2
          echo "The backend requires Redis and does not start without it." >&2
          exit 1
        fi
        echo "  Redis not ready, retrying in 3s..."
        sleep 3
      done
  env:
  - name: REDIS_HOST
    value: {{ $redis.host | quote }}
  - name: REDIS_PORT
    value: {{ $redis.port | quote }}
  - name: REDIS_DB
    value: {{ $redis.db | quote }}
  - name: REDIS_WAIT_TIMEOUT
    value: {{ $redis.wait.timeoutSeconds | quote }}
  {{- if $redis.authSecret }}
  - name: REDIS_USERNAME
    {{- if $redis.usernameKey }}
    valueFrom:
      secretKeyRef:
        name: {{ $redis.authSecret | quote }}
        key: {{ $redis.usernameKey | quote }}
    {{- else }}
    value: {{ $redis.username | quote }}
    {{- end }}
  - name: REDISCLI_AUTH
    valueFrom:
      secretKeyRef:
        name: {{ $redis.authSecret | quote }}
        key: {{ $redis.passwordKey | quote }}
  {{- end }}
  {{- if $redis.tls.enabled }}
  - name: REDIS_TLS
    value: "true"
  - name: REDIS_TLS_VERIFY
    value: {{ $redis.tls.verify | quote }}
  {{- with $redis.tls.serverName }}
  - name: REDIS_TLS_SERVER_NAME
    value: {{ . | quote }}
  {{- end }}
  {{- with $redis.tls.caFile }}
  - name: REDIS_TLS_CA_FILE
    value: {{ . | quote }}
  {{- end }}
  {{- end }}
  securityContext:
    allowPrivilegeEscalation: false
    capabilities:
      drop:
      - ALL
    readOnlyRootFilesystem: true
    runAsNonRoot: true
    runAsUser: 65534
    seccompProfile:
      type: RuntimeDefault
  {{- with (include "cloud-platform.redisCAVolumeMount" .) }}
  volumeMounts:
  {{- . | nindent 2 }}
  {{- end }}
{{- end }}

{{/*
The CA bundle an external Redis certificate is verified against: one volume and
one mount, rendered only when settings.cache.external.tls.caSecretRef.name is
set. Only the CA key is projected, so a Secret that also holds a private key
does not put it in the pod.
*/}}
{{- define "cloud-platform.redisCAVolume" -}}
{{- $redis := include "cloud-platform.redis" . | fromYaml -}}
{{- if $redis.tls.caSecret -}}
- name: redis-ca
  secret:
    secretName: {{ $redis.tls.caSecret | quote }}
    items:
    - key: {{ $redis.tls.caKey | quote }}
      path: {{ $redis.tls.caKey | quote }}
{{- end }}
{{- end }}

{{- define "cloud-platform.redisCAVolumeMount" -}}
{{- $redis := include "cloud-platform.redis" . | fromYaml -}}
{{- if $redis.tls.caSecret -}}
- name: redis-ca
  mountPath: /etc/cloud-platform/redis-ca
  readOnly: true
{{- end }}
{{- end }}

{{/*
Path the backend serves its readiness on, on the unified HTTP port. One
definition for the two places that must agree: the probe below, and
serviceCatalog.health.readinessPath in the backend config.
*/}}
{{- define "cloud-platform.readinessPath" -}}
/healthz/ready
{{- end }}

{{- define "cloud-platform.livenessPath" -}}
/healthz/live
{{- end }}

{{/*
Readiness probe of a backend container. The API StatefulSet and the worker
Deployment run the same binary, and both serve the unified HTTP port
(backend.config.http.port), whatever --services they were started with.

The backend checks the database and Redis in the background every 10 seconds.
GET /healthz/ready answers 503 until every service of the process has started,
and after that reports the result of the last check: 200 when both answered,
503 otherwise. The handler only reads that result from memory, so the probe
never waits on a dial to the database or to Redis.

The defaults follow from that 10 second interval:

  periodSeconds 10     one probe per background check. Probing faster would
                       read the same answer again.
  failureThreshold 3   three consecutive failed checks, so an outage of more
                       than about 20 seconds, before the pod leaves the Service.
                       Every replica talks to the same database and the same
                       Redis, so they turn NotReady together and the API is
                       then down for everyone: one lost ping must not do that.
  successThreshold 1   back in the Service on the first good check.
  timeoutSeconds 3     the answer takes milliseconds; this is only slack for a
                       busy node, well under the period.

There is deliberately no liveness probe; see the comment in the workloads.
*/}}
{{- define "cloud-platform.backendReadinessProbe" -}}
{{- $probe := (.Values.backend | default dict).readinessProbe | default dict -}}
{{- if ne (toString $probe.enabled) "false" -}}
readinessProbe:
  httpGet:
    path: {{ include "cloud-platform.readinessPath" . }}
    port: {{ .Values.backend.config.http.port | default 9112 }}
  initialDelaySeconds: {{ $probe.initialDelaySeconds | default 0 | int }}
  periodSeconds: {{ $probe.periodSeconds | default 10 | int }}
  timeoutSeconds: {{ $probe.timeoutSeconds | default 3 | int }}
  failureThreshold: {{ $probe.failureThreshold | default 3 | int }}
  successThreshold: {{ $probe.successThreshold | default 1 | int }}
{{- end }}
{{- end }}

{{- define "distro.openshift" -}}
{{- if .Capabilities.APIVersions.Has "security.openshift.io/v1" -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}



{{- /*
  Replicates the cadence subchart's "cadence.fullname" so we can build the exact
  Secret names its pods reference (cadence-<svc>-secrets). Keep in sync with the
  subchart's _helpers.tpl. The subchart uses its own .Chart.Name ("cadence").
*/ -}}
{{- define "cloud-platform.cadenceFullname" -}}
{{- $cv := .Values.cadence | default dict -}}
{{- if $cv.fullnameOverride -}}
{{- $cv.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := $cv.nameOverride | default "cadence" -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- /*
  OVERRIDE of the cadence subchart's "cadence.databaseSecrets" (named templates
  are global; the parent definition wins). We blank it so the subchart bakes NO
  POSTGRES_PWD and creates NO cadence-<svc>-secrets. Those secrets are instead
  rendered by templates/cadence/cadence-db-secret.yaml from the shared
  settings.db.auth.password, which the subchart itself cannot read.
*/ -}}
{{- define "cadence.databaseSecrets" -}}
{{- $_ := set . "databaseSecrets" list -}}
{{- end -}}

{{/*
Resolve one component's SMTP settings against the shared relay.

Call with a dict of the shared block and the component's own override:

    {{- $smtp := include "cloud-platform.smtp" (dict
          "shared"   (((.Values.global | default dict).settings | default dict).smtp)
          "override" .Values.casdoor.providers.email) | fromYaml }}
    host: {{ $smtp.host | quote }}

Two components need a relay — casdoor for signup and password-reset codes, the
backend for organization invitations — and in almost every deployment it is the
same relay. Configuring it twice invites the failure where one of them is updated
and the other keeps mailing through a decommissioned host, which shows up as
"invitations stopped arriving" long after the change that caused it.

So global.settings.smtp is the one an operator sets, and each component's own block
overrides it FIELD BY FIELD rather than wholesale: a deployment that only needs a
different sender for invitations sets that one key and inherits host, port and
credentials. An empty string in an override means "not set", so it falls back —
which is why an operator who wants a component to send as nobody has to change
the shared value rather than blank the override.

Both levels of the shared path are guarded with `| default dict` rather than
written as `.Values.global.settings.smtp`, so a values file that sets `global` or
`global.settings` to null yields an empty dict here instead of a nil-pointer
error at render time. (`dig` cannot be used for this: it wants a
map[string]interface{} and .Values is a chartutil.Values.)

Note that Helm merges `global` into every subchart's values, so the relay
credentials here are also visible to the gateway, cadence and cert-manager
subcharts. Supply the password with --set or from a secrets manager rather than
committing it to a values file.
*/}}
{{- define "cloud-platform.smtp" -}}
{{- $shared := .shared | default dict -}}
{{- $own := .override | default dict -}}
host: {{ $own.host | default $shared.host | default "" | quote }}
port: {{ $own.port | default $shared.port | default "587" | toString | quote }}
username: {{ $own.username | default $shared.username | default "" | quote }}
password: {{ $own.password | default $shared.password | default "" | quote }}
from: {{ $own.from | default $shared.from | default $own.username | default $shared.username | default "" | quote }}
{{- end }}

