{{/*
Expand the name of the chart.
*/}}
{{- define "cloud-platform.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "cloud-platform.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Primary backend workload/service name.
*/}}
{{- define "cloud-platform.backendName" -}}
{{- default (include "cloud-platform.fullname" .) .Values.backend.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Backend headless service name used by the StatefulSet.
*/}}
{{- define "cloud-platform.backendHeadlessName" -}}
{{- default (printf "%s-headless" (include "cloud-platform.backendName" .)) .Values.backend.headlessServiceName | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
UI workload/service name.
*/}}
{{- define "cloud-platform.uiName" -}}
{{- default (printf "%s-ui" (include "cloud-platform.fullname" .)) .Values.ui.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Worker workload name.
*/}}
{{- define "cloud-platform.workerName" -}}
{{- default (printf "%s-worker" (include "cloud-platform.fullname" .)) .Values.worker.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Compatibility alias used by installer patterns.
*/}}
{{- define "ace.fullname" -}}
{{- include "cloud-platform.fullname" . -}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cloud-platform.labels" -}}
helm.sh/chart: {{ include "cloud-platform.chart" . }}
{{ include "cloud-platform.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "ace.labels" -}}
{{- include "cloud-platform.labels" . -}}
{{- end }}

{{- define "ace.offshootLabels" -}}
{{- include "cloud-platform.labels" . -}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cloud-platform.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cloud-platform.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Chart label
*/}}
{{- define "cloud-platform.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
KubeDB Postgres service hostname (FQDN) used by cadence and the backend.
*/}}
{{- define "cloud-platform.dbHost" -}}
{{- printf "%s-db.%s.svc.cluster.local" (include "cloud-platform.fullname" .) .Release.Namespace -}}
{{- end }}

{{/*
HTTP scheme — "https" when gateway.tls.enabled, otherwise "http".
*/}}
{{- define "cloud-platform.scheme" -}}
{{- if .Values.gateway.tls.enabled -}}https{{- else -}}http{{- end -}}
{{- end }}

{{/*
Public base URL — single source of truth for all public-facing URLs.
Derived from gateway.hostname + TLS flag.  Result: http(s)://<hostname>
*/}}
{{- define "cloud-platform.publicBaseURL" -}}
{{- printf "%s://%s" (include "cloud-platform.scheme" .) (.Values.gateway.hostname | default "localhost") -}}
{{- end }}

{{/*
Whether gateway.hostname is a bare IPv4 address (vs a DNS name).
Browsers do NOT send TLS SNI when connecting to a bare IP, so an HTTPS
listener that pins `hostname` to an IP will never match — callers must omit
the listener hostname in that case. Returns the string "true" or "false".
*/}}
{{- define "cloud-platform.isIPHostname" -}}
{{- if regexMatch "^([0-9]{1,3}\\.){3}[0-9]{1,3}$" (.Values.gateway.hostname | default "") -}}true{{- else -}}false{{- end -}}
{{- end }}

{{- define "distro.openshift" -}}
{{- if .Capabilities.APIVersions.Has "security.openshift.io/v1" -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}
