{{/*
Expand the name of the chart.
*/}}
{{- define "prom-label-proxy.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "prom-label-proxy.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "prom-label-proxy.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "prom-label-proxy.labels" -}}
helm.sh/chart: {{ include "prom-label-proxy.chart" . }}
{{ include "prom-label-proxy.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "prom-label-proxy.selectorLabels" -}}
app.kubernetes.io/name: {{ include "prom-label-proxy.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "prom-label-proxy.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "prom-label-proxy.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "prom-label-proxy.namespace" -}}
  {{- if .Values.namespaceOverride -}}
    {{- .Values.namespaceOverride -}}
  {{- else -}}
    {{- .Release.Namespace -}}
  {{- end -}}
{{- end -}}

{{/*
On the ACE hub, service-gateway runs in its own tenant namespace and its cert is synced into
this namespace by config-syncer, so fall back to the default GatewayClass when none matches the namespace.
*/}}
{{- define "prom-label-proxy.gatewayClass" -}}
{{- $ns := include "prom-label-proxy.namespace" . -}}
{{- $gc := $ns -}}
{{- if not (lookup "gateway.networking.k8s.io/v1" "GatewayClass" "" $ns) -}}
  {{- range (dig "items" list (lookup "gateway.networking.k8s.io/v1" "GatewayClass" "" "")) -}}
    {{- if eq (dig "metadata" "annotations" "catalog.appscode.com/is-default-gatewayclass" "" .) "true" -}}
      {{- $gc = .metadata.name -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $gc -}}
{{- end -}}

{{/*
The image to use for kubeRBACProxy
*/}}
{{- define "kubeRBACProxy.image" -}}
{{- printf "%s:%s" .Values.kubeRBACProxy.image.repository .Values.kubeRBACProxy.image.tag }}
{{- end }}

{{/*
Returns whether the OpenShift distribution is used
*/}}
{{- define "distro.openshift" -}}
{{- or (.Capabilities.APIVersions.Has "project.openshift.io/v1/Project") .Values.distro.openshift -}}
{{- end }}
