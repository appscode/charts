# Druid Editor

[Druid Editor by AppsCode](https://appscode.com) - Druid Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-druid-editor --version=v0.37.0
$ helm upgrade -i kubedbcom-druid-editor appscode/kubedbcom-druid-editor -n default --create-namespace --version=v0.37.0
```

## Introduction

This chart deploys a Druid Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-druid-editor`:

```bash
$ helm upgrade -i kubedbcom-druid-editor appscode/kubedbcom-druid-editor -n default --create-namespace --version=v0.37.0
```

The command deploys a Druid Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-druid-editor`:

```bash
$ helm uninstall kubedbcom-druid-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-druid-editor` chart and their default values.

|                                   Parameter                                   | Description |                                                                Default                                                                |
|-------------------------------------------------------------------------------|-------------|---------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                               |             | <code>{}</code>                                                                                                                       |
| form.alert.annotations                                                        |             | <code>{}</code>                                                                                                                       |
| form.alert.enabled                                                            |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.enabled                                            |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.druidDown.duration                           |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.druidDown.enabled                            |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.druidDown.severity                           |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.database.rules.highJVMMemoryUsage.duration                  |             | <code>30s</code>                                                                                                                      |
| form.alert.groups.database.rules.highJVMMemoryUsage.enabled                   |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.highJVMMemoryUsage.severity                  |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.database.rules.highJVMMemoryUsage.val                       |             | <code>95</code>                                                                                                                       |
| form.alert.groups.database.rules.highJVMPoolUsage.duration                    |             | <code>30s</code>                                                                                                                      |
| form.alert.groups.database.rules.highJVMPoolUsage.enabled                     |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.highJVMPoolUsage.severity                    |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.highJVMPoolUsage.val                         |             | <code>95</code>                                                                                                                       |
| form.alert.groups.database.rules.highQueryTime.duration                       |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.highQueryTime.enabled                        |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.highQueryTime.severity                       |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.highQueryWaitTime.duration                   |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.highQueryWaitTime.enabled                    |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.highQueryWaitTime.severity                   |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.highSegmentScanPending.duration              |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.highSegmentScanPending.enabled               |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.highSegmentScanPending.severity              |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.highSegmentScanPending.val                   |             | <code>2</code>                                                                                                                        |
| form.alert.groups.database.rules.highSegmentUsage.duration                    |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.highSegmentUsage.enabled                     |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.highSegmentUsage.severity                    |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.database.rules.highSegmentUsage.val                         |             | <code>95</code>                                                                                                                       |
| form.alert.groups.database.rules.zkDisconnected.duration                      |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.zkDisconnected.enabled                       |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.zkDisconnected.severity                      |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.opsManager.enabled                                          |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.opsManager.rules.opsRequestFailed.duration                  |             | <code>0m</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestFailed.enabled                   |             | <code>true</code>                                                                                                                     |
| form.alert.groups.opsManager.rules.opsRequestFailed.severity                  |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.duration              |             | <code>0m</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.enabled               |             | <code>true</code>                                                                                                                     |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.severity              |             | <code>info</code>                                                                                                                     |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.duration |             | <code>30m</code>                                                                                                                      |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.enabled  |             | <code>true</code>                                                                                                                     |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.severity |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.provisioner.enabled                                         |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration                 |             | <code>15m</code>                                                                                                                      |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled                  |             | <code>true</code>                                                                                                                     |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity                 |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration                 |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled                  |             | <code>true</code>                                                                                                                     |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity                 |             | <code>critical</code>                                                                                                                 |
| form.alert.labels.release                                                     |             | <code>prometheus</code>                                                                                                               |
| metadata.resource.group                                                       |             | <code>kubedb.com</code>                                                                                                               |
| metadata.resource.version                                                     |             | <code>v1alpha2</code>                                                                                                                 |
| metadata.resource.name                                                        |             | <code>druids</code>                                                                                                                   |
| metadata.resource.kind                                                        |             | <code>Druid</code>                                                                                                                    |
| metadata.resource.scope                                                       |             | <code>Namespaced</code>                                                                                                               |
| metadata.release.name                                                         |             | <code>RELEASE-NAME</code>                                                                                                             |
| metadata.release.namespace                                                    |             | <code>default</code>                                                                                                                  |
| resources.autoscalingKubedbComDruidAutoscaler                                 |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"DruidAutoscaler","metadata":{"name":"druid","namespace":"demo"}}</code> |
| resources.catalogAppscodeComDruidBinding                                      |             | <code>{"apiVersion":"catalog.appscode.com/v1alpha1","kind":"DruidBinding","metadata":{"name":"druid","namespace":"demo"}}</code>      |
| resources.certManagerIoIssuer_ca                                              |             | <code>{"apiVersion":"cert-manager.io/v1","kind":"Issuer","metadata":{"name":"druid-ca","namespace":"demo"}}</code>                    |
| resources.coreKubestashComBackupBlueprint                                     |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupBlueprint","metadata":{"name":"druid","namespace":"demo"}}</code>     |
| resources.coreKubestashComBackupConfiguration                                 |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupConfiguration","metadata":{"name":"druid","namespace":"demo"}}</code> |
| resources.coreKubestashComRestoreSession                                      |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"RestoreSession","metadata":{"name":"druid","namespace":"demo"}}</code>      |
| resources.gitopsKubedbComDruid                                                |             | <code>{"apiVersion":"gitops.kubedb.com/v1alpha1","kind":"Druid","metadata":{"name":"druid","namespace":"druid"}}</code>               |
| resources.kubedbComDruid                                                      |             | <code>{"apiVersion":"kubedb.com/v1alpha2","kind":"Druid","metadata":{"name":"druid","namespace":"druid"}}</code>                      |
| resources.monitoringCoreosComServiceMonitor                                   |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"druid","namespace":"demo"}}</code>         |
| resources.secret_auth                                                         |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"druid-auth","namespace":"demo"}}</code>                                  |
| resources.secret_config                                                       |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"druid-config","namespace":"demo"}}</code>                                |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-druid-editor appscode/kubedbcom-druid-editor -n default --create-namespace --version=v0.37.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-druid-editor appscode/kubedbcom-druid-editor -n default --create-namespace --version=v0.37.0 --values values.yaml
```
