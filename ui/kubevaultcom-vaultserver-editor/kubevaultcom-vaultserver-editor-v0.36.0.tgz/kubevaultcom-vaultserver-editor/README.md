# VaultServer Editor

[VaultServer Editor by AppsCode](https://appscode.com) - VaultServer Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubevaultcom-vaultserver-editor --version=v0.36.0
$ helm upgrade -i kubevaultcom-vaultserver-editor appscode/kubevaultcom-vaultserver-editor -n default --create-namespace --version=v0.36.0
```

## Introduction

This chart deploys a VaultServer Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubevaultcom-vaultserver-editor`:

```bash
$ helm upgrade -i kubevaultcom-vaultserver-editor appscode/kubevaultcom-vaultserver-editor -n default --create-namespace --version=v0.36.0
```

The command deploys a VaultServer Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubevaultcom-vaultserver-editor`:

```bash
$ helm uninstall kubevaultcom-vaultserver-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubevaultcom-vaultserver-editor` chart and their default values.

|                                   Parameter                                   | Description |                                                                 Default                                                                 |
|-------------------------------------------------------------------------------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                               |             | <code>{}</code>                                                                                                                         |
| form.alert.annotations                                                        |             | <code>{}</code>                                                                                                                         |
| form.alert.enabled                                                            |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.operator.enabled                                            |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.operator.rules.appPhaseCritical.duration                    |             | <code>15m</code>                                                                                                                        |
| form.alert.groups.operator.rules.appPhaseCritical.enabled                     |             | <code>true</code>                                                                                                                       |
| form.alert.groups.operator.rules.appPhaseCritical.severity                    |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.operator.rules.appPhaseNotReady.duration                    |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.operator.rules.appPhaseNotReady.enabled                     |             | <code>true</code>                                                                                                                       |
| form.alert.groups.operator.rules.appPhaseNotReady.severity                    |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.opsManager.enabled                                          |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.opsManager.rules.opsRequestFailed.duration                  |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.opsManager.rules.opsRequestFailed.enabled                   |             | <code>true</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestFailed.severity                  |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.duration              |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.enabled               |             | <code>true</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.severity              |             | <code>info</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.duration |             | <code>30m</code>                                                                                                                        |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.enabled  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.severity |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.stash.enabled                                               |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.stash.rules.backupSessionFailed.duration                    |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.stash.rules.backupSessionFailed.enabled                     |             | <code>true</code>                                                                                                                       |
| form.alert.groups.stash.rules.backupSessionFailed.severity                    |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.stash.rules.backupSessionPeriodTooLong.duration             |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.stash.rules.backupSessionPeriodTooLong.enabled              |             | <code>true</code>                                                                                                                       |
| form.alert.groups.stash.rules.backupSessionPeriodTooLong.severity             |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.stash.rules.backupSessionPeriodTooLong.val                  |             | <code>1800</code>                                                                                                                       |
| form.alert.groups.stash.rules.noBackupSessionForTooLong.duration              |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.stash.rules.noBackupSessionForTooLong.enabled               |             | <code>true</code>                                                                                                                       |
| form.alert.groups.stash.rules.noBackupSessionForTooLong.severity              |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.stash.rules.noBackupSessionForTooLong.val                   |             | <code>18000</code>                                                                                                                      |
| form.alert.groups.stash.rules.repositoryCorrupted.duration                    |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.stash.rules.repositoryCorrupted.enabled                     |             | <code>true</code>                                                                                                                       |
| form.alert.groups.stash.rules.repositoryCorrupted.severity                    |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.stash.rules.repositoryStorageRunningLow.duration            |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.stash.rules.repositoryStorageRunningLow.enabled             |             | <code>true</code>                                                                                                                       |
| form.alert.groups.stash.rules.repositoryStorageRunningLow.severity            |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.stash.rules.repositoryStorageRunningLow.val                 |             | <code>1.073741824e+10</code>                                                                                                            |
| form.alert.groups.stash.rules.restoreSessionFailed.duration                   |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.stash.rules.restoreSessionFailed.enabled                    |             | <code>true</code>                                                                                                                       |
| form.alert.groups.stash.rules.restoreSessionFailed.severity                   |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.stash.rules.restoreSessionPeriodTooLong.duration            |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.stash.rules.restoreSessionPeriodTooLong.enabled             |             | <code>true</code>                                                                                                                       |
| form.alert.groups.stash.rules.restoreSessionPeriodTooLong.severity            |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.stash.rules.restoreSessionPeriodTooLong.val                 |             | <code>1800</code>                                                                                                                       |
| form.alert.groups.vault.enabled                                               |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.vault.rules.vaultAutoPilotNodeUnhealthy.duration            |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.vault.rules.vaultAutoPilotNodeUnhealthy.enabled             |             | <code>true</code>                                                                                                                       |
| form.alert.groups.vault.rules.vaultAutoPilotNodeUnhealthy.severity            |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.vault.rules.vaultDown.duration                              |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.vault.rules.vaultDown.enabled                               |             | <code>true</code>                                                                                                                       |
| form.alert.groups.vault.rules.vaultDown.severity                              |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.vault.rules.vaultLeadershipLoss.duration                    |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.vault.rules.vaultLeadershipLoss.enabled                     |             | <code>true</code>                                                                                                                       |
| form.alert.groups.vault.rules.vaultLeadershipLoss.severity                    |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.vault.rules.vaultLeadershipLoss.val                         |             | <code>5</code>                                                                                                                          |
| form.alert.groups.vault.rules.vaultLeadershipSetupFailures.duration           |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.vault.rules.vaultLeadershipSetupFailures.enabled            |             | <code>true</code>                                                                                                                       |
| form.alert.groups.vault.rules.vaultLeadershipSetupFailures.severity           |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.vault.rules.vaultLeadershipSetupFailures.val                |             | <code>5</code>                                                                                                                          |
| form.alert.groups.vault.rules.vaultLeadershipStepsDowns.duration              |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.vault.rules.vaultLeadershipStepsDowns.enabled               |             | <code>true</code>                                                                                                                       |
| form.alert.groups.vault.rules.vaultLeadershipStepsDowns.severity              |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.vault.rules.vaultLeadershipStepsDowns.val                   |             | <code>5</code>                                                                                                                          |
| form.alert.groups.vault.rules.vaultRequestFailures.duration                   |             | <code>15m</code>                                                                                                                        |
| form.alert.groups.vault.rules.vaultRequestFailures.enabled                    |             | <code>true</code>                                                                                                                       |
| form.alert.groups.vault.rules.vaultRequestFailures.severity                   |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.vault.rules.vaultResponseFailures.duration                  |             | <code>15m</code>                                                                                                                        |
| form.alert.groups.vault.rules.vaultResponseFailures.enabled                   |             | <code>true</code>                                                                                                                       |
| form.alert.groups.vault.rules.vaultResponseFailures.severity                  |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.vault.rules.vaultSealed.duration                            |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.vault.rules.vaultSealed.enabled                             |             | <code>true</code>                                                                                                                       |
| form.alert.groups.vault.rules.vaultSealed.severity                            |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.vault.rules.vaultTooManyInfinityTokens.duration             |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.vault.rules.vaultTooManyInfinityTokens.enabled              |             | <code>true</code>                                                                                                                       |
| form.alert.groups.vault.rules.vaultTooManyInfinityTokens.severity             |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.vault.rules.vaultTooManyInfinityTokens.val                  |             | <code>3</code>                                                                                                                          |
| form.alert.labels.release                                                     |             | <code>prometheus</code>                                                                                                                 |
| form.capi.clusterName                                                         |             | <code>""</code>                                                                                                                         |
| form.capi.dedicated                                                           |             | <code>false</code>                                                                                                                      |
| form.capi.namespace                                                           |             | <code>""</code>                                                                                                                         |
| form.capi.nodes                                                               |             | <code>1</code>                                                                                                                          |
| form.capi.provider                                                            |             | <code>""</code>                                                                                                                         |
| form.capi.sku                                                                 |             | <code>""</code>                                                                                                                         |
| form.capi.zones                                                               |             | <code>[]</code>                                                                                                                         |
| metadata.resource.group                                                       |             | <code>kubevault.com</code>                                                                                                              |
| metadata.resource.version                                                     |             | <code>v1alpha1</code>                                                                                                                   |
| metadata.resource.name                                                        |             | <code>vaultservers</code>                                                                                                               |
| metadata.resource.kind                                                        |             | <code>VaultServer</code>                                                                                                                |
| metadata.resource.scope                                                       |             | <code>Namespaced</code>                                                                                                                 |
| metadata.release.name                                                         |             | <code>RELEASE-NAME</code>                                                                                                               |
| metadata.release.namespace                                                    |             | <code>default</code>                                                                                                                    |
| resources.kubevaultComVaultServer                                             |             | <code>{"apiVersion":"kubevault.com/v1alpha2","kind":"VaultServer","metadata":{"name":"vault","namespace":"default"}}</code>             |
| resources.monitoringCoreosComServiceMonitor                                   |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"vault","namespace":"default"}}</code>        |
| resources.secret_backend_creds                                                |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"vault-backend-creds","namespace":"demo"}}</code>                           |
| resources.secret_backend_tls                                                  |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"vault-backend-tls","namespace":"demo"}}</code>                             |
| resources.secret_config                                                       |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"vault-config","namespace":"demo"}}</code>                                  |
| resources.secret_repo_cred                                                    |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"vault-repo-cred","namespace":"default"}}</code>                            |
| resources.secret_unsealer_creds                                               |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"vault-unsealer-creds","namespace":"demo"}}</code>                          |
| resources.stashAppscodeComBackupConfiguration                                 |             | <code>{"apiVersion":"stash.appscode.com/v1beta1","kind":"BackupConfiguration","metadata":{"name":"vault","namespace":"default"}}</code> |
| resources.stashAppscodeComRepository_repo                                     |             | <code>{"apiVersion":"stash.appscode.com/v1alpha1","kind":"Repository","metadata":{"name":"vault-repo","namespace":"default"}}</code>    |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubevaultcom-vaultserver-editor appscode/kubevaultcom-vaultserver-editor -n default --create-namespace --version=v0.36.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubevaultcom-vaultserver-editor appscode/kubevaultcom-vaultserver-editor -n default --create-namespace --version=v0.36.0 --values values.yaml
```
