const { ref, computed, axios, watch, useOperator, store } = window.vueHelpers || {}

const machines = {
  'db.t.micro': {
    resources: {
      requests: {
        cpu: '250m',
        memory: '512Mi',
      },
      limits: {
        cpu: '500m',
        memory: '1Gi',
      },
    },
  },
  'db.t.small': {
    resources: {
      requests: {
        cpu: '1',
        memory: '1Gi',
      },
      limits: {
        cpu: '2',
        memory: '2Gi',
      },
    },
  },
  'db.t.medium': {
    resources: {
      requests: {
        cpu: '1',
        memory: '2Gi',
      },
      limits: {
        cpu: '2',
        memory: '4Gi',
      },
    },
  },
  'db.t.large': {
    resources: {
      requests: {
        cpu: '1',
        memory: '4Gi',
      },
      limits: {
        cpu: '2',
        memory: '8Gi',
      },
    },
  },
  'db.t.xlarge': {
    resources: {
      requests: {
        cpu: '2',
        memory: '8Gi',
      },
      limits: {
        cpu: '4',
        memory: '16Gi',
      },
    },
  },
  'db.t.2xlarge': {
    resources: {
      requests: {
        cpu: '4',
        memory: '16Gi',
      },
      limits: {
        cpu: '8',
        memory: '32Gi',
      },
    },
  },
  'db.m.small': {
    resources: {
      requests: {
        cpu: '500m',
        memory: '0.85Gi',
      },
      limits: {
        cpu: '1',
        memory: '1.7Gi',
      },
    },
  },
  'db.m.large': {
    resources: {
      requests: {
        cpu: '1',
        memory: '4Gi',
      },
      limits: {
        cpu: '2',
        memory: '8Gi',
      },
    },
  },
  'db.m.xlarge': {
    resources: {
      requests: {
        cpu: '2',
        memory: '8Gi',
      },
      limits: {
        cpu: '4',
        memory: '16Gi',
      },
    },
  },
  'db.m.2xlarge': {
    resources: {
      requests: {
        cpu: '4',
        memory: '16Gi',
      },
      limits: {
        cpu: '8',
        memory: '32Gi',
      },
    },
  },
  'db.m.4xlarge': {
    resources: {
      requests: {
        cpu: '8',
        memory: '32Gi',
      },
      limits: {
        cpu: '16',
        memory: '64Gi',
      },
    },
  },
  'db.m.8xlarge': {
    resources: {
      requests: {
        cpu: '16',
        memory: '64Gi',
      },
      limits: {
        cpu: '32',
        memory: '128Gi',
      },
    },
  },
  'db.m.12xlarge': {
    resources: {
      requests: {
        cpu: '24',
        memory: '96Gi',
      },
      limits: {
        cpu: '48',
        memory: '192Gi',
      },
    },
  },
  'db.m.16xlarge': {
    resources: {
      requests: {
        cpu: '32',
        memory: '128Gi',
      },
      limits: {
        cpu: '64',
        memory: '256Gi',
      },
    },
  },
  'db.m.24xlarge': {
    resources: {
      requests: {
        cpu: '48',
        memory: '192Gi',
      },
      limits: {
        cpu: '96',
        memory: '384Gi',
      },
    },
  },
  'db.r.large': {
    resources: {
      requests: {
        cpu: '1',
        memory: '8Gi',
      },
      limits: {
        cpu: '2',
        memory: '16Gi',
      },
    },
  },
  'db.r.xlarge': {
    resources: {
      requests: {
        cpu: '2',
        memory: '16Gi',
      },
      limits: {
        cpu: '4',
        memory: '32Gi',
      },
    },
  },
  'db.r.2xlarge': {
    resources: {
      requests: {
        cpu: '4',
        memory: '32Gi',
      },
      limits: {
        cpu: '8',
        memory: '64Gi',
      },
    },
  },
  'db.r.4xlarge': {
    resources: {
      requests: {
        cpu: '8',
        memory: '96Gi',
      },
      limits: {
        cpu: '16',
        memory: '192Gi',
      },
    },
  },
  'db.r.8xlarge': {
    resources: {
      requests: {
        cpu: '16',
        memory: '128Gi',
      },
      limits: {
        cpu: '32',
        memory: '256Gi',
      },
    },
  },
  'db.r.12xlarge': {
    resources: {
      requests: {
        cpu: '24',
        memory: '192Gi',
      },
      limits: {
        cpu: '48',
        memory: '384Gi',
      },
    },
  },
  'db.r.16xlarge': {
    resources: {
      requests: {
        cpu: '32',
        memory: '256Gi',
      },
      limits: {
        cpu: '64',
        memory: '512Gi',
      },
    },
  },
  'db.r.24xlarge': {
    resources: {
      requests: {
        cpu: '24',
        memory: '384Gi',
      },
      limits: {
        cpu: '96',
        memory: '768Gi',
      },
    },
  },
}

const machineList = [
  'custom',
  'db.t.micro',
  'db.t.small',
  'db.t.medium',
  'db.t.large',
  'db.t.xlarge',
  'db.t.2xlarge',
  'db.m.small',
  'db.m.large',
  'db.m.xlarge',
  'db.m.2xlarge',
  'db.m.4xlarge',
  'db.m.8xlarge',
  'db.m.12xlarge',
  'db.m.16xlarge',
  'db.m.24xlarge',
  'db.r.large',
  'db.r.xlarge',
  'db.r.2xlarge',
  'db.r.4xlarge',
  'db.r.8xlarge',
  'db.r.12xlarge',
  'db.r.16xlarge',
  'db.r.24xlarge',
]
let archiverMap = []
const modeDetails = {
  Standalone: {
    description: 'Single node DB2 without high availability.',
    text: 'Standalone',
  },
  HADR: {
    description: 'DB2 High Availability Disaster Recovery with a primary replicating logs to standby databases for failover.',
    text: 'HADR',
  },
}

export const useFunc = (model) => {
  const { getValue, setDiscriminatorValue, commit, storeGet, discriminator } = useOperator(
    model,
    store.state,
  )

  setDiscriminatorValue('bundleApiLoaded', false)
  setDiscriminatorValue('configDatabase', false)
  setDiscriminatorValue('createAuthSecret', false)
  setDiscriminatorValue('referSecret', false)
  setDiscriminatorValue('backup', false)

  function isEqualToModelPathValue(value, modelPath) {
    const modelPathValue = getValue(model, modelPath)
    // // watchDependency('model#' + modelPath)
    return modelPathValue === value
  }

  let array = []
  function getMachineListForOptions() {
    const machinesFromPreset = getValue(model, '/spec/admin/machineProfiles/machines')
    const available = getValue(model, '/spec/admin/machineProfiles/available')

    if (available.length) {
      array = available.map((machine) => {
        if (machine === 'custom') return { text: machine, value: machine }
        else {
          let subText = '',
            text = ''
          const machineData = machinesFromPreset.find((val) => val.id === machine)
          if (machineData) {
            subText = `CPU: ${machineData.limits.cpu}, Memory: ${machineData.limits.memory}`
            text = machineData.name ? machineData.name : machineData.id
          }
          return { text, subText, value: machine }
        }
      })
    } else {
      array = machineList
        .map((machine) => {
          if (machine === 'custom') return { text: machine, value: machine }
          const subText = `CPU: ${machines[machine].resources.limits.cpu}, Memory: ${machines[machine].resources.limits.memory}`
          const text = machine
          return { text, subText, value: machine }
        })
        .filter((val) => !!val)
    }
    return array
  }

  function setMachineToCustom() {
    const machine = getValue(model, '/spec/admin/machineProfiles/default')
    return machine || 'custom'
  }

  const ifCapiProviderIsNotEmpty = ({ model, getValue, watchDependency }) => {
    // // // // watchDependency('model#/form/capi/provider')
    const val = getValue(model, '/form/capi/provider')
    if (val) return true
  }

  const showMultiselectZone = ({ model, getValue, watchDependency }) => {
    // // // // watchDependency('model#/form/capi/dedicated')
    const val = getValue(model, '/form/capi/provider')

    if (val === 'capz' && ifDedicated()) return true
  }

  const showSelectZone = ({ model, getValue, watchDependency }) => {
    // // // // watchDependency('model#/form/capi/dedicated')
    const val = getValue(model, '/form/capi/provider')
    if (val !== 'capz' && ifDedicated()) return true
  }

  const ifDedicated = ({ model, getValue }) => {
    const val = getValue(model, 'form/capi/dedicated')
    if (val) return true
  }

  const dedicatedOnChange = ({ model, getValue, commit }) => {
    const val = getValue(model, 'form/capi/dedicated')
    if (!val) {
      commit('wizard/model$delete', 'form/capi/zones')
      commit('wizard/model$delete', 'form/capi/sku')
    }
  }

  const ifZones = ({ model, getValue, watchDependency }) => {
    // // // // watchDependency('model#/form/capi/zones')
    // // // // watchDependency('model#/form/capi/dedicated')
    const zones = getValue(model, 'form/capi/zones') || []
    const isDedicated = getValue(model, 'form/capi/dedicated')
    if (zones.length && isDedicated) return true
  }

  const zonesOnChange = ({ model, getValue, commit }) => {
    const zones = getValue(model, 'form/capi/zones') || []
    if (!zones.length) commit('wizard/model$delete', 'form/capi/sku')
  }

  function setStorageClass() {
    const deletionPolicy = getValue(model, '/spec/deletionPolicy') || ''
    let storageClass = getValue(model, '/spec/admin/storageClasses/default') || ''
    const storageClassList = getValue(model, '/spec/admin/storageClasses/available') || []
    const suffix = '-retain'

    const simpleClassList = storageClassList.filter((item) => {
      return !item.endsWith(suffix)
    })
    const retainClassList = storageClassList.filter((item) => {
      return item.endsWith(suffix)
    })
    if (deletionPolicy === 'WipeOut' || deletionPolicy === 'Delete') {
      storageClass = simpleClassList.length ? simpleClassList[0] : retainClassList[0]
    } else {
      storageClass = retainClassList.length ? retainClassList[0] : simpleClassList[0]
    }

    const isChangeable = isToggleOn('storageClasses')
    if (isChangeable && storageClass) {
      commit('wizard/model$update', {
        path: '/spec/admin/storageClasses/default',
        value: storageClass,
        force: true,
      })
    }
  }

  let placement = []
  let versions = []
  let storageClass = []
  let clusterIssuers = []
  let nodetopologiesShared = []
  let nodetopologiesDedicated = []
  let features = []
  async function initBundle() {
    const owner = storeGet('/route/params/user')
    const cluster = storeGet('/route/params/cluster')
    const namespace = getValue(model, '/metadata/release/namespace')

    let db = getValue(model, '/metadata/resource/kind')
    db = db.toLowerCase()
    let url = `clusters/${owner}/${cluster}/db-bundle?type=features,common,versions&db-singular=${db}`
    const annotationUrl = `clusters/${owner}/${cluster}/proxy/core/v1/namespaces/${namespace}`

    try {
      const resp = await axios.get(url)
      features = resp.data.features || []
      placement = resp.data.placementpolicies || []
      versions = resp.data.versions || []
      storageClass = resp.data.storageclasses || []
      clusterIssuers = resp.data.clusterissuers || []
      nodetopologiesDedicated = resp.data.dedicated || []
      nodetopologiesShared = resp.data.shared || []

      const response = await axios.get(annotationUrl)
      const annotations = response.data?.metadata?.annotations || {}
      const uidRange = annotations['openshift.io/sa.scc.uid-range']
      if (uidRange) {
        const val = uidRange.split('/')[0]
        commit('wizard/model$update', {
          path: '/spec/openshift/securityContext/runAsUser',
          value: val,
          force: true,
        })
      }
    } catch (e) {
      console.log(e)
    }

    if (!getValue(model, `/spec/admin/databases/DB2/mode/toggle`)) {
      let defMode = getDefault('databases/DB2/mode') || ''
      if (defMode === '') {
        const arr = getValue(model, '/spec/databases/DB2/mode/available') || []
        if (arr.length) defMode = arr[0]
      }
      commit('wizard/model$update', {
        path: '/spec/mode',
        value: defMode,
        force: true,
      })
    }

    if (!features.includes('tls')) {
      commit('wizard/model$update', {
        path: '/spec/admin/tls/default',
        value: false,
        force: true,
      })
    }
    if (!features.includes('binding')) {
      commit('wizard/model$update', {
        path: '/spec/admin/expose/enable/default',
        value: false,
        force: true,
      })
    }
    if (!features.includes('monitoring')) {
      commit('wizard/model$update', {
        path: '/spec/admin/monitoring/agent',
        value: '',
        force: true,
      })
      commit('wizard/model$update', {
        path: '/form/alert/enabled',
        value: 'none',
        force: true,
      })
    }
    if (!features.includes('backup')) {
      commit('wizard/model$update', {
        path: '/spec/admin/archiver/enable/default',
        value: false,
        force: true,
      })
      commit('wizard/model$update', {
        path: '/spec/backup/tool',
        value: '',
        force: true,
      })
    }

    setDiscriminatorValue('/bundleApiLoaded', true)
  }

  function fetchOptions(type) {
    let kind = getValue(model, '/metadata/resource/kind')

    let returnArray = []
    if (type === 'clusterTier/placement') {
      returnArray = placement
    } else if (type === `databases/${kind}/versions`) {
      returnArray = versions
    } else if (type === 'storageClasses') {
      returnArray = storageClass
    } else if (type === 'clusterIssuers') {
      returnArray = clusterIssuers
    }

    if (returnArray.length === 1) {
      const path = `/spec/admin/${type}/default`
      commit('wizard/model$update', {
        path: path,
        value: returnArray[0],
        force: true,
      })
    }

    return returnArray
  }

  async function getAdminOptions(type) {
    // // // // watchDependency('discriminator#/bundleApiLoaded')

    const options = (await getValue(model, `/spec/admin/${type}/available`)) || []

    if (type.endsWith('/mode')) {
      const modes = options.length ? options : Object.keys(modeDetails)
      return modes.map((item) => ({
        description: modeDetails[item]?.description || '',
        text: modeDetails[item]?.text || '',
        value: item,
      }))
    }
    if (options.length === 0) {
      return fetchOptions(type)
    }
    return options
  }

  let backupOn = false
  function checkIfFeatureOn(type) {
    let val = getValue(model, `/spec/admin/${type}/toggle`)
    if (type === 'backup' || type === 'archiver' || type === 'expose') {
      val = getValue(model, `/spec/admin/${type}/enable/toggle`)
    }
    const backupVal = getValue(model, '/spec/backup/tool')

    if (type === 'backup') {
      if (!backupOn) backupOn = features.includes('backup') && backupVal === 'KubeStash' && val
      return backupOn
    } else if (type === 'tls') {
      return features.includes('tls') && val
    } else if (type === 'expose') {
      return features.includes('binding') && val
    } else if (type === 'monitoring') {
      return features.includes('monitoring') && val
    } else if (type === 'archiver') {
      return features.includes('backup') && backupVal === 'KubeStash' && val
    }
  }

  function isToggleOn(type) {
    // // // // watchDependency('discriminator#/bundleApiLoaded')
    // // // // watchDependency('model#/spec/admin/deployment/default')
    const bundleApiLoaded = getValue(discriminator, '/bundleApiLoaded')
    let deploymentType = getValue(model, `/spec/admin/deployment/default`)
    if (
      type === 'tls' ||
      type === 'backup' ||
      type === 'expose' ||
      type === 'monitoring' ||
      type === 'archiver'
    ) {
      return checkIfFeatureOn(type)
    } else if (
      type === 'clusterTier' ||
      type === 'clusterTier/placement' ||
      type === 'clusterTier/nodeTopology'
    ) {
      if (deploymentType === 'Dedicated' && bundleApiLoaded) return true
      else return false
    } else if (type === 'deployment') {
      const deploymentType = getValue(model, '/spec/admin/deployment/default')
      if (!nodetopologiesDedicated.length && deploymentType === 'Dedicated') {
        commit('wizard/model$update', {
          path: '/spec/admin/deployment/default',
          value: 'Shared',
          force: true,
        })
      }
      return (
        getValue(model, `/spec/admin/${type}/toggle`) &&
        nodetopologiesDedicated.length &&
        bundleApiLoaded
      )
    } else return getValue(model, `/spec/admin/${type}/toggle`) && bundleApiLoaded
  }

  async function getNodeTopology() {
    // // // // watchDependency('model#/spec/admin/deployment/default')
    // // // // watchDependency('model#/spec/admin/clusterTier/default')
    const deploymentType = getValue(model, '/spec/admin/deployment/default') || ''
    const clusterTier = getValue(model, '/spec/admin/clusterTier/default') || ''
    let nodeTopologyList = getValue(model, `/spec/admin/clusterTier/nodeTopology/available`) || []

    const provider = storeGet('/cluster/clusterDefinition/result/provider') || ''

    if (deploymentType === 'Shared') nodeTopologyList = nodetopologiesShared
    else if (deploymentType === 'Dedicated') nodeTopologyList = nodetopologiesDedicated

    const filteredList = filterNodeTopology(nodeTopologyList, clusterTier, provider)
    return filteredList
  }

  function filterNodeTopology(list, tier, provider) {
    // first filter the list from value that exists from the filtered list got from API
    const filteredlist = list

    // filter the list based on clusterTier
    if (provider === 'EKS') {
      return filteredlist.filter((item) => {
        if (tier === 'CPUOptimized') return item.startsWith('c')
        else if (tier === 'MemoryOptimized') return item.startsWith('r')
        else return !item.startsWith('c') && !item.startsWith('r')
      })
    } else if (provider === 'AKS') {
      return filteredlist.filter((item) => {
        if (tier === 'CPUOptimized') return item.startsWith('f') || item.startsWith('fx')
        else if (tier === 'MemoryOptimized')
          return (
            item.startsWith('e') ||
            item.startsWith('eb') ||
            item.startsWith('ec') ||
            item.startsWith('m') ||
            item.startsWith('d')
          )
        else
          return (
            !(item.startsWith('f') || item.startsWith('fx')) &&
            !(
              item.startsWith('e') ||
              item.startsWith('eb') ||
              item.startsWith('ec') ||
              item.startsWith('m') ||
              item.startsWith('d')
            )
          )
      })
    } else if (provider === 'GKE') {
      return filteredlist.filter((item) => {
        if (tier === 'CPUOptimized')
          return item.startsWith('h3') || item.startsWith('c2') || item.startsWith('c2d')
        else if (tier === 'MemoryOptimized')
          return (
            item.startsWith('x4') ||
            item.startsWith('m1') ||
            item.startsWith('m2') ||
            item.startsWith('m3')
          )
        else
          return (
            !(item.startsWith('h3') || item.startsWith('c2') || item.startsWith('c2d')) &&
            !(
              item.startsWith('x4') ||
              item.startsWith('m1') ||
              item.startsWith('m2') ||
              item.startsWith('m3')
            )
          )
      })
    } else return filteredlist
  }

  function isConfigDatabaseOn() {
    // // // // watchDependency('discriminator#/configDatabase')
    return getValue(discriminator, '/configDatabase')
  }
  function notEqualToDatabaseMode(mode) {
    const modelPathValue = getValue(model, '/spec/mode')
    // // // // watchDependency('model#/spec/mode')
    return modelPathValue && modelPathValue !== mode
  }
  function notEqualToDatabaseMode(mode) {
    const modelPathValue = getValue(model, '/spec/mode')
    // // // // watchDependency('model#/spec/mode')
    return modelPathValue && modelPathValue !== mode
  }
  function clearConfiguration() {
    const configOn = getValue(discriminator, '/configDatabase')

    if (!configOn) {
      commit('wizard/model$delete', '/spec/configuration')
    }
  }

  function onAuthChange() {
    commit('wizard/model$update', {
      path: '/spec/authSecret/name',
      value: '',
      force: true,
    })
    commit('wizard/model$update', {
      path: '/spec/authSecret/password',
      value: '',
      force: true,
    })
  }
  function isMachineCustom(path) {
    const fullpath = path ? `/spec/${path}/podResources/machine` : '/spec/podResources/machine'
    const modelPathValue = getValue(model, fullpath)
    // watchDependency(`model#${fullpath}`)
    return modelPathValue === 'custom'
  }

  function isMachineNotCustom(path) {
    return !isMachineCustom(path)
  }
  function setLimits(resource, type) {
    const path = type ? `/spec/${type}/podResources/machine` : '/spec/podResources/machine'
    // watchDependency(`model#${path}`)
    const selectedMachine = getValue(model, path) || 'custom'
    const reqCommitPath = type
      ? `/spec/${type}/podResources/resources/limits/${resource}`
      : `/spec/podResources/resources/limits/${resource}`
    const comparePath = type
      ? `/spec/${type}/podResources/resources/requests/${resource}`
      : `/spec/podResources/resources/requests/${resource}`

    const resourceValue = getValue(model, comparePath)
    const machinesFromPreset = getValue(model, '/spec/admin/machineProfiles/machines')
    const available = getValue(model, '/spec/admin/machineProfiles/available')

    let cpu = '',
      memory = ''
    if (available.length && selectedMachine !== 'custom') {
      const machineData = machinesFromPreset.find((val) => val.id === selectedMachine)
      if (machineData) {
        cpu = machineData.limits.cpu
        memory = machineData.limits.memory
      }
    } else {
      if (selectedMachine === 'custom') {
        cpu = resourceValue
        memory = resourceValue
      } else {
        cpu = machines[selectedMachine].resources.limits.cpu
        memory = machines[selectedMachine].resources.limits.memory
      }
    }

    if (resource === 'memory') {
      commit('wizard/model$update', {
        path: reqCommitPath,
        value: memory,
        force: true,
      })
      commit('wizard/model$update', {
        path: comparePath,
        value: memory,
        force: true,
      })
      return memory
    } else {
      commit('wizard/model$update', {
        path: reqCommitPath,
        value: cpu,
        force: true,
      })
      commit('wizard/model$update', {
        path: comparePath,
        value: cpu,
        force: true,
      })
      return cpu
    }
  }

  function setRequests(resource, type) {
    const modelPath = type
      ? `/spec/${type}/podResources/resources/requests/${resource}`
      : `/spec/podResources/resources/requests/${resource}`
    const val = getValue(model, modelPath)
    const commitPath = type
      ? `/spec/${type}/podResources/resources/limits/${resource}`
      : `/spec/podResources/resources/limits/${resource}`

    const fullpath = type ? `/spec/${type}/podResources/machine` : `/spec/podResources/machine`
    const modelPathValue = getValue(model, fullpath)

    commit('wizard/model$update', {
      path: commitPath,
      value: val,
      force: true,
    })

    if (!modelPathValue) return
    if (modelPathValue === 'custom') return val

    let commitCpuMemory, ModelPathValue
    if (resource && type) {
      const fullPath = `/spec/${type}/podResources/machine`
      ModelPathValue = getValue(model, fullPath)
      commitCpuMemory = `spec/${type}/podResources/resources/requests/${resource}`
    } else {
      const fullPath = `/spec/podResources/machine`
      ModelPathValue = getValue(model, fullPath)
      commitCpuMemory = `spec/podResources/resources/requests/${resource}`
    }
    let cpuMemoryValue
    array.forEach((item) => {
      if (item.value === ModelPathValue) {
        // Parse subText like "CPU: 2, Memory: 2Gi"
        const subText = item.subText || ''
        if (resource === 'cpu') {
          // Extract CPU value
          const cpuMatch = subText.match(/CPU:\s*([^,]+)/)
          cpuMemoryValue = cpuMatch ? cpuMatch[1].trim() : ''
        } else if (resource === 'memory') {
          // Extract Memory value
          const memoryMatch = subText.match(/Memory:\s*(.+)/)
          cpuMemoryValue = memoryMatch ? memoryMatch[1].trim() : ''
        }
      }
    })
    commit('wizard/model$update', {
      path: commitCpuMemory,
      value: cpuMemoryValue,
      force: true,
    })
    return cpuMemoryValue
  }

  function getDefault(type) {
    const val = getValue(model, `/spec/admin/${type}/default`) || ''
    return val
  }

  function initDeletionPolicy() {
    const deletionPolicy = getDefault('deletionPolicy')
    const options = {
      DoNotTerminate: {
        text: 'DoNotTerminate — Blocks deletion; protects against accidental removal',
        value: 'DoNotTerminate',
      },
      Halt: {
        text: 'Halt — Deletes pods & services; retains data, secrets & backups',
        value: 'Halt',
      },
      Delete: {
        text: 'Delete — Deletes pods, services & data; retains secrets & backups',
        value: 'Delete',
      },
      WipeOut: {
        text: 'WipeOut — Deletes everything, including data, secrets & backups',
        value: 'WipeOut',
      },
    }
    return options[deletionPolicy] || options.WipeOut
  }

  async function getReferSecrets() {
    const referSecret = getValue(discriminator, '/referSecret')
    if (!referSecret) {
      return []
    }

    const params = storeGet('/route/params')
    const { user, cluster } = params
    const namespace = getValue(model, `/metadata/release/namespace`)
    let url = `/clusters/${user}/${cluster}/proxy/core/v1/namespaces/${namespace}/secrets`

    const options = []
    try {
      const resp = await axios.get(url, {
        params: {
          filter: { items: { metadata: { name: null }, data: null } },
        },
      })
      const items = resp.data?.items || []
      items.forEach((ele) => {
        const keys = Object.keys(ele.data || {})
        if (keys.length === 2 && keys.includes('username') && keys.includes('password'))
          options.push(ele.metadata?.name)
      })
    } catch (e) {
      console.log(e)
    }
    return options
  }

  function showSecretDropdown() {
    const modelPathValue = getValue(discriminator, '/referSecret')
    // // // // watchDependency('discriminator#/referSecret')
    return !!modelPathValue && showReferSecret()
  }

  function showReferSecret() {
    const modelPathValue = getValue(discriminator, '/createAuthSecret')
    // // // // watchDependency('discriminator#/createAuthSecret')
    return !!modelPathValue
  }

  function getDefaultValue(path) {
    const val = getValue(model, `/${path}`) || ''
    return val
  }

  function showReferSecretSwitch() {
    const modelPathValue = getValue(model, '/spec/admin/authCredential/referExisting')
    // // // // watchDependency('discriminator#/createAuthSecret')
    return !!modelPathValue && showReferSecret()
  }

  function onReferSecretChange() {
    commit('wizard/model$update', {
      path: '/spec/authSecret/name',
      value: '',
      force: true,
    })
  }

  function setServiceTemplate() {
    const serviceTemplates = getValue(model, '/spec/admin/serviceTemplates') || []
    if (serviceTemplates.length) return serviceTemplates
  }
  setDiscriminatorValue('initScript', false)
  setDiscriminatorValue('initScriptSource', 'configMap')

  function isInitScriptOn() {
    return !!getValue(discriminator, '/initScript')
  }

  function isInitScriptSource(source) {
    return getValue(discriminator, '/initScriptSource') === source
  }

  function onInitScriptChange() {
    if (!getValue(discriminator, '/initScript')) commit('wizard/model$delete', '/spec/init/script')
  }

  function onInitScriptSourceChange() {
    const source = getValue(discriminator, '/initScriptSource')
    const other = source === 'secret' ? 'configMap' : 'secret'
    commit('wizard/model$delete', `/spec/init/script/${other}`)
  }

  async function getInitScriptSources(resource) {
    const { user, cluster } = storeGet('/route/params')
    const namespace = getValue(model, '/metadata/release/namespace')
    const url = `/clusters/${user}/${cluster}/proxy/core/v1/namespaces/${namespace}/${resource}`
    try {
      const resp = await axios.get(url, {
        params: { filter: { items: { metadata: { name: null } } } },
      })
      return (resp.data?.items || []).map((item) => item.metadata?.name)
    } catch (e) {
      console.log(e)
      return []
    }
  }

  return {
    isInitScriptOn,
    isInitScriptSource,
    onInitScriptChange,
    onInitScriptSourceChange,
    getInitScriptSources,
    showReferSecretSwitch,
    onReferSecretChange,
    getDefaultValue,
    showSecretDropdown,
    showReferSecret,
    getReferSecrets,
    initBundle,
    setLimits,
    setRequests,
    getAdminOptions,
    isToggleOn,
    getNodeTopology,
    isConfigDatabaseOn,
    notEqualToDatabaseMode,
    filterNodeTopology,
    onAuthChange,
    isMachineNotCustom,
    isMachineCustom,
    clearConfiguration,
    isEqualToModelPathValue,
    getMachineListForOptions,
    setMachineToCustom,
    ifCapiProviderIsNotEmpty,
    ifDedicated,
    dedicatedOnChange,
    ifZones,
    zonesOnChange,
    showMultiselectZone,
    showSelectZone,
    setStorageClass,
    getDefault,
    setServiceTemplate,
    initDeletionPolicy,
  }
}
