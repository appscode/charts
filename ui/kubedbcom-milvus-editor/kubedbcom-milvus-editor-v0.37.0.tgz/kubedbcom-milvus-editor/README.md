# Milvus Editor

[Milvus Editor by AppsCode](https://appscode.com) - Milvus Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-milvus-editor --version=v0.37.0
$ helm upgrade -i kubedbcom-milvus-editor appscode/kubedbcom-milvus-editor -n default --create-namespace --version=v0.37.0
```

## Introduction

This chart deploys a Milvus Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-milvus-editor`:

```bash
$ helm upgrade -i kubedbcom-milvus-editor appscode/kubedbcom-milvus-editor -n default --create-namespace --version=v0.37.0
```

The command deploys a Milvus Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-milvus-editor`:

```bash
$ helm uninstall kubedbcom-milvus-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-milvus-editor` chart and their default values.

|                               Parameter                                | Description |                                                                 Default                                                                 |
|------------------------------------------------------------------------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                        |             | <code>{}</code>                                                                                                                         |
| form.alert.annotations                                                 |             | <code>{}</code>                                                                                                                         |
| form.alert.enabled                                                     |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.enabled                                     |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.diskAlmostFull.duration               |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.diskAlmostFull.enabled                |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.diskAlmostFull.severity               |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.diskAlmostFull.val                    |             | <code>95</code>                                                                                                                         |
| form.alert.groups.database.rules.diskUsageHigh.duration                |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.diskUsageHigh.enabled                 |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.diskUsageHigh.severity                |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.diskUsageHigh.val                     |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusGoroutinesExplosion.duration    |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusGoroutinesExplosion.enabled     |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.milvusGoroutinesExplosion.severity    |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.milvusGoroutinesExplosion.val         |             | <code>1000</code>                                                                                                                       |
| form.alert.groups.database.rules.milvusHighCPUUsage.duration           |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusHighCPUUsage.enabled            |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.milvusHighCPUUsage.severity           |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.milvusHighCPUUsage.val                |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusHighFDsUsage.duration           |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusHighFDsUsage.enabled            |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.milvusHighFDsUsage.severity           |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.milvusHighFDsUsage.val                |             | <code>110</code>                                                                                                                        |
| form.alert.groups.database.rules.milvusHighMemoryUsage.duration        |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusHighMemoryUsage.enabled         |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.milvusHighMemoryUsage.severity        |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.milvusHighMemoryUsage.val             |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusHighProcessMemoryUsage.duration |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusHighProcessMemoryUsage.enabled  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.milvusHighProcessMemoryUsage.severity |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.milvusHighProcessMemoryUsage.val      |             | <code>800000000</code>                                                                                                                  |
| form.alert.groups.database.rules.milvusHighThreadPressure.duration     |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusHighThreadPressure.enabled      |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.milvusHighThreadPressure.severity     |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.milvusHighThreadPressure.val          |             | <code>60</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusInstanceDown.duration           |             | <code>30s</code>                                                                                                                        |
| form.alert.groups.database.rules.milvusInstanceDown.enabled            |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.milvusInstanceDown.severity           |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.milvusRestarted.duration              |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.milvusRestarted.enabled               |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.milvusRestarted.severity              |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.milvusRestarted.val                   |             | <code>180</code>                                                                                                                        |
| form.alert.groups.kubeStash.enabled                                    |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.kubeStash.rules.backupSessionFailed.duration         |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.kubeStash.rules.backupSessionFailed.enabled          |             | <code>true</code>                                                                                                                       |
| form.alert.groups.kubeStash.rules.backupSessionFailed.severity         |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.kubeStash.rules.backupSessionPeriodTooLong.duration  |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.kubeStash.rules.backupSessionPeriodTooLong.enabled   |             | <code>true</code>                                                                                                                       |
| form.alert.groups.kubeStash.rules.backupSessionPeriodTooLong.severity  |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.kubeStash.rules.backupSessionPeriodTooLong.val       |             | <code>1800</code>                                                                                                                       |
| form.alert.groups.kubeStash.rules.noBackupSessionForTooLong.duration   |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.kubeStash.rules.noBackupSessionForTooLong.enabled    |             | <code>true</code>                                                                                                                       |
| form.alert.groups.kubeStash.rules.noBackupSessionForTooLong.severity   |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.kubeStash.rules.noBackupSessionForTooLong.val        |             | <code>18000</code>                                                                                                                      |
| form.alert.groups.kubeStash.rules.repositoryCorrupted.duration         |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.kubeStash.rules.repositoryCorrupted.enabled          |             | <code>true</code>                                                                                                                       |
| form.alert.groups.kubeStash.rules.repositoryCorrupted.severity         |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.kubeStash.rules.repositoryStorageRunningLow.duration |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.kubeStash.rules.repositoryStorageRunningLow.enabled  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.kubeStash.rules.repositoryStorageRunningLow.severity |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.kubeStash.rules.repositoryStorageRunningLow.val      |             | <code>1.073741824e+10</code>                                                                                                            |
| form.alert.groups.kubeStash.rules.restoreSessionFailed.duration        |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.kubeStash.rules.restoreSessionFailed.enabled         |             | <code>true</code>                                                                                                                       |
| form.alert.groups.kubeStash.rules.restoreSessionFailed.severity        |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.kubeStash.rules.restoreSessionPeriodTooLong.duration |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.kubeStash.rules.restoreSessionPeriodTooLong.enabled  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.kubeStash.rules.restoreSessionPeriodTooLong.severity |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.kubeStash.rules.restoreSessionPeriodTooLong.val      |             | <code>1800</code>                                                                                                                       |
| form.alert.groups.provisioner.enabled                                  |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration          |             | <code>15m</code>                                                                                                                        |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled           |             | <code>true</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity          |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration          |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled           |             | <code>true</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity          |             | <code>critical</code>                                                                                                                   |
| form.alert.labels.release                                              |             | <code>prometheus</code>                                                                                                                 |
| metadata.resource.group                                                |             | <code>kubedb.com</code>                                                                                                                 |
| metadata.resource.version                                              |             | <code>v1alpha2</code>                                                                                                                   |
| metadata.resource.name                                                 |             | <code>milvuses</code>                                                                                                                   |
| metadata.resource.kind                                                 |             | <code>Milvus</code>                                                                                                                     |
| metadata.resource.scope                                                |             | <code>Namespaced</code>                                                                                                                 |
| metadata.release.name                                                  |             | <code>RELEASE-NAME</code>                                                                                                               |
| metadata.release.namespace                                             |             | <code>default</code>                                                                                                                    |
| resources.autoscalingKubedbComMilvusAutoscaler                         |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"MilvusAutoscaler","metadata":{"name":"milvus","namespace":"demo"}}</code> |
| resources.catalogAppscodeComMilvusBinding                              |             | <code>{"apiVersion":"catalog.appscode.com/v1alpha1","kind":"MilvusBinding","metadata":{"name":"milvus","namespace":"demo"}}</code>      |
| resources.certManagerIoIssuer_ca                                       |             | <code>{"apiVersion":"cert-manager.io/v1","kind":"Issuer","metadata":{"name":"milvus-ca","namespace":"demo"}}</code>                     |
| resources.coreKubestashComBackupBlueprint                              |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupBlueprint","metadata":{"name":"milvus","namespace":"demo"}}</code>      |
| resources.coreKubestashComBackupConfiguration                          |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupConfiguration","metadata":{"name":"milvus","namespace":"demo"}}</code>  |
| resources.coreKubestashComRestoreSession                               |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"RestoreSession","metadata":{"name":"milvus","namespace":"demo"}}</code>       |
| resources.kubedbComMilvus                                              |             | <code>{"apiVersion":"kubedb.com/v1alpha2","kind":"Milvus","metadata":{"name":"milvus","namespace":"default"}}</code>                    |
| resources.monitoringCoreosComServiceMonitor                            |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"milvus","namespace":"demo"}}</code>          |
| resources.secret_auth                                                  |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"milvus-auth","namespace":"demo"}}</code>                                   |
| resources.secret_config                                                |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"milvus-config","namespace":"demo"}}</code>                                 |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-milvus-editor appscode/kubedbcom-milvus-editor -n default --create-namespace --version=v0.37.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-milvus-editor appscode/kubedbcom-milvus-editor -n default --create-namespace --version=v0.37.0 --values values.yaml
```
