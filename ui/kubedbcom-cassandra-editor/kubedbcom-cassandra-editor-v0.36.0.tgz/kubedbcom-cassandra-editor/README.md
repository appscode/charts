# Cassandra Editor

[Cassandra Editor by AppsCode](https://appscode.com) - Cassandra Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-cassandra-editor --version=v0.36.0
$ helm upgrade -i kubedbcom-cassandra-editor appscode/kubedbcom-cassandra-editor -n default --create-namespace --version=v0.36.0
```

## Introduction

This chart deploys a Cassandra Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-cassandra-editor`:

```bash
$ helm upgrade -i kubedbcom-cassandra-editor appscode/kubedbcom-cassandra-editor -n default --create-namespace --version=v0.36.0
```

The command deploys a Cassandra Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-cassandra-editor`:

```bash
$ helm uninstall kubedbcom-cassandra-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-cassandra-editor` chart and their default values.

|                               Parameter                               | Description |                                                                    Default                                                                    |
|-----------------------------------------------------------------------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                       |             | <code>{}</code>                                                                                                                               |
| form.alert.annotations                                                |             | <code>{}</code>                                                                                                                               |
| form.alert.enabled                                                    |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.enabled                                    |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.rules.cassandraConnectionTimeouts.duration |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.cassandraConnectionTimeouts.enabled  |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.cassandraConnectionTimeouts.severity |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.rules.cassandraConnectionTimeouts.val      |             | <code>100</code>                                                                                                                              |
| form.alert.groups.database.rules.cassandraDown.duration               |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.cassandraDown.enabled                |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.cassandraDown.severity               |             | <code>critical</code>                                                                                                                         |
| form.alert.groups.database.rules.cassandraDroppedMessages.duration    |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.cassandraDroppedMessages.enabled     |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.cassandraDroppedMessages.severity    |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.rules.cassandraDroppedMessages.val         |             | <code>1</code>                                                                                                                                |
| form.alert.groups.database.rules.cassandraHighReadLatency.duration    |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.cassandraHighReadLatency.enabled     |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.cassandraHighReadLatency.severity    |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.rules.cassandraHighReadLatency.val         |             | <code>7000</code>                                                                                                                             |
| form.alert.groups.database.rules.cassandraHighWriteLatency.duration   |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.cassandraHighWriteLatency.enabled    |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.cassandraHighWriteLatency.severity   |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.rules.cassandraHighWriteLatency.val        |             | <code>7000</code>                                                                                                                             |
| form.alert.groups.database.rules.cassandraMemoryLimit.duration        |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.cassandraMemoryLimit.enabled         |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.cassandraMemoryLimit.severity        |             | <code>critical</code>                                                                                                                         |
| form.alert.groups.database.rules.cassandraMemoryLimit.val             |             | <code>3.3554432e+07</code>                                                                                                                    |
| form.alert.groups.database.rules.cassandraServiceRespawn.duration     |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.cassandraServiceRespawn.enabled      |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.cassandraServiceRespawn.severity     |             | <code>critical</code>                                                                                                                         |
| form.alert.groups.database.rules.cassandraServiceRespawn.val          |             | <code>180</code>                                                                                                                              |
| form.alert.groups.provisioner.enabled                                 |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration         |             | <code>5m</code>                                                                                                                               |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled          |             | <code>true</code>                                                                                                                             |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity         |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration         |             | <code>1m</code>                                                                                                                               |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled          |             | <code>true</code>                                                                                                                             |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity         |             | <code>critical</code>                                                                                                                         |
| form.alert.labels.release                                             |             | <code>kube-prometheus-stack</code>                                                                                                            |
| metadata.resource.group                                               |             | <code>kubedb.com</code>                                                                                                                       |
| metadata.resource.version                                             |             | <code>v1alpha2</code>                                                                                                                         |
| metadata.resource.name                                                |             | <code>cassandras</code>                                                                                                                       |
| metadata.resource.kind                                                |             | <code>Cassandra</code>                                                                                                                        |
| metadata.resource.scope                                               |             | <code>Namespaced</code>                                                                                                                       |
| metadata.release.name                                                 |             | <code>RELEASE-NAME</code>                                                                                                                     |
| metadata.release.namespace                                            |             | <code>default</code>                                                                                                                          |
| resources.autoscalingKubedbComCassandraAutoscaler                     |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"CassandraAutoscaler","metadata":{"name":"cassandra","namespace":"demo"}}</code> |
| resources.catalogAppscodeComCassandraBinding                          |             | <code>{"apiVersion":"catalog.appscode.com/v1alpha1","kind":"CassandraBinding","metadata":{"name":"cassandra","namespace":"demo"}}</code>      |
| resources.certManagerIoIssuer_ca                                      |             | <code>{"apiVersion":"cert-manager.io/v1","kind":"Issuer","metadata":{"name":"cassandra-ca","namespace":"demo"}}</code>                        |
| resources.coreKubestashComBackupBlueprint                             |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupBlueprint","metadata":{"name":"cassandra","namespace":"demo"}}</code>         |
| resources.coreKubestashComBackupConfiguration                         |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupConfiguration","metadata":{"name":"cassandra","namespace":"demo"}}</code>     |
| resources.coreKubestashComRestoreSession                              |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"RestoreSession","metadata":{"name":"cassandra","namespace":"demo"}}</code>          |
| resources.kubedbComCassandra                                          |             | <code>{"apiVersion":"kubedb.com/v1alpha2","kind":"Cassandra","metadata":{"name":"cassandra","namespace":"cassandra"}}</code>                  |
| resources.monitoringCoreosComServiceMonitor                           |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"cassandra","namespace":"demo"}}</code>             |
| resources.secret_auth                                                 |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"cassandra-auth","namespace":"demo"}}</code>                                      |
| resources.secret_config                                               |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"cassandra-config","namespace":"demo"}}</code>                                    |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-cassandra-editor appscode/kubedbcom-cassandra-editor -n default --create-namespace --version=v0.36.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-cassandra-editor appscode/kubedbcom-cassandra-editor -n default --create-namespace --version=v0.36.0 --values values.yaml
```
