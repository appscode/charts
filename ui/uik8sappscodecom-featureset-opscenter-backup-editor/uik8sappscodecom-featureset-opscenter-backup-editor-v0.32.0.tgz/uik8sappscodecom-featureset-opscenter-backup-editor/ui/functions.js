const { axios, store, useOperator } = window.vueHelpers || {}

export const useFunc = (model) => {
  const { getValue, setDiscriminatorValue, commit, storeGet, discriminator } = useOperator(
    model,
    store.state,
  )

  setDiscriminatorValue('/enabledFeatures', [])
  setDiscriminatorValue('/isResourceLoaded', false)
  let resources = {}
  let enabledFeaturesChanged = false
  const backendMap = {
    azure: {
      spec: { container: '', maxConnections: 0, prefix: '' },
      auth: { AZURE_ACCOUNT_KEY: '', AZURE_ACCOUNT_NAME: '' },
    },
    b2: {
      spec: { bucket: '', prefix: '', maxConnections: 0 },
      auth: { B2_ACCOUNT_ID: '', B2_ACCOUNT_KEY: '' },
    },
    gcs: {
      spec: { bucket: '', prefix: '', maxConnections: 0 },
      auth: { GOOGLE_PROJECT_ID: '', GOOGLE_SERVICE_ACCOUNT_JSON_KEY: '' },
    },
    s3: {
      spec: { endpoint: '', bucket: '', prefix: '', region: '' },
      auth: {
        AWS_ACCESS_KEY_ID: '',
        AWS_SECRET_ACCESS_KEY: '',
        CA_CERT_DATA: '',
      },
    },
    swift: {
      spec: { container: '', prefix: '' },
      auth: {
        OS_AUTH_TOKEN: '',
        OS_AUTH_URL: '',
        OS_PASSWORD: '',
        OS_PROJECT_DOMAIN_NAME: '',
        OS_PROJECT_NAME: '',
        OS_REGION_NAME: '',
        OS_STORAGE_URL: '',
        OS_TENANT_ID: '',
        OS_TENANT_NAME: '',
        OS_USERNAME: '',
        OS_USER_DOMAIN_NAME: '',
        ST_AUTH: '',
        ST_KEY: '',
        ST_USER: '',
      },
    },
  }

  // get specific feature details
  function getFeatureSetDetails() {
    const featureSets = storeGet('/cluster/featureSets/result') || []
    const featureSetName = storeGet('/route/params/featureset') || ''
    const featureSet = featureSets.find((item) => item?.metadata?.name === featureSetName)
    return featureSet
  }

  // get specific attribute's value of a feature
  function getFeatureSetPropertyValue(path) {
    const featureSet = getFeatureSetDetails()
    const value = storeGet(path, featureSet)
    return value
  }

  function getFeatureSetDescription() {
    const description = getFeatureSetPropertyValue('/spec/description')
    return description
  }

  // get specific feature details
  function getFeatureDetails(name) {
    const features = storeGet('/cluster/features/result') || []
    const feature = features.find((item) => item?.metadata?.name === name)
    return feature
  }

  // get specific attribute's value of a feature
  function getFeaturePropertyValue(name, path) {
    const feature = getFeatureDetails(name)
    const value = storeGet(path, feature)
    return value
  }

  function isEqualToModelPathValue(path, value) {
    const modelValue = getValue(model, path)
    return modelValue === value
  }

  function isFeatureRequired(featureName) {
    const featureSet = getFeatureSetDetails()
    const requiredFeatures = featureSet?.spec?.requiredFeatures || []
    const isRequired = requiredFeatures.includes(featureName)
    return isRequired
  }

  function getEnabledFeatureInConfigureBtnClick(allFeatureSetFeature, isBlockLevel) {
    const featureBlock = storeGet('/route/query/activeBlock') || ''
    const enabledFeatures = allFeatureSetFeature.filter((item) => {
      const featureName = item?.metadata?.name
      return (
        item?.status?.enabled ||
        isFeatureRequired(storeGet, featureName) ||
        (isBlockLevel && item?.spec?.featureBlock === featureBlock && item?.spec?.recommended)
      )
    })
    const enabledFeatureNames = enabledFeatures.map((item) => item?.metadata?.name) || []
    return enabledFeatureNames
  }

  function getEnabledFeatureInEnableBtnClick(allFeatureSetFeature, isBlockLevel) {
    // filter only (enabled + required + feature block feature)
    const featureBlock = storeGet('/route/query/activeBlock') || ''

    // for OCM

    const getRoute = storeGet('/route')
    const FeatureList = storeGet('/ocm/featureSet/')
    const FeatureSet = storeGet('/route/params/featureset')

    if (getRoute.fullPath.includes('/hubs/')) {
      const selectedFeatureSet =
        FeatureList.result?.filter((item) => {
          return item.name === FeatureSet
        }) || []
      const checkedFeatures =
        selectedFeatureSet[0].features.filter((item) => {
          return item.installed || item.recommended
        }) || []
      const checkedFeatureName =
        checkedFeatures.map((item) => {
          return item.name
        }) || []
      checkedFeatureName.push(featureBlock)
      return checkedFeatureName
    }

    const isRecommendedFeatureAvailable = allFeatureSetFeature.some((item) => {
      return item?.spec?.featureBlock === featureBlock && item?.spec?.recommended
    })
    const enabledFeatures = allFeatureSetFeature.filter((item) => {
      const featureName = item?.metadata?.name

      if (isBlockLevel) {
        if (isRecommendedFeatureAvailable) {
          return (
            item?.status?.enabled ||
            isFeatureRequired(storeGet, featureName) ||
            (item?.spec?.featureBlock === featureBlock && item?.spec?.recommended === true)
          )
        } else {
          return (
            item?.status?.enabled ||
            isFeatureRequired(storeGet, featureName) ||
            item?.spec?.featureBlock === featureBlock
          )
        }
      } else {
        return (
          item?.status?.enabled ||
          item?.spec?.recommended ||
          isFeatureRequired(storeGet, featureName)
        )
      }
    })
    const enabledFeatureNames = enabledFeatures.map((item) => item?.metadata?.name) || []
    return enabledFeatureNames
  }

  function getEnabledFeaturesFromActiveFeature(allFeatureSetFeature) {
    const activeFeature = storeGet('/route/query/activeFeature') || ''

    const enabledFeatures = allFeatureSetFeature.filter((item) => {
      const featureName = item?.metadata?.name
      return (
        item?.status?.enabled ||
        isFeatureRequired(storeGet, featureName) ||
        item?.spec?.recommended ||
        featureName === activeFeature
      )
    })
    const enabledFeatureNames = enabledFeatures.map((item) => item?.metadata?.name) || []

    return enabledFeatureNames
  }

  function getEnabledFeatures() {
    // fire computed function only on modal startup
    if (!enabledFeaturesChanged) {
      const allFeatures = storeGet('/cluster/features/result') || []
      const featureSet = storeGet('/route/params/featureset') || []
      const featureBlock = storeGet('/route/query/activeBlock') || ''
      const configureMode = storeGet('/route/query/mode') || ''
      const activeFeature = storeGet('/route/query/activeFeature') || ''

      const allFeatureSetFeature =
        allFeatures.filter((item) => {
          return item?.spec?.featureSet === featureSet
        }) || []

      if (activeFeature) {
        return getEnabledFeaturesFromActiveFeature(allFeatureSetFeature, storeGet)
      }

      if (featureBlock) {
        //feature block level
        if (configureMode) {
          // configure btn
          return getEnabledFeatureInConfigureBtnClick(allFeatureSetFeature, true, storeGet)
        } else {
          // enable btn
          return getEnabledFeatureInEnableBtnClick(allFeatureSetFeature, true, storeGet)
        }
      } else {
        // feature set level
        if (configureMode) {
          // configure btn
          return getEnabledFeatureInConfigureBtnClick(allFeatureSetFeature, false, storeGet)
        } else {
          // enable btn
          return getEnabledFeatureInEnableBtnClick(allFeatureSetFeature, false, storeGet)
        }
      }
    }
  }

  function disableFeatures(value) {
    // watchDependency('discriminator#/isResourceLoaded')

    const isResourceLoaded = getValue(discriminator, '/isResourceLoaded')
    if (!isResourceLoaded) return true

    const featureName = value
    const featureSet = getFeatureSetDetails()
    const requiredFeatures = featureSet?.spec?.requiredFeatures || []

    if (requiredFeatures.includes(featureName)) return true
    else return false
  }

  function getResourceValuePathFromFeature(feature) {
    const featureName = feature?.metadata?.name || ''
    const underscoredFeatureName = featureName.toLowerCase().replaceAll('-', '_')
    const resourceValuePath = `helmToolkitFluxcdIoHelmRelease_${underscoredFeatureName}`
    return resourceValuePath
  }

  function onEnabledFeaturesChange() {
    const enabledFeatures = getValue(discriminator, '/enabledFeatures') || []

    const allFeatures = storeGet('/cluster/features/result') || []

    allFeatures.forEach((item) => {
      const featureName = item?.metadata?.name || ''
      const resourceValuePath = getResourceValuePathFromFeature(item)

      if (enabledFeatures.includes(featureName)) {
        const featureSet = storeGet('/route/params/featureset') || ''
        const chart = getFeaturePropertyValue(storeGet, featureName, getValue, '/spec/chart/name')
        const targetNamespace = getFeaturePropertyValue(
          storeGet,
          featureName,
          getValue,
          '/spec/chart/namespace',
        )
        const sourceRef = getFeaturePropertyValue(
          storeGet,
          featureName,
          getValue,
          '/spec/chart/sourceRef',
        )
        const version = getFeaturePropertyValue(
          storeGet,
          featureName,
          getValue,
          '/spec/chart/version',
        )

        const isEnabled = getFeaturePropertyValue(featureName, '/status/enabled')
        const isManaged = getFeaturePropertyValue(featureName, '/status/managed')

        if (isEnabled && !isManaged) {
          commit('wizard/model$delete', `/resources/${resourceValuePath}`)
        } else {
          commit('wizard/model$update', {
            path: `/resources/${resourceValuePath}`,
            value: {
              ...resources?.[resourceValuePath],
              metadata: {
                ...resources?.[resourceValuePath]?.metadata,
                labels: {
                  ...resources?.[resourceValuePath]?.metadata?.labels,
                  'app.kubernetes.io/component': featureName,
                  'app.kubernetes.io/part-of': featureSet,
                },
              },
              spec: {
                ...resources?.[resourceValuePath]?.spec,
                chart: {
                  spec: {
                    chart,
                    sourceRef,
                    version,
                  },
                },
                targetNamespace,
              },
            },
            force: true,
          })
        }
      } else {
        commit('wizard/model$delete', `/resources/${resourceValuePath}`)
      }
    })
  }

  function returnFalse() {
    return false
  }

  async function setReleaseNameAndNamespaceAndInitializeValues() {
    const modelResources = getValue(model, '/resources')
    resources = { ...modelResources }

    const isFeatureSetInstalled = getFeatureSetPropertyValue('/status/enabled')

    if (isFeatureSetInstalled) {
      // get resources default values when featureset is installed
      const owner = storeGet('/route/params/user')
      const cluster = storeGet('/route/params/cluster')
      const clusterset = storeGet('route/params/clusterset')
      const spoke = storeGet('/route/params/spoke')

      const {
        name: chartName,
        sourceRef,
        version: chartVersion,
      } = getFeatureSetPropertyValue('/spec/chart')
      let url =
        `/clusters/${owner}/${cluster}/helm/packageview/values?name=${chartName}&sourceApiGroup=${sourceRef.apiGroup}&sourceKind=${sourceRef.kind}&sourceNamespace=${sourceRef.namespace}&sourceName=${sourceRef.name}&version=${chartVersion}&format=json` +
        (clusterset ? `&clusterset=${clusterset}` : '')
      if (spoke)
        url = `/clusters/${owner}/${spoke}/helm/packageview/values?name=${chartName}&sourceApiGroup=${sourceRef.apiGroup}&sourceKind=${sourceRef.kind}&sourceNamespace=${sourceRef.namespace}&sourceName=${sourceRef.name}&version=${chartVersion}&format=json`
      const { data } = await axios.get(url)
      const { resources: resourcesDefaultValues } = data || {}

      Object.keys(resourcesDefaultValues || {}).forEach((key) => {
        if (!resources[key]) {
          resources[key] = resourcesDefaultValues[key]
        }
      })
    }
    const featureSet = storeGet('/route/params/featureset')
    commit('wizard/model$update', {
      path: '/metadata/release',
      value: {
        name: featureSet,
        namespace: 'kubeops',
      },
      force: true,
    })

    // delete extra values from model if the feature does not exist
    const allFeatures = storeGet('/cluster/features/result') || []
    const allFeatureResourceValuePathNames = allFeatures.map((feature) =>
      getResourceValuePathFromFeature(feature),
    )
    Object.keys(modelResources).forEach((modelResourcePath) => {
      if (!allFeatureResourceValuePathNames.includes(modelResourcePath)) {
        // model path does not exist in feature values
        // remove the model path
        commit('wizard/model$delete', `/resources/${modelResourcePath}`)
      }
    })

    setDiscriminatorValue('/isResourceLoaded', true)
  }

  function fetchFeatureSetOptions() {
    const features = storeGet('/cluster/features/result') || []
    const featureSetName = storeGet('/route/params/featureset')
    const filteredFeatures = features.filter((item) => item?.spec?.featureSet === featureSetName)
    const options = filteredFeatures.map((item) => {
      const { spec, metadata } = item || {}
      const { title, description, required } = spec || {}
      const { name } = metadata || {}
      return {
        text: title,
        value: name,
        description: description,
        statusTag: {
          text: required ? 'Required' : '',
        },
      }
    })

    return options || []
  }

  // this element is is used only to catch discriminator value
  // It is not used in create-ui to get or store value
  function hideThisElement() {
    return false
  }

  // this computed's main purpose is to watch isResourceLoaded flag
  // and fire the onEnabledFeatureChange function when it's true
  function checkIsResourceLoaded() {
    const isResourceLoaded = getValue(discriminator, '/isResourceLoaded')
    if (isResourceLoaded) {
      onEnabledFeaturesChange()
    }
  }

  function isStashPreset() {
    const enabledFeatures = getValue(discriminator, '/enabledFeatures') || []
    if (enabledFeatures?.includes('stash-presets') && enabledFeatures?.includes('kubestash')) {
      setTool()
      return true
    } else {
      commit('wizard/model$update', {
        path: '/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/tool',
        value: '',
        force: true,
      })
      return false
    }
  }

  function presetType(value) {
    const presetType = getValue(
      model,
      '/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/tool',
    )
    const enabledFeatures = getValue(discriminator, '/enabledFeatures') || []
    if (!enabledFeatures?.includes(value)) {
      return false
    }
    if (presetType?.toLowerCase() === value) return true
  }

  function providerType(value) {
    const presetType = getValue(
      model,
      '/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/tool',
    )?.toLowerCase()

    const provider = getValue(
      model,
      `/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/${presetType}/backend/provider`,
    )
    return provider === value
  }

  function authEnabled() {
    const presetType = getValue(
      model,
      '/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/tool',
    )?.toLowerCase()

    const isEnabled = getValue(
      model,
      `/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/${presetType}/storageSecret/create`,
    )
    return isEnabled
  }

  function initPrune() {
    const prune = getValue(
      model,
      `/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/stash/retentionPolicy/prune`,
    )
    return prune ? prune : false
  }

  function setTool() {
    commit('wizard/model$update', {
      path: '/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/tool',
      value: 'KubeStash',
      force: true,
    })
    return 'KubeStash'
  }

  function setProvider() {
    const provider = getValue(
      model,
      `/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/kubestash/backend/provider`,
    )
    if (provider === undefined) {
      return 's3'
    }
    return provider
  }

  function setStorageSecret() {
    const secret = getValue(
      model,
      '/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/kubestash/storageSecret/create',
    )
    return secret
  }

  function onAuthChange(type) {
    const auth = getValue(discriminator, `/${type}`) || false
    commit('wizard/model$update', {
      path: '/resources/helmToolkitFluxcdIoHelmRelease_stash_presets/spec/values/kubestash/storageSecret/create',
      value: auth,
      force: true,
    })
  }

  async function fetchJsons(itemCtx) {
    let ui = {}
    let language = {}
    let functions = {}
    const { name, sourceRef, version, packageviewUrlPrefix } = itemCtx.chart

    try {
      ui = await axios.get(
        `${packageviewUrlPrefix}/create-ui.yaml?name=${name}&sourceApiGroup=${sourceRef.apiGroup}&sourceKind=${sourceRef.kind}&sourceNamespace=${sourceRef.namespace}&sourceName=${sourceRef.name}&version=${version}&format=json`,
      )
      language = await axios.get(
        `${packageviewUrlPrefix}/language.yaml?name=${name}&sourceApiGroup=${sourceRef.apiGroup}&sourceKind=${sourceRef.kind}&sourceNamespace=${sourceRef.namespace}&sourceName=${sourceRef.name}&version=${version}&format=json`,
      )
      const functionString = await axios.get(
        `${packageviewUrlPrefix}/functions.js?name=${name}&sourceApiGroup=${sourceRef.apiGroup}&sourceKind=${sourceRef.kind}&sourceNamespace=${sourceRef.namespace}&sourceName=${sourceRef.name}&version=${version}`,
      )
      // declare evaluate the functionString to get the functions Object
      const evalFunc = new Function(functionString.data || '')
      functions = evalFunc()
    } catch (e) {
      console.log(e)
    }

    return {
      ui: ui.data || {},
      language: language.data || {},
      functions,
    }
  }

  return {
    hideThisElement,
    checkIsResourceLoaded,
    getFeatureSetDetails,
    getFeatureSetPropertyValue,
    getFeatureSetDescription,
    isEqualToModelPathValue,
    getEnabledFeatures,
    disableFeatures,
    onEnabledFeaturesChange,
    returnFalse,
    setReleaseNameAndNamespaceAndInitializeValues,
    fetchFeatureSetOptions,
    isStashPreset,
    presetType,
    providerType,
    authEnabled,
    initPrune,
    fetchJsons,
    setTool,
    setProvider,
    setStorageSecret,
    onAuthChange,
  }
}
