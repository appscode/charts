# Weaviate Editor

[Weaviate Editor by AppsCode](https://appscode.com) - Weaviate Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-weaviate-editor --version=v0.36.0
$ helm upgrade -i kubedbcom-weaviate-editor appscode/kubedbcom-weaviate-editor -n default --create-namespace --version=v0.36.0
```

## Introduction

This chart deploys a Weaviate Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-weaviate-editor`:

```bash
$ helm upgrade -i kubedbcom-weaviate-editor appscode/kubedbcom-weaviate-editor -n default --create-namespace --version=v0.36.0
```

The command deploys a Weaviate Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-weaviate-editor`:

```bash
$ helm uninstall kubedbcom-weaviate-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-weaviate-editor` chart and their default values.

|                    Parameter                     | Description |                                                                   Default                                                                   |
|--------------------------------------------------|-------------|---------------------------------------------------------------------------------------------------------------------------------------------|
| metadata.resource.group                          |             | <code>kubedb.com</code>                                                                                                                     |
| metadata.resource.version                        |             | <code>v1alpha2</code>                                                                                                                       |
| metadata.resource.name                           |             | <code>weaviates</code>                                                                                                                      |
| metadata.resource.kind                           |             | <code>Weaviate</code>                                                                                                                       |
| metadata.resource.scope                          |             | <code>Namespaced</code>                                                                                                                     |
| metadata.release.name                            |             | <code>RELEASE-NAME</code>                                                                                                                   |
| metadata.release.namespace                       |             | <code>default</code>                                                                                                                        |
| resources.autoscalingKubedbComWeaviateAutoscaler |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"WeaviateAutoscaler","metadata":{"name":"weaviate","namespace":"demo"}}</code> |
| resources.kubedbComWeaviate                      |             | <code>{"apiVersion":"kubedb.com/v1alpha2","kind":"Weaviate","metadata":{"name":"weaviate","namespace":"default"}}</code>                    |
| resources.secret_auth                            |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"weaviate-auth","namespace":"demo"}}</code>                                     |
| resources.secret_config                          |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"weaviate-config","namespace":"demo"}}</code>                                   |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-weaviate-editor appscode/kubedbcom-weaviate-editor -n default --create-namespace --version=v0.36.0 --set metadata.resource.group=kubedb.com
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-weaviate-editor appscode/kubedbcom-weaviate-editor -n default --create-namespace --version=v0.36.0 --values values.yaml
```
