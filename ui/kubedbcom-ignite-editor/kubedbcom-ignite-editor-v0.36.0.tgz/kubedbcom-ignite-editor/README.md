# Ignite Editor

[Ignite Editor by AppsCode](https://appscode.com) - Ignite Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-ignite-editor --version=v0.36.0
$ helm upgrade -i kubedbcom-ignite-editor appscode/kubedbcom-ignite-editor -n default --create-namespace --version=v0.36.0
```

## Introduction

This chart deploys a Ignite Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-ignite-editor`:

```bash
$ helm upgrade -i kubedbcom-ignite-editor appscode/kubedbcom-ignite-editor -n default --create-namespace --version=v0.36.0
```

The command deploys a Ignite Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-ignite-editor`:

```bash
$ helm uninstall kubedbcom-ignite-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-ignite-editor` chart and their default values.

|                                   Parameter                                   | Description |                                                                 Default                                                                 |
|-------------------------------------------------------------------------------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                               |             | <code>{}</code>                                                                                                                         |
| form.alert.annotations                                                        |             | <code>{}</code>                                                                                                                         |
| form.alert.enabled                                                            |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.enabled                                            |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.diskAlmostFull.duration                      |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.diskAlmostFull.enabled                       |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.diskAlmostFull.severity                      |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.diskAlmostFull.val                           |             | <code>95</code>                                                                                                                         |
| form.alert.groups.database.rules.diskUsageHigh.duration                       |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.diskUsageHigh.enabled                        |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.diskUsageHigh.severity                       |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.diskUsageHigh.val                            |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.igniteClusterNoBaselineNode.duration         |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.igniteClusterNoBaselineNode.enabled          |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.igniteClusterNoBaselineNode.severity         |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.igniteClusterNoBaselineNode.val              |             | <code>0</code>                                                                                                                          |
| form.alert.groups.database.rules.igniteDown.duration                          |             | <code>30s</code>                                                                                                                        |
| form.alert.groups.database.rules.igniteDown.enabled                           |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.igniteDown.severity                          |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.igniteHighCPULoad.duration                   |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.igniteHighCPULoad.enabled                    |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.igniteHighCPULoad.severity                   |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.igniteHighCPULoad.val                        |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.igniteHighDataregionOffHeapUsed.duration     |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.igniteHighDataregionOffHeapUsed.enabled      |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.igniteHighDataregionOffHeapUsed.severity     |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.igniteHighDataregionOffHeapUsed.val          |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.igniteHighHeapMemoryUsed.duration            |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.igniteHighHeapMemoryUsed.enabled             |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.igniteHighHeapMemoryUsed.severity            |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.igniteHighHeapMemoryUsed.val                 |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.igniteJVMPausesTotalDuration.duration        |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.igniteJVMPausesTotalDuration.enabled         |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.igniteJVMPausesTotalDuration.severity        |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.igniteJVMPausesTotalDuration.val             |             | <code>0</code>                                                                                                                          |
| form.alert.groups.database.rules.ignitePhaseCritical.duration                 |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.ignitePhaseCritical.enabled                  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.ignitePhaseCritical.severity                 |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.igniteRestarted.duration                     |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.igniteRestarted.enabled                      |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.igniteRestarted.severity                     |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.igniteRestarted.val                          |             | <code>180</code>                                                                                                                        |
| form.alert.groups.opsManager.enabled                                          |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.opsManager.rules.opsRequestFailed.duration                  |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.opsManager.rules.opsRequestFailed.enabled                   |             | <code>true</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestFailed.severity                  |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.duration              |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.enabled               |             | <code>true</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.severity              |             | <code>info</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.duration |             | <code>30m</code>                                                                                                                        |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.enabled  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.severity |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.provisioner.enabled                                         |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration                 |             | <code>15m</code>                                                                                                                        |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled                  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity                 |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration                 |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled                  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity                 |             | <code>critical</code>                                                                                                                   |
| form.alert.labels.release                                                     |             | <code>kube-prometheus-stack</code>                                                                                                      |
| metadata.resource.group                                                       |             | <code>kubedb.com</code>                                                                                                                 |
| metadata.resource.version                                                     |             | <code>v1alpha2</code>                                                                                                                   |
| metadata.resource.name                                                        |             | <code>ignites</code>                                                                                                                    |
| metadata.resource.kind                                                        |             | <code>Ignite</code>                                                                                                                     |
| metadata.resource.scope                                                       |             | <code>Namespaced</code>                                                                                                                 |
| metadata.release.name                                                         |             | <code>RELEASE-NAME</code>                                                                                                               |
| metadata.release.namespace                                                    |             | <code>default</code>                                                                                                                    |
| resources.autoscalingKubedbComIgniteAutoscaler                                |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"IgniteAutoscaler","metadata":{"name":"ignite","namespace":"demo"}}</code> |
| resources.certManagerIoIssuer_ca                                              |             | <code>{"apiVersion":"cert-manager.io/v1","kind":"Issuer","metadata":{"name":"ignite-ca","namespace":"demo"}}</code>                     |
| resources.kubedbComIgnite                                                     |             | <code>{"apiVersion":"kubedb.com/v1alpha2","kind":"Ignite","metadata":{"name":"ignite","namespace":"ignite"}}</code>                     |
| resources.monitoringCoreosComServiceMonitor                                   |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"ignite","namespace":"demo"}}</code>          |
| resources.secret_auth                                                         |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"ignite-auth","namespace":"demo"}}</code>                                   |
| resources.secret_config                                                       |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"ignite-config","namespace":"demo"}}</code>                                 |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-ignite-editor appscode/kubedbcom-ignite-editor -n default --create-namespace --version=v0.36.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-ignite-editor appscode/kubedbcom-ignite-editor -n default --create-namespace --version=v0.36.0 --values values.yaml
```
