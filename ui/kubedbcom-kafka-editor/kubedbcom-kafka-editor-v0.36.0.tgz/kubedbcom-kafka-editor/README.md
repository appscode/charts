# Kafka Editor

[Kafka Editor by AppsCode](https://appscode.com) - Kafka Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-kafka-editor --version=v0.36.0
$ helm upgrade -i kubedbcom-kafka-editor appscode/kubedbcom-kafka-editor -n default --create-namespace --version=v0.36.0
```

## Introduction

This chart deploys a Kafka Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-kafka-editor`:

```bash
$ helm upgrade -i kubedbcom-kafka-editor appscode/kubedbcom-kafka-editor -n default --create-namespace --version=v0.36.0
```

The command deploys a Kafka Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-kafka-editor`:

```bash
$ helm uninstall kubedbcom-kafka-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-kafka-editor` chart and their default values.

|                                   Parameter                                   | Description |                                                                Default                                                                |
|-------------------------------------------------------------------------------|-------------|---------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                               |             | <code>{}</code>                                                                                                                       |
| form.alert.annotations                                                        |             | <code>{}</code>                                                                                                                       |
| form.alert.enabled                                                            |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.enabled                                            |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.diskAlmostFull.duration                      |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.diskAlmostFull.enabled                       |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.diskAlmostFull.severity                      |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.database.rules.diskAlmostFull.val                           |             | <code>95</code>                                                                                                                       |
| form.alert.groups.database.rules.diskUsageHigh.duration                       |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.diskUsageHigh.enabled                        |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.diskUsageHigh.severity                       |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.diskUsageHigh.val                            |             | <code>80</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaAbnormalControllerState.duration        |             | <code>10s</code>                                                                                                                      |
| form.alert.groups.database.rules.kafkaAbnormalControllerState.enabled         |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaAbnormalControllerState.severity        |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.kafkaAbnormalControllerState.val             |             | <code>1</code>                                                                                                                        |
| form.alert.groups.database.rules.kafkaBrokerCount.duration                    |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaBrokerCount.enabled                     |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaBrokerCount.severity                    |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.database.rules.kafkaBrokerCount.val                         |             | <code>0</code>                                                                                                                        |
| form.alert.groups.database.rules.kafkaDown.duration                           |             | <code>30s</code>                                                                                                                      |
| form.alert.groups.database.rules.kafkaDown.enabled                            |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaDown.severity                           |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.database.rules.kafkaISRExpandRate.duration                  |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaISRExpandRate.enabled                   |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaISRExpandRate.severity                  |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.kafkaISRExpandRate.val                       |             | <code>0</code>                                                                                                                        |
| form.alert.groups.database.rules.kafkaISRShrinkRate.duration                  |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaISRShrinkRate.enabled                   |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaISRShrinkRate.severity                  |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.kafkaISRShrinkRate.val                       |             | <code>0</code>                                                                                                                        |
| form.alert.groups.database.rules.kafkaNetworkProcessorIdlePercent.duration    |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaNetworkProcessorIdlePercent.enabled     |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaNetworkProcessorIdlePercent.severity    |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.database.rules.kafkaNetworkProcessorIdlePercent.val         |             | <code>30</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaOfflineLogDirectoryCount.duration       |             | <code>10s</code>                                                                                                                      |
| form.alert.groups.database.rules.kafkaOfflineLogDirectoryCount.enabled        |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaOfflineLogDirectoryCount.severity       |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.kafkaOfflineLogDirectoryCount.val            |             | <code>0</code>                                                                                                                        |
| form.alert.groups.database.rules.kafkaOfflinePartitions.duration              |             | <code>10s</code>                                                                                                                      |
| form.alert.groups.database.rules.kafkaOfflinePartitions.enabled               |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaOfflinePartitions.severity              |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.kafkaOfflinePartitions.val                   |             | <code>0</code>                                                                                                                        |
| form.alert.groups.database.rules.kafkaPhaseCritical.duration                  |             | <code>3m</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaPhaseCritical.enabled                   |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaPhaseCritical.severity                  |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.kafkaReplicaFetcherManagerMaxLag.duration    |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaReplicaFetcherManagerMaxLag.enabled     |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaReplicaFetcherManagerMaxLag.severity    |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.database.rules.kafkaReplicaFetcherManagerMaxLag.val         |             | <code>50</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaRequestHandlerIdlePercent.duration      |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaRequestHandlerIdlePercent.enabled       |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaRequestHandlerIdlePercent.severity      |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.database.rules.kafkaRequestHandlerIdlePercent.val           |             | <code>30</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaTopicCount.duration                     |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.database.rules.kafkaTopicCount.enabled                      |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaTopicCount.severity                     |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.kafkaTopicCount.val                          |             | <code>1000</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaUnderMinIsrPartitionCount.duration      |             | <code>10s</code>                                                                                                                      |
| form.alert.groups.database.rules.kafkaUnderMinIsrPartitionCount.enabled       |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaUnderMinIsrPartitionCount.severity      |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.kafkaUnderMinIsrPartitionCount.val           |             | <code>0</code>                                                                                                                        |
| form.alert.groups.database.rules.kafkaUnderReplicatedPartitions.duration      |             | <code>10s</code>                                                                                                                      |
| form.alert.groups.database.rules.kafkaUnderReplicatedPartitions.enabled       |             | <code>true</code>                                                                                                                     |
| form.alert.groups.database.rules.kafkaUnderReplicatedPartitions.severity      |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.database.rules.kafkaUnderReplicatedPartitions.val           |             | <code>0</code>                                                                                                                        |
| form.alert.groups.opsManager.enabled                                          |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.opsManager.rules.opsRequestFailed.duration                  |             | <code>0m</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestFailed.enabled                   |             | <code>true</code>                                                                                                                     |
| form.alert.groups.opsManager.rules.opsRequestFailed.severity                  |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.duration              |             | <code>0m</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.enabled               |             | <code>true</code>                                                                                                                     |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.severity              |             | <code>info</code>                                                                                                                     |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.duration |             | <code>30m</code>                                                                                                                      |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.enabled  |             | <code>true</code>                                                                                                                     |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.severity |             | <code>critical</code>                                                                                                                 |
| form.alert.groups.provisioner.enabled                                         |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration                 |             | <code>15m</code>                                                                                                                      |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled                  |             | <code>true</code>                                                                                                                     |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity                 |             | <code>warning</code>                                                                                                                  |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration                 |             | <code>1m</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled                  |             | <code>true</code>                                                                                                                     |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity                 |             | <code>critical</code>                                                                                                                 |
| form.alert.labels.release                                                     |             | <code>kube-prometheus-stack</code>                                                                                                    |
| metadata.resource.group                                                       |             | <code>kubedb.com</code>                                                                                                               |
| metadata.resource.version                                                     |             | <code>v1</code>                                                                                                                       |
| metadata.resource.name                                                        |             | <code>kafkas</code>                                                                                                                   |
| metadata.resource.kind                                                        |             | <code>Kafka</code>                                                                                                                    |
| metadata.resource.scope                                                       |             | <code>Namespaced</code>                                                                                                               |
| metadata.release.name                                                         |             | <code>RELEASE-NAME</code>                                                                                                             |
| metadata.release.namespace                                                    |             | <code>default</code>                                                                                                                  |
| resources.autoscalingKubedbComKafkaAutoscaler                                 |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"KafkaAutoscaler","metadata":{"name":"kafka","namespace":"demo"}}</code> |
| resources.catalogAppscodeComKafkaBinding                                      |             | <code>{"apiVersion":"catalog.appscode.com/v1alpha1","kind":"KafkaBinding","metadata":{"name":"kafka","namespace":"demo"}}</code>      |
| resources.gitopsKubedbComKafka                                                |             | <code>{"apiVersion":"gitops.kubedb.com/v1alpha1","kind":"Kafka","metadata":{"name":"kafka","namespace":"demo"}}</code>                |
| resources.kubedbComKafka                                                      |             | <code>{"apiVersion":"kubedb.com/v1","kind":"Kafka","metadata":{"name":"kafka","namespace":"demo"}}</code>                             |
| resources.monitoringCoreosComServiceMonitor                                   |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"kafka","namespace":"demo"}}</code>         |
| resources.secret_admin_cred                                                   |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"kafka-admin-cred","namespace":"demo"}}</code>                            |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-kafka-editor appscode/kubedbcom-kafka-editor -n default --create-namespace --version=v0.36.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-kafka-editor appscode/kubedbcom-kafka-editor -n default --create-namespace --version=v0.36.0 --values values.yaml
```
