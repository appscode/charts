# RabbitMQ Editor

[RabbitMQ Editor by AppsCode](https://appscode.com) - RabbitMQ Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-rabbitmq-editor --version=v0.37.0
$ helm upgrade -i kubedbcom-rabbitmq-editor appscode/kubedbcom-rabbitmq-editor -n default --create-namespace --version=v0.37.0
```

## Introduction

This chart deploys a RabbitMQ Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-rabbitmq-editor`:

```bash
$ helm upgrade -i kubedbcom-rabbitmq-editor appscode/kubedbcom-rabbitmq-editor -n default --create-namespace --version=v0.37.0
```

The command deploys a RabbitMQ Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-rabbitmq-editor`:

```bash
$ helm uninstall kubedbcom-rabbitmq-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-rabbitmq-editor` chart and their default values.

|                                            Parameter                                             | Description |                                                                   Default                                                                   |
|--------------------------------------------------------------------------------------------------|-------------|---------------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                                                  |             | <code>{}</code>                                                                                                                             |
| form.alert.annotations                                                                           |             | <code>{}</code>                                                                                                                             |
| form.alert.enabled                                                                               |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.database.enabled                                                               |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.database.rules.diskAlmostFull.duration                                         |             | <code>1m</code>                                                                                                                             |
| form.alert.groups.database.rules.diskAlmostFull.enabled                                          |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.diskAlmostFull.severity                                         |             | <code>critical</code>                                                                                                                       |
| form.alert.groups.database.rules.diskAlmostFull.val                                              |             | <code>95</code>                                                                                                                             |
| form.alert.groups.database.rules.diskUsageHigh.duration                                          |             | <code>1m</code>                                                                                                                             |
| form.alert.groups.database.rules.diskUsageHigh.enabled                                           |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.diskUsageHigh.severity                                          |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.database.rules.diskUsageHigh.val                                               |             | <code>80</code>                                                                                                                             |
| form.alert.groups.database.rules.rabbitmqDown.duration                                           |             | <code>30s</code>                                                                                                                            |
| form.alert.groups.database.rules.rabbitmqDown.enabled                                            |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.rabbitmqDown.severity                                           |             | <code>critical</code>                                                                                                                       |
| form.alert.groups.database.rules.rabbitmqFileDescriptorsNearLimit.duration                       |             | <code>30s</code>                                                                                                                            |
| form.alert.groups.database.rules.rabbitmqFileDescriptorsNearLimit.enabled                        |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.rabbitmqFileDescriptorsNearLimit.severity                       |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.database.rules.rabbitmqHighConnectionChurn.duration                            |             | <code>30s</code>                                                                                                                            |
| form.alert.groups.database.rules.rabbitmqHighConnectionChurn.enabled                             |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.rabbitmqHighConnectionChurn.severity                            |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.database.rules.rabbitmqInsufficientEstablishedErlangDistributionLinks.duration |             | <code>30s</code>                                                                                                                            |
| form.alert.groups.database.rules.rabbitmqInsufficientEstablishedErlangDistributionLinks.enabled  |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.rabbitmqInsufficientEstablishedErlangDistributionLinks.severity |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.database.rules.rabbitmqLowDiskWatermarkPredicted.duration                      |             | <code>30s</code>                                                                                                                            |
| form.alert.groups.database.rules.rabbitmqLowDiskWatermarkPredicted.enabled                       |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.rabbitmqLowDiskWatermarkPredicted.severity                      |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.database.rules.rabbitmqPhaseCritical.duration                                  |             | <code>3m</code>                                                                                                                             |
| form.alert.groups.database.rules.rabbitmqPhaseCritical.enabled                                   |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.rabbitmqPhaseCritical.severity                                  |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.database.rules.rabbitmqQueueIsGrowing.duration                                 |             | <code>30s</code>                                                                                                                            |
| form.alert.groups.database.rules.rabbitmqQueueIsGrowing.enabled                                  |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.rabbitmqQueueIsGrowing.severity                                 |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.database.rules.rabbitmqTCPSocketsNearLimit.duration                            |             | <code>30s</code>                                                                                                                            |
| form.alert.groups.database.rules.rabbitmqTCPSocketsNearLimit.enabled                             |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.rabbitmqTCPSocketsNearLimit.severity                            |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.database.rules.rabbitmqUnroutableMessages.duration                             |             | <code>30s</code>                                                                                                                            |
| form.alert.groups.database.rules.rabbitmqUnroutableMessages.enabled                              |             | <code>true</code>                                                                                                                           |
| form.alert.groups.database.rules.rabbitmqUnroutableMessages.severity                             |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.opsManager.enabled                                                             |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.opsManager.rules.opsRequestFailed.duration                                     |             | <code>0m</code>                                                                                                                             |
| form.alert.groups.opsManager.rules.opsRequestFailed.enabled                                      |             | <code>true</code>                                                                                                                           |
| form.alert.groups.opsManager.rules.opsRequestFailed.severity                                     |             | <code>critical</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.duration                                 |             | <code>0m</code>                                                                                                                             |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.enabled                                  |             | <code>true</code>                                                                                                                           |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.severity                                 |             | <code>info</code>                                                                                                                           |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.duration                    |             | <code>30m</code>                                                                                                                            |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.enabled                     |             | <code>true</code>                                                                                                                           |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.severity                    |             | <code>critical</code>                                                                                                                       |
| form.alert.groups.provisioner.enabled                                                            |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration                                    |             | <code>15m</code>                                                                                                                            |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled                                     |             | <code>true</code>                                                                                                                           |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity                                    |             | <code>warning</code>                                                                                                                        |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration                                    |             | <code>1m</code>                                                                                                                             |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled                                     |             | <code>true</code>                                                                                                                           |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity                                    |             | <code>critical</code>                                                                                                                       |
| form.alert.labels.release                                                                        |             | <code>kube-prometheus-stack</code>                                                                                                          |
| metadata.resource.group                                                                          |             | <code>kubedb.com</code>                                                                                                                     |
| metadata.resource.version                                                                        |             | <code>v1alpha2</code>                                                                                                                       |
| metadata.resource.name                                                                           |             | <code>rabbitmqs</code>                                                                                                                      |
| metadata.resource.kind                                                                           |             | <code>RabbitMQ</code>                                                                                                                       |
| metadata.resource.scope                                                                          |             | <code>Namespaced</code>                                                                                                                     |
| metadata.release.name                                                                            |             | <code>RELEASE-NAME</code>                                                                                                                   |
| metadata.release.namespace                                                                       |             | <code>default</code>                                                                                                                        |
| resources.autoscalingKubedbComRabbitMQAutoscaler                                                 |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"RabbitMQAutoscaler","metadata":{"name":"rabbitmq","namespace":"demo"}}</code> |
| resources.catalogAppscodeComRabbitMQBinding                                                      |             | <code>{"apiVersion":"catalog.appscode.com/v1alpha1","kind":"RabbitMQBinding","metadata":{"name":"rabbitmq","namespace":"demo"}}</code>      |
| resources.certManagerIoIssuer_ca                                                                 |             | <code>{"apiVersion":"cert-manager.io/v1","kind":"Issuer","metadata":{"name":"rabbitmq-ca","namespace":"demo"}}</code>                       |
| resources.gitopsKubedbComRabbitMQ                                                                |             | <code>{"apiVersion":"gitops.kubedb.com/v1alpha1","kind":"RabbitMQ","metadata":{"name":"rabbitmq","namespace":"sdb"}}</code>                 |
| resources.kubedbComRabbitMQ                                                                      |             | <code>{"apiVersion":"kubedb.com/v1alpha2","kind":"RabbitMQ","metadata":{"name":"rabbitmq","namespace":"sdb"}}</code>                        |
| resources.monitoringCoreosComServiceMonitor                                                      |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"rabbitmq","namespace":"demo"}}</code>            |
| resources.secret_auth                                                                            |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"rabbitmq-auth","namespace":"demo"}}</code>                                     |
| resources.secret_config                                                                          |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"rabbitmq-config","namespace":"demo"}}</code>                                   |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-rabbitmq-editor appscode/kubedbcom-rabbitmq-editor -n default --create-namespace --version=v0.37.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-rabbitmq-editor appscode/kubedbcom-rabbitmq-editor -n default --create-namespace --version=v0.37.0 --values values.yaml
```
