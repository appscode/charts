# EndpointSlice Editor

[EndpointSlice Editor by AppsCode](https://appscode.com) - EndpointSlice Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/discoveryk8sio-endpointslice-editor --version=v0.32.0
$ helm upgrade -i discoveryk8sio-endpointslice-editor appscode/discoveryk8sio-endpointslice-editor -n default --create-namespace --version=v0.32.0
```

## Introduction

This chart deploys a EndpointSlice Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `discoveryk8sio-endpointslice-editor`:

```bash
$ helm upgrade -i discoveryk8sio-endpointslice-editor appscode/discoveryk8sio-endpointslice-editor -n default --create-namespace --version=v0.32.0
```

The command deploys a EndpointSlice Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `discoveryk8sio-endpointslice-editor`:

```bash
$ helm uninstall discoveryk8sio-endpointslice-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `discoveryk8sio-endpointslice-editor` chart and their default values.

|     Parameter      | Description |             Default              |
|--------------------|-------------|----------------------------------|
| apiVersion         |             | <code>discovery.k8s.io/v1</code> |
| kind               |             | <code>EndpointSlice</code>       |
| metadata.name      |             | <code>endpointslice</code>       |
| metadata.namespace |             | <code>default</code>             |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i discoveryk8sio-endpointslice-editor appscode/discoveryk8sio-endpointslice-editor -n default --create-namespace --version=v0.32.0 --set apiVersion=discovery.k8s.io/v1
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i discoveryk8sio-endpointslice-editor appscode/discoveryk8sio-endpointslice-editor -n default --create-namespace --version=v0.32.0 --values values.yaml
```
