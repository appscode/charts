# Solr Editor

[Solr Editor by AppsCode](https://appscode.com) - Solr Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-solr-editor --version=v0.36.0
$ helm upgrade -i kubedbcom-solr-editor appscode/kubedbcom-solr-editor -n default --create-namespace --version=v0.36.0
```

## Introduction

This chart deploys a Solr Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-solr-editor`:

```bash
$ helm upgrade -i kubedbcom-solr-editor appscode/kubedbcom-solr-editor -n default --create-namespace --version=v0.36.0
```

The command deploys a Solr Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-solr-editor`:

```bash
$ helm uninstall kubedbcom-solr-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-solr-editor` chart and their default values.

|                                   Parameter                                   | Description |                                                               Default                                                                |
|-------------------------------------------------------------------------------|-------------|--------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                               |             | <code>{}</code>                                                                                                                      |
| form.alert.annotations                                                        |             | <code>{}</code>                                                                                                                      |
| form.alert.enabled                                                            |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.database.enabled                                            |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.database.rules.diskAlmostFull.duration                      |             | <code>1m</code>                                                                                                                      |
| form.alert.groups.database.rules.diskAlmostFull.enabled                       |             | <code>true</code>                                                                                                                    |
| form.alert.groups.database.rules.diskAlmostFull.severity                      |             | <code>critical</code>                                                                                                                |
| form.alert.groups.database.rules.diskAlmostFull.val                           |             | <code>95</code>                                                                                                                      |
| form.alert.groups.database.rules.diskUsageHigh.duration                       |             | <code>1m</code>                                                                                                                      |
| form.alert.groups.database.rules.diskUsageHigh.enabled                        |             | <code>true</code>                                                                                                                    |
| form.alert.groups.database.rules.diskUsageHigh.severity                       |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.database.rules.diskUsageHigh.val                            |             | <code>80</code>                                                                                                                      |
| form.alert.groups.database.rules.solrDownShards.duration                      |             | <code>30s</code>                                                                                                                     |
| form.alert.groups.database.rules.solrDownShards.enabled                       |             | <code>true</code>                                                                                                                    |
| form.alert.groups.database.rules.solrDownShards.severity                      |             | <code>critical</code>                                                                                                                |
| form.alert.groups.database.rules.solrDownShards.val                           |             | <code>0</code>                                                                                                                       |
| form.alert.groups.database.rules.solrHighBufferSize.duration                  |             | <code>5m</code>                                                                                                                      |
| form.alert.groups.database.rules.solrHighBufferSize.enabled                   |             | <code>true</code>                                                                                                                    |
| form.alert.groups.database.rules.solrHighBufferSize.severity                  |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.database.rules.solrHighBufferSize.val                       |             | <code>25</code>                                                                                                                      |
| form.alert.groups.database.rules.solrHighHeapSize.duration                    |             | <code>5m</code>                                                                                                                      |
| form.alert.groups.database.rules.solrHighHeapSize.enabled                     |             | <code>true</code>                                                                                                                    |
| form.alert.groups.database.rules.solrHighHeapSize.severity                    |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.database.rules.solrHighHeapSize.val                         |             | <code>85</code>                                                                                                                      |
| form.alert.groups.database.rules.solrHighPoolSize.duration                    |             | <code>5m</code>                                                                                                                      |
| form.alert.groups.database.rules.solrHighPoolSize.enabled                     |             | <code>true</code>                                                                                                                    |
| form.alert.groups.database.rules.solrHighPoolSize.severity                    |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.database.rules.solrHighPoolSize.val                         |             | <code>85</code>                                                                                                                      |
| form.alert.groups.database.rules.solrHighQPS.duration                         |             | <code>30s</code>                                                                                                                     |
| form.alert.groups.database.rules.solrHighQPS.enabled                          |             | <code>true</code>                                                                                                                    |
| form.alert.groups.database.rules.solrHighQPS.severity                         |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.database.rules.solrHighQPS.val                              |             | <code>1000</code>                                                                                                                    |
| form.alert.groups.database.rules.solrHighThreadRunning.duration               |             | <code>30s</code>                                                                                                                     |
| form.alert.groups.database.rules.solrHighThreadRunning.enabled                |             | <code>true</code>                                                                                                                    |
| form.alert.groups.database.rules.solrHighThreadRunning.severity               |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.database.rules.solrHighThreadRunning.val                    |             | <code>300</code>                                                                                                                     |
| form.alert.groups.database.rules.solrRecoveryFailedShards.duration            |             | <code>30s</code>                                                                                                                     |
| form.alert.groups.database.rules.solrRecoveryFailedShards.enabled             |             | <code>true</code>                                                                                                                    |
| form.alert.groups.database.rules.solrRecoveryFailedShards.severity            |             | <code>critical</code>                                                                                                                |
| form.alert.groups.opsManager.enabled                                          |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.opsManager.rules.opsRequestFailed.duration                  |             | <code>0m</code>                                                                                                                      |
| form.alert.groups.opsManager.rules.opsRequestFailed.enabled                   |             | <code>true</code>                                                                                                                    |
| form.alert.groups.opsManager.rules.opsRequestFailed.severity                  |             | <code>critical</code>                                                                                                                |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.duration              |             | <code>0m</code>                                                                                                                      |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.enabled               |             | <code>true</code>                                                                                                                    |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.severity              |             | <code>info</code>                                                                                                                    |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.duration |             | <code>30m</code>                                                                                                                     |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.enabled  |             | <code>true</code>                                                                                                                    |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.severity |             | <code>critical</code>                                                                                                                |
| form.alert.groups.provisioner.enabled                                         |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration                 |             | <code>1m</code>                                                                                                                      |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled                  |             | <code>true</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity                 |             | <code>warning</code>                                                                                                                 |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration                 |             | <code>1m</code>                                                                                                                      |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled                  |             | <code>true</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity                 |             | <code>critical</code>                                                                                                                |
| form.alert.labels.release                                                     |             | <code>kube-prometheus-stack</code>                                                                                                   |
| metadata.resource.group                                                       |             | <code>kubedb.com</code>                                                                                                              |
| metadata.resource.version                                                     |             | <code>v1alpha2</code>                                                                                                                |
| metadata.resource.name                                                        |             | <code>solrs</code>                                                                                                                   |
| metadata.resource.kind                                                        |             | <code>Solr</code>                                                                                                                    |
| metadata.resource.scope                                                       |             | <code>Namespaced</code>                                                                                                              |
| metadata.release.name                                                         |             | <code>RELEASE-NAME</code>                                                                                                            |
| metadata.release.namespace                                                    |             | <code>default</code>                                                                                                                 |
| resources.autoscalingKubedbComSolrAutoscaler                                  |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"SolrAutoscaler","metadata":{"name":"solr","namespace":"demo"}}</code>  |
| resources.catalogAppscodeComSolrBinding                                       |             | <code>{"apiVersion":"catalog.appscode.com/v1alpha1","kind":"SolrBinding","metadata":{"name":"solr","namespace":"demo"}}</code>       |
| resources.certManagerIoIssuer_ca                                              |             | <code>{"apiVersion":"cert-manager.io/v1","kind":"Issuer","metadata":{"name":"solr-ca","namespace":"demo"}}</code>                    |
| resources.coreKubestashComBackupBlueprint                                     |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupBlueprint","metadata":{"name":"solr","namespace":"demo"}}</code>     |
| resources.coreKubestashComBackupConfiguration                                 |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupConfiguration","metadata":{"name":"solr","namespace":"demo"}}</code> |
| resources.coreKubestashComRestoreSession                                      |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"RestoreSession","metadata":{"name":"solr","namespace":"demo"}}</code>      |
| resources.gitopsKubedbComSolr                                                 |             | <code>{"apiVersion":"gitops.kubedb.com/v1alpha1","kind":"Solr","metadata":{"name":"solr","namespace":"solr"}}</code>                 |
| resources.kubedbComSolr                                                       |             | <code>{"apiVersion":"kubedb.com/v1alpha2","kind":"Solr","metadata":{"name":"solr","namespace":"solr"}}</code>                        |
| resources.monitoringCoreosComServiceMonitor                                   |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"solr","namespace":"demo"}}</code>         |
| resources.secret_auth                                                         |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"solr-auth","namespace":"demo"}}</code>                                  |
| resources.secret_config                                                       |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"solr-config","namespace":"demo"}}</code>                                |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-solr-editor appscode/kubedbcom-solr-editor -n default --create-namespace --version=v0.36.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-solr-editor appscode/kubedbcom-solr-editor -n default --create-namespace --version=v0.36.0 --values values.yaml
```
