# AerospikeOpsRequest Editor

[AerospikeOpsRequest Editor by AppsCode](https://appscode.com) - AerospikeOpsRequest Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/opskubedbcom-aerospikeopsrequest-editor --version=v0.37.0
$ helm upgrade -i opskubedbcom-aerospikeopsrequest-editor appscode/opskubedbcom-aerospikeopsrequest-editor -n default --create-namespace --version=v0.37.0
```

## Introduction

This chart deploys a AerospikeOpsRequest Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `opskubedbcom-aerospikeopsrequest-editor`:

```bash
$ helm upgrade -i opskubedbcom-aerospikeopsrequest-editor appscode/opskubedbcom-aerospikeopsrequest-editor -n default --create-namespace --version=v0.37.0
```

The command deploys a AerospikeOpsRequest Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `opskubedbcom-aerospikeopsrequest-editor`:

```bash
$ helm uninstall opskubedbcom-aerospikeopsrequest-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `opskubedbcom-aerospikeopsrequest-editor` chart and their default values.

|     Parameter      | Description |               Default                |
|--------------------|-------------|--------------------------------------|
| apiVersion         |             | <code>ops.kubedb.com/v1alpha1</code> |
| kind               |             | <code>AerospikeOpsRequest</code>     |
| metadata.name      |             | <code>aerospikeopsrequest</code>     |
| metadata.namespace |             | <code>default</code>                 |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i opskubedbcom-aerospikeopsrequest-editor appscode/opskubedbcom-aerospikeopsrequest-editor -n default --create-namespace --version=v0.37.0 --set apiVersion=ops.kubedb.com/v1alpha1
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i opskubedbcom-aerospikeopsrequest-editor appscode/opskubedbcom-aerospikeopsrequest-editor -n default --create-namespace --version=v0.37.0 --values values.yaml
```
