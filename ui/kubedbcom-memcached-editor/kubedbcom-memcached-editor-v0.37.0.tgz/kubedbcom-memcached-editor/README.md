# Memcached Editor

[Memcached Editor by AppsCode](https://appscode.com) - Memcached Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-memcached-editor --version=v0.37.0
$ helm upgrade -i kubedbcom-memcached-editor appscode/kubedbcom-memcached-editor -n default --create-namespace --version=v0.37.0
```

## Introduction

This chart deploys a Memcached Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-memcached-editor`:

```bash
$ helm upgrade -i kubedbcom-memcached-editor appscode/kubedbcom-memcached-editor -n default --create-namespace --version=v0.37.0
```

The command deploys a Memcached Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-memcached-editor`:

```bash
$ helm uninstall kubedbcom-memcached-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-memcached-editor` chart and their default values.

|                                   Parameter                                   | Description |                                                                    Default                                                                    |
|-------------------------------------------------------------------------------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                               |             | <code>{}</code>                                                                                                                               |
| form.alert.annotations                                                        |             | <code>{}</code>                                                                                                                               |
| form.alert.enabled                                                            |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.enabled                                            |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.rules.memcachedConnectionThrottled.duration        |             | <code>2m</code>                                                                                                                               |
| form.alert.groups.database.rules.memcachedConnectionThrottled.enabled         |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.memcachedConnectionThrottled.severity        |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.rules.memcachedConnectionThrottled.val             |             | <code>10</code>                                                                                                                               |
| form.alert.groups.database.rules.memcachedConnectionsNoneMinor.duration       |             | <code>2m</code>                                                                                                                               |
| form.alert.groups.database.rules.memcachedConnectionsNoneMinor.enabled        |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.memcachedConnectionsNoneMinor.severity       |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.rules.memcachedDown.duration                       |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.memcachedDown.enabled                        |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.memcachedDown.severity                       |             | <code>critical</code>                                                                                                                         |
| form.alert.groups.database.rules.memcachedEvictionsLimit.duration             |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.memcachedEvictionsLimit.enabled              |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.memcachedEvictionsLimit.severity             |             | <code>critical</code>                                                                                                                         |
| form.alert.groups.database.rules.memcachedEvictionsLimit.val                  |             | <code>10</code>                                                                                                                               |
| form.alert.groups.database.rules.memcachedItemsNoneMinor.duration             |             | <code>2m</code>                                                                                                                               |
| form.alert.groups.database.rules.memcachedItemsNoneMinor.enabled              |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.memcachedItemsNoneMinor.severity             |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.database.rules.memcachedMemoryLimit.duration                |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.memcachedMemoryLimit.enabled                 |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.memcachedMemoryLimit.severity                |             | <code>critical</code>                                                                                                                         |
| form.alert.groups.database.rules.memcachedMemoryLimit.val                     |             | <code>3.3554432e+07</code>                                                                                                                    |
| form.alert.groups.database.rules.memcachedServiceRespawn.duration             |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.database.rules.memcachedServiceRespawn.enabled              |             | <code>true</code>                                                                                                                             |
| form.alert.groups.database.rules.memcachedServiceRespawn.severity             |             | <code>critical</code>                                                                                                                         |
| form.alert.groups.database.rules.memcachedServiceRespawn.val                  |             | <code>180</code>                                                                                                                              |
| form.alert.groups.opsManager.enabled                                          |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.opsManager.rules.opsRequestFailed.duration                  |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.opsManager.rules.opsRequestFailed.enabled                   |             | <code>true</code>                                                                                                                             |
| form.alert.groups.opsManager.rules.opsRequestFailed.severity                  |             | <code>critical</code>                                                                                                                         |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.duration              |             | <code>0m</code>                                                                                                                               |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.enabled               |             | <code>true</code>                                                                                                                             |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.severity              |             | <code>info</code>                                                                                                                             |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.duration |             | <code>30m</code>                                                                                                                              |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.enabled  |             | <code>true</code>                                                                                                                             |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.severity |             | <code>critical</code>                                                                                                                         |
| form.alert.groups.provisioner.enabled                                         |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration                 |             | <code>15m</code>                                                                                                                              |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled                  |             | <code>true</code>                                                                                                                             |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity                 |             | <code>warning</code>                                                                                                                          |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration                 |             | <code>1m</code>                                                                                                                               |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled                  |             | <code>true</code>                                                                                                                             |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity                 |             | <code>critical</code>                                                                                                                         |
| form.alert.labels.release                                                     |             | <code>kube-prometheus-stack</code>                                                                                                            |
| metadata.resource.group                                                       |             | <code>kubedb.com</code>                                                                                                                       |
| metadata.resource.version                                                     |             | <code>v1</code>                                                                                                                               |
| metadata.resource.name                                                        |             | <code>memcacheds</code>                                                                                                                       |
| metadata.resource.kind                                                        |             | <code>Memcached</code>                                                                                                                        |
| metadata.resource.scope                                                       |             | <code>Namespaced</code>                                                                                                                       |
| metadata.release.name                                                         |             | <code>RELEASE-NAME</code>                                                                                                                     |
| metadata.release.namespace                                                    |             | <code>default</code>                                                                                                                          |
| resources.autoscalingKubedbComMemcachedAutoscaler                             |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"MemcachedAutoscaler","metadata":{"name":"memcached","namespace":"demo"}}</code> |
| resources.catalogAppscodeComMemcachedBinding                                  |             | <code>{"apiVersion":"catalog.appscode.com/v1alpha1","kind":"MemcachedBinding","metadata":{"name":"memcached","namespace":"demo"}}</code>      |
| resources.certManagerIoIssuer_ca                                              |             | <code>{"apiVersion":"cert-manager.io/v1","kind":"Issuer","metadata":{"name":"memcached-ca","namespace":"demo"}}</code>                        |
| resources.gitopsKubedbComMemcached                                            |             | <code>{"apiVersion":"gitops.kubedb.com/v1alpha1","kind":"Memcached","metadata":{"name":"memcached","namespace":"sdb"}}</code>                 |
| resources.kubedbComMemcached                                                  |             | <code>{"apiVersion":"kubedb.com/v1","kind":"Memcached","metadata":{"name":"memcached","namespace":"sdb"}}</code>                              |
| resources.monitoringCoreosComServiceMonitor                                   |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"memcached","namespace":"demo"}}</code>             |
| resources.secret_auth                                                         |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"memcached-auth","namespace":"demo"}}</code>                                      |
| resources.secret_config                                                       |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"memcached-config","namespace":"demo"}}</code>                                    |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-memcached-editor appscode/kubedbcom-memcached-editor -n default --create-namespace --version=v0.37.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-memcached-editor appscode/kubedbcom-memcached-editor -n default --create-namespace --version=v0.37.0 --values values.yaml
```
