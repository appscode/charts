# Qdrant Editor

[Qdrant Editor by AppsCode](https://appscode.com) - Qdrant Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-qdrant-editor --version=v0.36.0
$ helm upgrade -i kubedbcom-qdrant-editor appscode/kubedbcom-qdrant-editor -n default --create-namespace --version=v0.36.0
```

## Introduction

This chart deploys a Qdrant Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-qdrant-editor`:

```bash
$ helm upgrade -i kubedbcom-qdrant-editor appscode/kubedbcom-qdrant-editor -n default --create-namespace --version=v0.36.0
```

The command deploys a Qdrant Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-qdrant-editor`:

```bash
$ helm uninstall kubedbcom-qdrant-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-qdrant-editor` chart and their default values.

|                               Parameter                               | Description |                                                                 Default                                                                 |
|-----------------------------------------------------------------------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                       |             | <code>{}</code>                                                                                                                         |
| form.alert.annotations                                                |             | <code>{}</code>                                                                                                                         |
| form.alert.enabled                                                    |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.enabled                                    |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.diskAlmostFull.duration              |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.diskAlmostFull.enabled               |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.diskAlmostFull.severity              |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.diskAlmostFull.val                   |             | <code>95</code>                                                                                                                         |
| form.alert.groups.database.rules.diskUsageHigh.duration               |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.diskUsageHigh.enabled                |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.diskUsageHigh.severity               |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.diskUsageHigh.val                    |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantGrpcResponsesFailHigh.duration |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantGrpcResponsesFailHigh.enabled  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.qdrantGrpcResponsesFailHigh.severity |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.qdrantGrpcResponsesFailHigh.val      |             | <code>5</code>                                                                                                                          |
| form.alert.groups.database.rules.qdrantHighCPUUsage.duration          |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantHighCPUUsage.enabled           |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.qdrantHighCPUUsage.severity          |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.qdrantHighCPUUsage.val               |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantHighMemoryUsage.duration       |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantHighMemoryUsage.enabled        |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.qdrantHighMemoryUsage.severity       |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.qdrantHighMemoryUsage.val            |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantHighPendingOperations.duration |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantHighPendingOperations.enabled  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.qdrantHighPendingOperations.severity |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.qdrantHighPendingOperations.val      |             | <code>10</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantInstanceDown.duration          |             | <code>30s</code>                                                                                                                        |
| form.alert.groups.database.rules.qdrantInstanceDown.enabled           |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.qdrantInstanceDown.severity          |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.qdrantPhaseCritical.duration         |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantPhaseCritical.enabled          |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.qdrantPhaseCritical.severity         |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.qdrantRestResponsesFailHigh.duration |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantRestResponsesFailHigh.enabled  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.qdrantRestResponsesFailHigh.severity |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.qdrantRestResponsesFailHigh.val      |             | <code>5</code>                                                                                                                          |
| form.alert.groups.database.rules.qdrantRestarted.duration             |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.qdrantRestarted.enabled              |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.qdrantRestarted.severity             |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.qdrantRestarted.val                  |             | <code>180</code>                                                                                                                        |
| form.alert.groups.provisioner.enabled                                 |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration         |             | <code>15m</code>                                                                                                                        |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled          |             | <code>true</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity         |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration         |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled          |             | <code>true</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity         |             | <code>critical</code>                                                                                                                   |
| form.alert.labels.release                                             |             | <code>prometheus</code>                                                                                                                 |
| metadata.resource.group                                               |             | <code>kubedb.com</code>                                                                                                                 |
| metadata.resource.version                                             |             | <code>v1alpha2</code>                                                                                                                   |
| metadata.resource.name                                                |             | <code>qdrants</code>                                                                                                                    |
| metadata.resource.kind                                                |             | <code>Qdrant</code>                                                                                                                     |
| metadata.resource.scope                                               |             | <code>Namespaced</code>                                                                                                                 |
| metadata.release.name                                                 |             | <code>RELEASE-NAME</code>                                                                                                               |
| metadata.release.namespace                                            |             | <code>default</code>                                                                                                                    |
| resources.autoscalingKubedbComQdrantAutoscaler                        |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"QdrantAutoscaler","metadata":{"name":"qdrant","namespace":"demo"}}</code> |
| resources.catalogAppscodeComQdrantBinding                             |             | <code>{"apiVersion":"catalog.appscode.com/v1alpha1","kind":"QdrantBinding","metadata":{"name":"qdrant","namespace":"demo"}}</code>      |
| resources.certManagerIoIssuer_ca                                      |             | <code>{"apiVersion":"cert-manager.io/v1","kind":"Issuer","metadata":{"name":"qdrant-ca","namespace":"demo"}}</code>                     |
| resources.coreKubestashComBackupBlueprint                             |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupBlueprint","metadata":{"name":"qdrant","namespace":"demo"}}</code>      |
| resources.coreKubestashComBackupConfiguration                         |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupConfiguration","metadata":{"name":"qdrant","namespace":"demo"}}</code>  |
| resources.coreKubestashComRestoreSession                              |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"RestoreSession","metadata":{"name":"qdrant","namespace":"demo"}}</code>       |
| resources.kubedbComQdrant                                             |             | <code>{"apiVersion":"kubedb.com/v1alpha2","kind":"Qdrant","metadata":{"name":"qdrant","namespace":"default"}}</code>                    |
| resources.monitoringCoreosComServiceMonitor                           |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"qdrant","namespace":"demo"}}</code>          |
| resources.secret_auth                                                 |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"qdrant-auth","namespace":"demo"}}</code>                                   |
| resources.secret_config                                               |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"qdrant-config","namespace":"demo"}}</code>                                 |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-qdrant-editor appscode/kubedbcom-qdrant-editor -n default --create-namespace --version=v0.36.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-qdrant-editor appscode/kubedbcom-qdrant-editor -n default --create-namespace --version=v0.36.0 --values values.yaml
```
