# HanaDB Editor

[HanaDB Editor by AppsCode](https://appscode.com) - HanaDB Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-hanadb-editor --version=v0.37.0
$ helm upgrade -i kubedbcom-hanadb-editor appscode/kubedbcom-hanadb-editor -n default --create-namespace --version=v0.37.0
```

## Introduction

This chart deploys a HanaDB Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-hanadb-editor`:

```bash
$ helm upgrade -i kubedbcom-hanadb-editor appscode/kubedbcom-hanadb-editor -n default --create-namespace --version=v0.37.0
```

The command deploys a HanaDB Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-hanadb-editor`:

```bash
$ helm uninstall kubedbcom-hanadb-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-hanadb-editor` chart and their default values.

|                              Parameter                               | Description |                                                                 Default                                                                 |
|----------------------------------------------------------------------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                      |             | <code>{}</code>                                                                                                                         |
| form.alert.annotations                                               |             | <code>{}</code>                                                                                                                         |
| form.alert.enabled                                                   |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.enabled                                   |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.diskAlmostFull.duration             |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.diskAlmostFull.enabled              |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.diskAlmostFull.severity             |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.diskAlmostFull.val                  |             | <code>95</code>                                                                                                                         |
| form.alert.groups.database.rules.diskUsageHigh.duration              |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.diskUsageHigh.enabled               |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.diskUsageHigh.severity              |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.diskUsageHigh.val                   |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.hanadbHighCPUUsage.duration         |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.database.rules.hanadbHighCPUUsage.enabled          |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.hanadbHighCPUUsage.severity         |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.hanadbHighCPUUsage.val              |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.hanadbHighMemoryUsage.duration      |             | <code>5m</code>                                                                                                                         |
| form.alert.groups.database.rules.hanadbHighMemoryUsage.enabled       |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.hanadbHighMemoryUsage.severity      |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.hanadbHighMemoryUsage.val           |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.hanadbInstanceDown.duration         |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.database.rules.hanadbInstanceDown.enabled          |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.hanadbInstanceDown.severity         |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.hanadbReplicationNotActive.duration |             | <code>2m</code>                                                                                                                         |
| form.alert.groups.database.rules.hanadbReplicationNotActive.enabled  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.hanadbReplicationNotActive.severity |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.hanadbRestarted.duration            |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.hanadbRestarted.enabled             |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.hanadbRestarted.severity            |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.hanadbRestarted.val                 |             | <code>180</code>                                                                                                                        |
| form.alert.groups.database.rules.hanadbServiceDown.duration          |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.database.rules.hanadbServiceDown.enabled           |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.hanadbServiceDown.severity          |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.provisioner.enabled                                |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration        |             | <code>15m</code>                                                                                                                        |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled         |             | <code>true</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity        |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration        |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled         |             | <code>true</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity        |             | <code>critical</code>                                                                                                                   |
| form.alert.labels.release                                            |             | <code>kube-prometheus-stack</code>                                                                                                      |
| metadata.resource.group                                              |             | <code>kubedb.com</code>                                                                                                                 |
| metadata.resource.version                                            |             | <code>v1alpha2</code>                                                                                                                   |
| metadata.resource.name                                               |             | <code>hanadbs</code>                                                                                                                    |
| metadata.resource.kind                                               |             | <code>HanaDB</code>                                                                                                                     |
| metadata.resource.scope                                              |             | <code>Namespaced</code>                                                                                                                 |
| metadata.release.name                                                |             | <code>RELEASE-NAME</code>                                                                                                               |
| metadata.release.namespace                                           |             | <code>default</code>                                                                                                                    |
| resources.autoscalingKubedbComHanaDBAutoscaler                       |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"HanaDBAutoscaler","metadata":{"name":"hanadb","namespace":"demo"}}</code> |
| resources.kubedbComHanaDB                                            |             | <code>{"apiVersion":"kubedb.com/v1alpha2","kind":"HanaDB","metadata":{"name":"hanadb","namespace":"default"}}</code>                    |
| resources.monitoringCoreosComServiceMonitor                          |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"hanadb","namespace":"demo"}}</code>          |
| resources.secret_auth                                                |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"hanadb-auth","namespace":"demo"}}</code>                                   |
| resources.secret_config                                              |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"hanadb-config","namespace":"demo"}}</code>                                 |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-hanadb-editor appscode/kubedbcom-hanadb-editor -n default --create-namespace --version=v0.37.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-hanadb-editor appscode/kubedbcom-hanadb-editor -n default --create-namespace --version=v0.37.0 --values values.yaml
```
