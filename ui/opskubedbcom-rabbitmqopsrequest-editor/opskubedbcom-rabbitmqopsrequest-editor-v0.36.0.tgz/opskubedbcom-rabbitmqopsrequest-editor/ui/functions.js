const { axios, useOperator, store, useToast } = window.vueHelpers || {}
const machines = {
  'db.t.micro': {
    resources: {
      requests: {
        cpu: '250m',
        memory: '512Mi',
      },
      limits: {
        cpu: '500m',
        memory: '1Gi',
      },
    },
  },
  'db.t.small': {
    resources: {
      requests: {
        cpu: '1',
        memory: '1Gi',
      },
      limits: {
        cpu: '2',
        memory: '2Gi',
      },
    },
  },
  'db.t.medium': {
    resources: {
      requests: {
        cpu: '1',
        memory: '2Gi',
      },
      limits: {
        cpu: '2',
        memory: '4Gi',
      },
    },
  },
  'db.t.large': {
    resources: {
      requests: {
        cpu: '1',
        memory: '4Gi',
      },
      limits: {
        cpu: '2',
        memory: '8Gi',
      },
    },
  },
  'db.t.xlarge': {
    resources: {
      requests: {
        cpu: '2',
        memory: '8Gi',
      },
      limits: {
        cpu: '4',
        memory: '16Gi',
      },
    },
  },
  'db.t.2xlarge': {
    resources: {
      requests: {
        cpu: '4',
        memory: '16Gi',
      },
      limits: {
        cpu: '8',
        memory: '32Gi',
      },
    },
  },
  'db.m.small': {
    resources: {
      requests: {
        cpu: '500m',
        memory: '912680550',
      },
      limits: {
        cpu: '1',
        memory: '1825361100',
      },
    },
  },
  'db.m.large': {
    resources: {
      requests: {
        cpu: '1',
        memory: '4Gi',
      },
      limits: {
        cpu: '2',
        memory: '8Gi',
      },
    },
  },
  'db.m.xlarge': {
    resources: {
      requests: {
        cpu: '2',
        memory: '8Gi',
      },
      limits: {
        cpu: '4',
        memory: '16Gi',
      },
    },
  },
  'db.m.2xlarge': {
    resources: {
      requests: {
        cpu: '4',
        memory: '16Gi',
      },
      limits: {
        cpu: '8',
        memory: '32Gi',
      },
    },
  },
  'db.m.4xlarge': {
    resources: {
      requests: {
        cpu: '8',
        memory: '32Gi',
      },
      limits: {
        cpu: '16',
        memory: '64Gi',
      },
    },
  },
  'db.m.8xlarge': {
    resources: {
      requests: {
        cpu: '16',
        memory: '64Gi',
      },
      limits: {
        cpu: '32',
        memory: '128Gi',
      },
    },
  },
  'db.m.12xlarge': {
    resources: {
      requests: {
        cpu: '24',
        memory: '96Gi',
      },
      limits: {
        cpu: '48',
        memory: '192Gi',
      },
    },
  },
  'db.m.16xlarge': {
    resources: {
      requests: {
        cpu: '32',
        memory: '128Gi',
      },
      limits: {
        cpu: '64',
        memory: '256Gi',
      },
    },
  },
  'db.m.24xlarge': {
    resources: {
      requests: {
        cpu: '48',
        memory: '192Gi',
      },
      limits: {
        cpu: '96',
        memory: '384Gi',
      },
    },
  },
  'db.r.large': {
    resources: {
      requests: {
        cpu: '1',
        memory: '8Gi',
      },
      limits: {
        cpu: '2',
        memory: '16Gi',
      },
    },
  },
  'db.r.xlarge': {
    resources: {
      requests: {
        cpu: '2',
        memory: '16Gi',
      },
      limits: {
        cpu: '4',
        memory: '32Gi',
      },
    },
  },
  'db.r.2xlarge': {
    resources: {
      requests: {
        cpu: '4',
        memory: '32Gi',
      },
      limits: {
        cpu: '8',
        memory: '64Gi',
      },
    },
  },
  'db.r.4xlarge': {
    resources: {
      requests: {
        cpu: '8',
        memory: '96Gi',
      },
      limits: {
        cpu: '16',
        memory: '192Gi',
      },
    },
  },
  'db.r.8xlarge': {
    resources: {
      requests: {
        cpu: '16',
        memory: '128Gi',
      },
      limits: {
        cpu: '32',
        memory: '256Gi',
      },
    },
  },
  'db.r.12xlarge': {
    resources: {
      requests: {
        cpu: '24',
        memory: '192Gi',
      },
      limits: {
        cpu: '48',
        memory: '384Gi',
      },
    },
  },
  'db.r.16xlarge': {
    resources: {
      requests: {
        cpu: '32',
        memory: '256Gi',
      },
      limits: {
        cpu: '64',
        memory: '512Gi',
      },
    },
  },
  'db.r.24xlarge': {
    resources: {
      requests: {
        cpu: '24',
        memory: '384Gi',
      },
      limits: {
        cpu: '96',
        memory: '768Gi',
      },
    },
  },
}

const machineList = [
  'custom',
  'db.t.micro',
  'db.t.small',
  'db.t.medium',
  'db.t.large',
  'db.t.xlarge',
  'db.t.2xlarge',
  'db.m.small',
  'db.m.large',
  'db.m.xlarge',
  'db.m.2xlarge',
  'db.m.4xlarge',
  'db.m.8xlarge',
  'db.m.12xlarge',
  'db.m.16xlarge',
  'db.m.24xlarge',
  'db.r.large',
  'db.r.xlarge',
  'db.r.2xlarge',
  'db.r.4xlarge',
  'db.r.8xlarge',
  'db.r.12xlarge',
  'db.r.16xlarge',
  'db.r.24xlarge',
]

const configSecretKeys = ['rabbitmq.conf']
let machinesFromPreset = []

export const useFunc = (model) => {
  const route = store.state?.route
  const toast = useToast()

  const { getValue, storeGet, discriminator, setDiscriminatorValue, commit } = useOperator(
    model,
    store.state,
  )

  showAndInitOpsRequestType()

  function isTlsEnabled(type) {
    const selectedOpsType = getValue(discriminator, '/tlsOperation')
    return selectedOpsType === type
  }

  async function getNamespaces() {
    if (storeGet('/route/params/actions')) return []
    const owner = storeGet('/route/params/user')
    const cluster = storeGet('/route/params/cluster')

    const resp = await axios.get(`/clusters/${owner}/${cluster}/proxy/core/v1/namespaces`, {
      params: { filter: { items: { metadata: { name: null } } } },
    })

    const resources = (resp && resp.data && resp.data.items) || []

    return resources.map((item) => {
      const name = (item.metadata && item.metadata.name) || ''
      return {
        text: name,
        value: name,
      }
    })
  }

  function isRancherManaged() {
    const managers = storeGet('/cluster/clusterDefinition/result/clusterManagers')
    const found = managers.find((item) => item === 'Rancher')
    return !!found
  }

  async function getDbs() {
    if (storeGet('/route/params/actions')) return []
    const owner = storeGet('/route/params/user')
    const cluster = storeGet('/route/params/cluster')

    const namespace = getValue(model, '/metadata/namespace')
    // watchDependency('model#/metadata/namespace')

    const resp = await axios.get(
      `/clusters/${owner}/${cluster}/proxy/kubedb.com/v1alpha2/namespaces/${namespace}/rabbitmqs`,
      {
        params: { filter: { items: { metadata: { name: null } } } },
      },
    )

    const resources = (resp && resp.data && resp.data.items) || []

    return resources.map((item) => {
      const name = (item.metadata && item.metadata.name) || ''
      return {
        text: name,
        value: name,
      }
    })
  }

  async function getDbDetails() {
    machinesFromPreset = storeGet('/kubedbuiPresets')?.admin?.machineProfiles?.machines || []

    const owner = storeGet('/route/params/user')
    const cluster = storeGet('/route/params/cluster')
    const namespace = storeGet('/route/query/namespace') || getValue(model, '/metadata/namespace')
    const name = storeGet('/route/params/name') || getValue(model, '/spec/databaseRef/name')
    const version = storeGet('/route/params/version')
    if (namespace && name) {
      const url = `/clusters/${owner}/${cluster}/proxy/kubedb.com/${version}/namespaces/${namespace}/rabbitmqs/${name}`
      const resp = await axios.get(url)

      setDiscriminatorValue('/dbDetails', resp.data || {})

      return resp.data || {}
    } else return {}
  }

  let presetVersions = []
  setDiscriminatorValue('/filteredVersion', [])
  async function getDbVersions() {
    const owner = storeGet('/route/params/user')
    const cluster = storeGet('/route/params/cluster')

    const url = `/clusters/${owner}/${cluster}/proxy/charts.x-helm.dev/v1alpha1/clusterchartpresets/kubedb-ui-presets`

    let presets = storeGet('/kubedbuiPresets') || {}
    if (!storeGet('/route/params/actions')) {
      try {
        const presetResp = await axios.get(url)
        presets = presetResp.data?.spec?.values?.spec
      } catch (e) {
        console.log(e)
        presets.status = String(e.status)
      }
    }

    try {
      presetVersions = presets.admin?.databases?.RabbitMQ?.versions?.available || []
      const queryParams = {
        filter: {
          items: {
            metadata: { name: null },
            spec: { version: null, deprecated: null, updateConstraints: null },
          },
        },
      }

      const resp = await axios.get(
        `/clusters/${owner}/${cluster}/proxy/catalog.kubedb.com/v1alpha1/rabbitmqversions`,
        {
          params: queryParams,
        },
      )

      const resources = (resp && resp.data && resp.data.items) || []

      const sortedVersions = resources.sort((a, b) =>
        versionCompare(a.spec.version, b.spec.version),
      )

      let ver = getValue(discriminator, '/dbDetails/spec/version') || '0'
      const found = sortedVersions.find((item) => item.metadata.name === ver)

      if (found) ver = found.spec?.version
      const allowed = found?.spec?.updateConstraints?.allowlist || []
      const limit = allowed.length ? allowed[0] : '0.0'

      const filteredRabbitMQVersions = sortedVersions.filter((item) => {
        if (limit === '0.0')
          return (
            !item.spec?.deprecated &&
            (presets.status === '404' ||
              presetVersions.length === 0 ||
              presetVersions.includes(item.metadata?.name)) &&
            versionCompare(item.spec?.version, ver) >= 0
          )
        else if (!limit.match(/^(>=|<=|>|<)/))
          return (
            !item.spec?.deprecated &&
            (presets.status === '404' ||
              presetVersions.length === 0 ||
              presetVersions.includes(item.metadata?.name)) &&
            item.spec?.version === limit
          )
        else
          return (
            !item.spec?.deprecated &&
            (presets.status === '404' ||
              presetVersions.length === 0 ||
              presetVersions.includes(item.metadata?.name)) &&
            isVersionWithinConstraints(item.spec?.version, limit)
          )
      })

      setDiscriminatorValue('/filteredVersion', filteredRabbitMQVersions)
      return filteredRabbitMQVersions.map((item) => {
        const name = (item.metadata && item.metadata.name) || ''
        const specVersion = (item.spec && item.spec.version) || ''
        return {
          text: `${name} (${specVersion})`,
          value: name,
        }
      })
    } catch (e) {
      console.log(e)
      return []
    }
  }

  function getVersionInfo() {
    const filteredVersion = getValue(discriminator, '/filteredVersion')
    if (filteredVersion.length) return ''

    let txt = 'No versions from this list can be selected as the target version: [ '

    presetVersions.forEach((v, idx) => {
      txt = `${txt}"${v}"`
      if (idx !== presetVersions.length - 1) txt = txt + ', '
      else txt = txt + ' ]'
    })

    return txt
  }

  function isVersionEmpty() {
    const val = getValue(discriminator, '/filteredVersion')
    return val.length === 0
  }

  function versionCompare(v1, v2) {
    const arr1 = v1.split('.').map(Number)
    const arr2 = v2.split('.').map(Number)

    for (let i = 0; i < Math.max(arr1.length, arr2.length); i++) {
      const num1 = arr1[i] || 0
      const num2 = arr2[i] || 0

      if (num1 > num2) return 1
      if (num1 < num2) return -1
    }
    return 0
  }

  function isVersionWithinConstraints(version, constraints) {
    let constraintsArr = []
    if (constraints.includes(',')) constraintsArr = constraints?.split(',')?.map((c) => c.trim())
    else constraintsArr = [constraints]

    for (let constraint of constraintsArr) {
      let match = constraint.match(/^(>=|<=|>|<)/)
      let operator = match ? match[0] : ''
      let constraintVersion = constraint.replace(/^(>=|<=|>|<)/, '').trim()

      let comparison = versionCompare(version, constraintVersion)
      if (
        (operator === '>=' && comparison < 0) ||
        (operator === '<=' && comparison > 0) ||
        (operator === '>' && comparison <= 0) ||
        (operator === '<' && comparison >= 0)
      )
        return false
    }
    return true
  }

  function ifRequestTypeEqualsTo(type) {
    const selectedType = getValue(model, '/spec/type')
    // watchDependency('model#/spec/type')

    return selectedType === type
  }

  function onRequestTypeChange() {
    const selectedType = getValue(model, '/spec/type')
    const reqTypeMapping = {
      Upgrade: 'updateVersion',
      UpdateVersion: 'updateVersion',
      HorizontalScaling: 'horizontalScaling',
      VerticalScaling: 'verticalScaling',
      VolumeExpansion: 'volumeExpansion',
      Restart: 'restart',
      Reconfigure: 'configuration',
      ReconfigureTLS: 'tls',
    }

    Object.keys(reqTypeMapping).forEach((key) => {
      if (key !== selectedType) commit('wizard/model$delete', `/spec/${reqTypeMapping[key]}`)
    })
  }

  function getDbTls() {
    // watchDependency('discriminator#/dbDetails')
    const dbDetails = getValue(discriminator, '/dbDetails')

    const { spec } = dbDetails || {}
    return spec?.tls || undefined
  }

  function getDbType() {
    // watchDependency('discriminator#/dbDetails')
    const dbDetails = getValue(discriminator, '/dbDetails')
    const { spec } = dbDetails || {}
    const { topology } = spec || {}
    if (topology) return 'Topology'
    else return 'Combined'
  }

  function initNamespace() {
    const { namespace } = route.query || {}
    return namespace || null
  }

  function initDatabaseRef() {
    // watchDependency('model#/metadata/namespace')
    const { name } = route.params || {}
    return name
  }

  function asDatabaseOperation() {
    return !!route.params.actions
  }

  function generateOpsRequestNameForClusterUI(getValue, model, route) {
    const dbName = getValue(model, '/spec/databaseRef/name')

    const selectedType = getValue(model, '/spec/type')
    const lowerType = selectedType ? String(selectedType).toLowerCase() : ''

    const resources = route.params.resource || ''
    const resource = resources.slice(0, -1)

    const opsName = dbName ? dbName : resource
    return `${opsName}-${Math.floor(Date.now() / 1000)}${lowerType ? '-' + lowerType : ''}`
  }

  function showAndInitName() {
    // watchDependency('model#/spec/type')
    // watchDependency('model#/spec/databaseRef/name')
    const ver = asDatabaseOperation()

    const selectedType = getValue(model, '/spec/type')
    const lowerType = selectedType ? String(selectedType).toLowerCase() : ''

    if (ver) {
      commit('wizard/model$update', {
        path: '/metadata/name',
        value: `${route.params.name}-${Math.floor(Date.now() / 1000)}-${lowerType}`,
        force: true,
      })
    } else {
      commit('wizard/model$update', {
        path: '/metadata/name',
        value: generateOpsRequestNameForClusterUI(getValue, model, route),
        force: true,
      })
    }
    return !ver
  }

  function showAndInitNamespace() {
    const ver = asDatabaseOperation()
    if (ver) {
      commit('wizard/model$update', {
        path: '/metadata/namespace',
        value: `${route.query.namespace}`,
        force: true,
      })
    }

    return !ver
  }

  function showAndInitDatabaseRef() {
    const ver = asDatabaseOperation()
    if (ver) {
      commit('wizard/model$update', {
        path: '/spec/databaseRef/name',
        value: `${route.params.name}`,
        force: true,
      })
    }

    return !ver
  }

  function showConfigureOpsrequestLabel() {
    return !asDatabaseOperation()
  }

  function showAndInitOpsRequestType() {
    const ver = asDatabaseOperation()
    const opMap = {
      upgrade: 'UpdateVersion',
      updateVersion: 'UpdateVersion',
      horizontalscaling: 'HorizontalScaling',
      verticalscaling: 'VerticalScaling',
      volumeexpansion: 'VolumeExpansion',
      restart: 'Restart',
      reconfiguretls: 'ReconfigureTLS',
      reconfigure: 'Reconfigure',
    }
    if (ver) {
      const operation = storeGet('/resource/activeActionItem/result/operationId') || ''
      const match = /^(.*)-opsrequest-(.*)$/.exec(operation)
      if (match) {
        const opstype = match[2]
        commit('wizard/model$update', {
          path: '/spec/type',
          value: opMap[opstype],
          force: true,
        })
      }
    }

    return !ver
  }

  function ifDbTypeEqualsTo(value, opsReqType) {
    const verd = getDbType()
    return value === verd
  }

  function getMachines() {
    const presets = storeGet('/kubedbuiPresets') || {}
    const limits = getLimits()

    const avlMachines = presets.admin?.machineProfiles?.available || []
    let arr = []
    if (avlMachines.length) {
      arr = avlMachines.map((machine) => {
        if (machine === 'custom')
          return { text: machine, value: { machine, cpu: limits.cpu, memory: limits.memory } }
        else {
          const machineData = machinesFromPreset.find((val) => val.id === machine)
          if (machineData) {
            const subtext = `CPU: ${machineData.limits.cpu}, Memory: ${machineData.limits.memory}`
            const text = machineData.name ? machineData.name : machineData.id
            return {
              text,
              subtext,
              value: {
                machine: text,
                cpu: machineData.limits.cpu,
                memory: machineData.limits.memory,
              },
            }
          } else
            return { text: machine, value: { machine, cpu: limits.cpu, memory: limits.memory } }
        }
      })
    } else {
      arr = machineList
        .map((machine) => {
          if (machine === 'custom')
            return { text: machine, value: { machine, cpu: limits.cpu, memory: limits.memory } }
          const subtext = `CPU: ${machines[machine].resources.limits.cpu}, Memory: ${machines[machine].resources.limits.memory}`
          const text = machine
          return {
            text,
            subtext,
            value: {
              machine: text,
              cpu: machines[machine].resources.limits.cpu,
              memory: machines[machine].resources.limits.memory,
            },
          }
        })
        .filter((val) => !!val)
    }
    return arr
  }

  function setMachine() {
    const dbDetails = getValue(discriminator, '/dbDetails')
    const limits = getLimits()
    const annotations = dbDetails?.metadata?.annotations || {}
    const instance = annotations['kubernetes.io/instance-type']
    let parsedInstance = {}
    try {
      if (instance) parsedInstance = JSON.parse(instance)
    } catch (e) {
      console.log(e)
      parsedInstance = instance || {}
    }
    const machine = parsedInstance || 'custom'

    const machinePresets = machinesFromPreset.find((item) => item.id === machine)
    if (machinePresets) {
      return {
        machine: machine,
        cpu: machinePresets.limits.cpu,
        memory: machinePresets.limits.memory,
      }
    } else return { machine: 'custom', cpu: limits.cpu, memory: limits.memory }
  }

  function onMachineChange(type) {
    const selectedMachine = getValue(discriminator, '/machine') || {}
    const machine = machinesFromPreset.find((item) => item.id === selectedMachine.machine)

    let obj = {}
    if (selectedMachine.machine !== 'custom') {
      if (machine) obj = { limits: { ...machine?.limits }, requests: { ...machine?.limits } }
      else obj = machines[selectedMachine.machine]?.resources
    } else {
      const cpu = selectedMachine.cpu || ''
      const memory = selectedMachine.memory || ''
      obj = {
        limits: { cpu: cpu, memory: memory },
        requests: { cpu: cpu, memory: memory },
      }
    }

    const path = `/spec/verticalScaling/${type}/resources`

    if (obj && Object.keys(obj).length) {
      commit('wizard/model$update', {
        path: path,
        value: obj,
      })
    } else {
      commit('wizard/model$delete', `/spec/verticalScaling/${type}`)
    }

    const annotations = getValue(model, '/metadata/annotations') || {}
    annotations['kubernetes.io/instance-type'] = selectedMachine.machine
    if (machinesFromPreset.length)
      commit('wizard/model$update', {
        path: '/metadata/annotations',
        value: annotations,
        force: true,
      })
  }

  // Fetch and store database Infos
  // for secret configurations in reconfigure
  let configSecrets = []
  let secretConfigData = []
  let existingSecrets = []
  let databaseInfoResponse = {}

  async function fetchConfigSecrets() {
    const owner = storeGet('/route/params/user')
    const cluster = storeGet('/route/params/cluster')
    const namespace = getValue(model, '/metadata/namespace')
    // watchDependency('model#/metadata/namespace')

    const name = getValue(model, '/spec/databaseRef/name')
    const dbGroup = getValue(model, '/route/params/group')
    const dbKind = getValue(store.state, '/resource/definition/result/kind')

    try {
      const resp = await axios.get(
        `/clusters/${owner}/${cluster}/proxy/ui.kubedb.com/v1alpha1/namespaces/${namespace}/databaseconfigurations/${name}~${dbKind}.${dbGroup}`,
        {
          params: {
            keys: ['rabbitmq.conf'].join(','),
          },
        },
      )
      databaseInfoResponse = resp?.data?.response || {}
      configSecrets = resp?.data?.response?.availableSecrets || []
      secretConfigData = resp?.data?.response?.configurations || []
    } catch (e) {
      console.log(e)
    }

    // Fetching all existing secrets
    try {
      const resp = await axios.get(`/clusters/${owner}/${cluster}/proxy/core/v1/secrets`)
      resp.data?.items.forEach((item) => {
        if (item.metadata?.name) {
          existingSecrets.push(item.metadata.name)
        }
      })
    } catch (e) {
      console.log(e)
    }
  }

  function getCurrentConfig() {
    const currentConfig = databaseInfoResponse?.appliedConfig ?? ''
    return currentConfig
  }

  async function getConfigSecrets(type) {
    type = type ? type + '/' : ''
    const secretStatus = getValue(discriminator, `${type}createSecret/status`)
    if (secretStatus === 'success') {
      await fetchConfigSecrets()
    }
    const mappedSecrets = configSecrets.map((item) => {
      return { text: item, value: item }
    })
    mappedSecrets.push({ text: '+ Create a new Secret', value: 'Create' })
    return mappedSecrets
  }

  async function getConfigSecretsforAppyConfig() {
    const secrets = secretConfigData.map((item) => {
      return { text: item.componentName, value: item.componentName }
    })
    return secrets
  }

  async function createNewConfigSecret(type) {
    type = type ? type + '/' : ''
    const { user, cluster } = route.params
    const url = `/clusters/${user}/${cluster}/resources`
    const namespace = storeGet('/route/query/namespace') || getValue(model, '/metadata/namespace')
    const secretName = getValue(discriminator, `${type}createSecret/name`)
    const secretData = getValue(discriminator, `${type}createSecret/data`)
    const secretDataObj = Object.fromEntries(secretData.map((item) => [item.key, item.value]))

    // Check uniqueness of secret name
    if (existingSecrets.includes(secretName)) {
      toast.error('A secret with this name already exists. Please choose another name.', {
        timeout: 8000,
      })
      return false
    }

    try {
      const res = await axios.post(url, {
        apiVersion: 'v1',
        stringData: secretDataObj,
        kind: 'Secret',
        metadata: {
          name: secretName,
          namespace: namespace,
        },
        type: 'Opaque',
      })
      commit('wizard/temp$update', {
        path: `${type}createSecret/status`,
        value: 'success',
      })
      commit('wizard/temp$update', {
        path: `${type}createSecret/lastCreatedSecret`,
        value: secretName,
      })
      toast.success('Secret created successfully')
    } catch (error) {
      const errMsg = decodeError(error, 'Failed to create secret')
      toast.error(errMsg, { timeout: 5000 })
      cancelCreateSecret()
    }
    return true
  }

  function decodeError(msg, defaultMsg) {
    if (typeof msg === 'string') {
      return msg || defaultMsg
    }
    return (
      (msg.response && msg.response.data && msg.response.data.message) ||
      (msg.response && msg.response.data) ||
      (msg.status && msg.status.status) ||
      defaultMsg
    )
  }

  function isCreateSecret(type) {
    type = type ? type + '/' : ''
    const selectedSecret = getValue(model, `spec/configuration/${type}configSecret/name`)
    const res = selectedSecret === 'Create'

    if (res === true) {
      commit('wizard/temp$update', {
        path: `${type}createSecret/status`,
        value: 'pending',
      })
    }
    return res
  }

  function isNotCreateSecret(type) {
    return !isCreateSecret(type)
  }

  function onCreateSecretChange(type) {
    type = type ? type + '/' : ''
    const secretStatus = getValue(discriminator, `${type}createSecret/status`)
    if (secretStatus === 'cancelled') return ''
    else if (secretStatus === 'success') {
      const name = getValue(discriminator, `${type}createSecret/lastCreatedSecret`)

      const configFound = configSecrets.find((item) => item === name)
      return configFound ? { text: name, value: name } : ''
    }
  }

  function cancelCreateSecret(type) {
    type = type ? type + '/' : ''
    commit('wizard/temp$delete', `${type}createSecret/name`)
    commit('wizard/temp$delete', `${type}createSecret/data`)
    commit('wizard/temp$update', {
      path: `${type}createSecret/status`,
      value: 'cancelled',
    })
  }

  async function onApplyconfigChange(type) {
    type = type ? type + '/' : ''
    const configValue = getValue(discriminator, `${type}applyConfig`)

    if (!configValue) {
      commit('wizard/model$delete', `/spec/configuration/${type}applyConfig`)
      return
    }
    const tempConfigObj = {}
    configValue.forEach((item) => {
      if (item.name && item.content) {
        tempConfigObj[item.name] = item.content
      }
    })
    if (Object.keys(tempConfigObj).length === 0) {
      commit('wizard/model$delete', `/spec/configuration/${type}applyConfig`)
      return
    }
    commit('wizard/model$update', {
      path: `/spec/configuration/${type}applyConfig`,
      value: tempConfigObj,
    })
  }

  function setApplyConfig(type) {
    type = type ? type + '/' : ''
    const configPath = `/${type}selectedConfiguration`
    const selectedConfig = getValue(discriminator, configPath)
    if (!selectedConfig) {
      return [{ name: '', content: '' }]
    }
    const applyconfigData = secretConfigData.find((item) => {
      if (item.componentName === selectedConfig) {
        return item
      }
    })
    const { applyConfig } = applyconfigData
    const configObj = []

    if (applyConfig) {
      Object.keys(applyConfig).forEach((fileName) => {
        configObj.push({
          name: fileName,
          content: applyConfig[fileName],
        })
      })
    }
    configSecretKeys.forEach((key) => {
      if (!configObj.find((item) => item.name === key)) {
        configObj.push({ name: key, content: '' })
      }
    })
    return configObj
  }

  function onRemoveConfigChange(type) {
    type = type ? type + '/' : ''
    const configPath = `/${type}selectedConfigurationRemove`
    const selectedConfig = getValue(discriminator, configPath)

    if (!selectedConfig) {
      commit('wizard/model$delete', `/spec/configuration/${type}removeCustomConfig`)
      return
    }
    commit('wizard/model$update', {
      path: `/spec/configuration/${type}removeCustomConfig`,
      value: true,
    })
  }

  async function onNewConfigSecretChange(type) {
    type = type ? type + '/' : ''
    const path = `/spec/configuration/${type}configSecret/name`
    const selectedSecret = getValue(model, path)

    if (!selectedSecret) {
      commit('wizard/model$delete', `/spec/configuration/${type}configSecret`)
      return [{ name: '', content: '' }]
    }
    if (selectedSecret === 'Create') return [{ name: '', content: '' }]

    const owner = storeGet('/route/params/user')
    const cluster = storeGet('/route/params/cluster')
    const namespace = storeGet('/route/query/namespace') || getValue(model, '/metadata/namespace')

    try {
      // Fetch the secret data from API
      const secretResp = await axios.get(
        `/clusters/${owner}/${cluster}/proxy/core/v1/namespaces/${namespace}/secrets/${selectedSecret}`,
      )

      const secretData = secretResp.data?.data || {}
      const configObj = []

      // Decode base64 and format as array of objects with name and content
      Object.keys(secretData).forEach((fileName) => {
        try {
          // Decode base64 string
          const decodedString = atob(secretData[fileName])
          configObj.push({
            name: fileName,
            content: decodedString,
          })
        } catch (e) {
          console.error(`Error decoding ${fileName}:`, e)
          configObj.push({
            name: fileName,
            content: secretData[fileName], // Fallback to original if decode fails
          })
        }
      })

      return configObj
    } catch (e) {
      console.error('Error fetching secret:', e)
      return [{ name: '', content: '' }]
    }
  }

  function onSelectedSecretChange(index) {
    const secretData = getValue(discriminator, 'createSecret/data') || []
    const selfSecrets = secretData.map((item) => item.key)

    const remainingSecrets = configSecretKeys.filter((item) => !selfSecrets.includes(item))

    const selfKey = getValue(discriminator, `createSecret/data/${index}/key`)
    if (selfKey) {
      remainingSecrets.push(selfKey)
    }
    const resSecret = remainingSecrets.map((item) => {
      return { text: item, value: item }
    })
    return resSecret
  }

  function ifReconfigurationTypeEqualsTo(value) {
    const reconfigurationType = getValue(discriminator, '/reconfigurationType')
    // watchDependency('discriminator#/reconfigurationType')

    return reconfigurationType === value
  }

  function hasTlsField() {
    const tls = getDbTls()
    return !!tls
  }

  function initIssuerRefApiGroup() {
    const kind = getValue(model, '/spec/tls/issuerRef/kind')
    // watchDependency('model#/spec/tls/issuerRef/kind')

    if (kind) {
      const apiGroup = getValue(discriminator, '/dbDetails/spec/tls/issuerRef/apiGroup')
      if (apiGroup) return apiGroup
      return 'cert-manager.io'
    } else return undefined
  }

  async function getIssuerRefsName() {
    const owner = storeGet('/route/params/user')
    const cluster = storeGet('/route/params/cluster')
    // watchDependency('model#/spec/tls/issuerRef/kind')
    // watchDependency('model#/metadata/namespace')
    const kind = getValue(model, '/spec/tls/issuerRef/kind')
    const namespace = getValue(model, '/metadata/namespace')

    if (kind === 'Issuer') {
      const url = `/clusters/${owner}/${cluster}/proxy/cert-manager.io/v1/namespaces/${namespace}/issuers`
      return getIssuer(url)
    } else if (kind === 'ClusterIssuer') {
      const url = `/clusters/${owner}/${cluster}/proxy/charts.x-helm.dev/v1alpha1/clusterchartpresets/kubedb-ui-presets`

      let presets = storeGet('/kubedbuiPresets') || {}
      if (!storeGet('/route/params/actions')) {
        try {
          const presetResp = await axios.get(url)
          presets = presetResp.data?.spec?.values?.spec
        } catch (e) {
          console.log(e)
          presets.status = String(e.status)
        }
      }
      let clusterIssuers = presets.admin?.clusterIssuers?.available || []
      if (presets.status === '404') {
        const url = `/clusters/${owner}/${cluster}/proxy/cert-manager.io/v1/clusterissuers`
        return getIssuer(url)
      }
      return clusterIssuers
    } else if (!kind) {
      commit('wizard/model$delete', '/spec/tls/issuerRef/name')
      return []
    }

    async function getIssuer(url) {
      try {
        const resp = await axios.get(url)
        const resources = (resp && resp.data && resp.data.items) || []

        resources.map((item) => {
          const name = (item.metadata && item.metadata.name) || ''
          item.text = name
          item.value = name
          return true
        })
        return resources
      } catch (e) {
        console.log(e)
        return []
      }
    }
  }

  function initTlsOperation() {
    return 'update'
  }

  function onTlsOperationChange() {
    const tlsOperation = getValue(discriminator, '/tlsOperation')
    const rotate = !!getValue(model, '/spec/tls/rotateCertificates')
    const remove = !!getValue(model, '/spec/tls/remove')

    commit('wizard/model$delete', '/spec/tls')

    if (tlsOperation === 'rotate') {
      commit('wizard/model$update', {
        path: '/spec/tls/rotateCertificates',
        value: rotate,
      })
    } else if (tlsOperation === 'remove') {
      commit('wizard/model$update', {
        path: '/spec/tls/remove',
        value: remove,
      })
    }
  }

  function showIssuerRefAndCertificates() {
    const tlsOperation = getValue(discriminator, '/tlsOperation')
    // watchDependency('discriminator#/tlsOperation')
    const verd = tlsOperation !== 'remove' && tlsOperation !== 'rotate'

    return verd
  }

  function isIssuerRefRequired() {
    const hasTls = hasTlsField()
    return hasTls ? false : ''
  }

  function getRequestTypeFromRoute() {
    const isDbloading = isDbDetailsLoading()
    const { query } = route || {}
    const { requestType } = query || {}
    return isDbloading ? '' : requestType || ''
  }

  function isDbDetailsLoading() {
    // watchDependency('discriminator#/dbDetails')
    // watchDependency('model#/spec/databaseRef/name')
    const dbDetails = getValue(discriminator, '/dbDetails')
    const dbName = getValue(model, '/spec/databaseRef/name')

    return !dbDetails || !dbName
  }

  function setValueFromDbDetails(path, commitPath) {
    // watchDependency('discriminator#/dbDetails')

    const retValue = getValue(discriminator, `/dbDetails${path}`)

    if (commitPath && retValue) {
      const tlsOperation = getValue(discriminator, '/tlsOperation')

      if (commitPath.includes('/spec/tls') && tlsOperation !== 'update') return undefined

      commit('wizard/model$update', {
        path: commitPath,
        value: retValue,
        force: true,
      })
    }

    return retValue || undefined
  }

  function getAliasOptions() {
    return ['server', 'client', 'metrics-exporter']
  }

  function isNamespaceDisabled() {
    const { namespace } = route.query || {}
    return !!namespace
  }

  function isDatabaseRefDisabled() {
    const { name } = route.params || {}
    return !!name
  }

  function onDbChange() {
    commit('wizard/model$delete', '/spec/type')
    getDbDetails()
  }

  function setApplyToIfReady() {
    return 'IfReady'
  }

  function isVerticalScaleTopologyRequired(type, mode) {
    // watchDependency(`discriminator#/topologyKey`)
    // watchDependency(`discriminator#/topologyValue`)
    const path = `/spec/verticalScaling/${type}/topology`

    const key = String(getValue(model, `${path}/key`) ?? '').trim()
    const value = String(getValue(model, `${path}/value`) ?? '').trim()

    if (!key && !value) {
      commit('wizard/model$delete', path)
    }
    const missingPair = mode === 'key' ? !key && value : key && !value
    if (missingPair) {
      return mode === 'key'
        ? 'Key is required when Value is provided'
        : 'Value is required when Key is provided'
    }
  }

  function checkVolume(initpath, path) {
    const volume = getValue(discriminator, `/dbDetails${initpath}`)
    const input = getValue(model, path)

    try {
      const sizeInBytes = parseSize(volume)
      const inputSizeInBytes = parseSize(input)

      if (inputSizeInBytes >= sizeInBytes) return
      else return 'Cannot expand to lower volume!'
    } catch (err) {
      return err.message || 'Invalid'
    }
  }

  function parseSize(sizeStr) {
    const units = {
      '': 1,
      K: 1e3,
      M: 1e6,
      G: 1e9,
      T: 1e12,
      P: 1e15,
      E: 1e18,
      Ki: 1024,
      Mi: 1024 ** 2,
      Gi: 1024 ** 3,
      Ti: 1024 ** 4,
      Pi: 1024 ** 5,
      Ei: 1024 ** 6,
    }

    const match = String(sizeStr).match(/^([0-9]+(?:\.[0-9]*)?)\s*([A-Za-z]*)$/)
    if (!match) throw new Error('Invalid size format')

    const value = parseFloat(match[1])
    const unit = match[2]

    if (!(unit in units))
      throw new Error('Unrecognized unit. Available units are K, Ki, M, Mi, G, Gi etc')

    return value * units[unit]
  }

  function fetchAliasOptions() {
    return getAliasOptions ? getAliasOptions() : []
  }

  function disableAlias() {
    return !!(model && model.alias)
  }

  function getLimits() {
    const dbDetails = getValue(discriminator, '/dbDetails')
    let limits = {}
    const containers = dbDetails?.spec?.podTemplate?.spec?.containers || []
    if (containers.length === 0)
      limits = dbDetails?.spec?.podTemplate?.spec?.resources?.requests || {}
    else {
      const kind = dbDetails?.kind
      const resource = containers.filter((ele) => ele.name === kind?.toLowerCase())
      limits = resource[0]?.resources?.requests || {}
    }

    return limits
  }

  function isReplicasValid() {
    const dbDetails = getValue(discriminator, '/dbDetails')
    const currentReplicas = dbDetails?.spec?.replicas
    const newReplicas = getValue(model, '/spec/horizontalScaling/node')

    if (currentReplicas === newReplicas) {
      return 'New replica count must be different from the current replica count.'
    }
    return false
  }

  function isMachineValid() {
    const limits = getLimits()

    const selectedMachine = getValue(discriminator, '/machine')
    const selectedLimits = { cpu: selectedMachine?.cpu, memory: selectedMachine?.memory }

    if (JSON.stringify(limits) === JSON.stringify(selectedLimits)) {
      return 'Resource limits are same as current machine configuration. Please select different resources or machine preset.'
    }
    return false
  }

  return {
    isReplicasValid,
    isMachineValid,
    fetchAliasOptions,
    disableAlias,
    getNamespaces,
    getDbs,
    getDbDetails,
    getDbVersions,
    getVersionInfo,
    isVersionEmpty,
    ifRequestTypeEqualsTo,
    onRequestTypeChange,
    getDbTls,
    getDbType,
    initNamespace,
    initDatabaseRef,
    isRancherManaged,
    showAndInitName,
    showAndInitNamespace,
    showAndInitDatabaseRef,
    showConfigureOpsrequestLabel,
    showAndInitOpsRequestType,
    ifDbTypeEqualsTo,
    getConfigSecrets,
    ifReconfigurationTypeEqualsTo,
    onApplyconfigChange,
    hasTlsField,
    initIssuerRefApiGroup,
    getIssuerRefsName,
    initTlsOperation,
    onTlsOperationChange,
    showIssuerRefAndCertificates,
    isIssuerRefRequired,
    getRequestTypeFromRoute,
    isDbDetailsLoading,
    setValueFromDbDetails,
    getAliasOptions,
    isNamespaceDisabled,
    isDatabaseRefDisabled,
    onDbChange,
    setApplyToIfReady,
    isVerticalScaleTopologyRequired,
    getMachines,
    setMachine,
    onMachineChange,
    checkVolume,
    fetchConfigSecrets,
    getConfigSecretsforAppyConfig,
    createNewConfigSecret,
    decodeError,
    isCreateSecret,
    isNotCreateSecret,
    onCreateSecretChange,
    cancelCreateSecret,
    setApplyConfig,
    onRemoveConfigChange,
    onNewConfigSecretChange,
    onSelectedSecretChange,
    isTlsEnabled,
    getCurrentConfig,
  }
}
