# RestoreSession Editor

[RestoreSession Editor by AppsCode](https://appscode.com) - RestoreSession Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/stashappscodecom-restoresession-editor --version=v0.37.0
$ helm upgrade -i stashappscodecom-restoresession-editor appscode/stashappscodecom-restoresession-editor -n default --create-namespace --version=v0.37.0
```

## Introduction

This chart deploys a RestoreSession Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `stashappscodecom-restoresession-editor`:

```bash
$ helm upgrade -i stashappscodecom-restoresession-editor appscode/stashappscodecom-restoresession-editor -n default --create-namespace --version=v0.37.0
```

The command deploys a RestoreSession Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `stashappscodecom-restoresession-editor`:

```bash
$ helm uninstall stashappscodecom-restoresession-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `stashappscodecom-restoresession-editor` chart and their default values.

|                Parameter                 | Description |                                                                Default                                                                |
|------------------------------------------|-------------|---------------------------------------------------------------------------------------------------------------------------------------|
| metadata.resource.group                  |             | <code>stash.appscode.com</code>                                                                                                       |
| metadata.resource.version                |             | <code>v1beta1</code>                                                                                                                  |
| metadata.resource.name                   |             | <code>restoresessions</code>                                                                                                          |
| metadata.resource.kind                   |             | <code>RestoreSession</code>                                                                                                           |
| metadata.resource.scope                  |             | <code>Namespaced</code>                                                                                                               |
| metadata.release.name                    |             | <code>RELEASE-NAME</code>                                                                                                             |
| metadata.release.namespace               |             | <code>default</code>                                                                                                                  |
| resources.stashAppscodeComRestoreSession |             | <code>{"apiVersion":"stash.appscode.com/v1beta1","kind":"RestoreSession","metadata":{"name":"restore-app","namespace":"demo"}}</code> |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i stashappscodecom-restoresession-editor appscode/stashappscodecom-restoresession-editor -n default --create-namespace --version=v0.37.0 --set metadata.resource.group=stash.appscode.com
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i stashappscodecom-restoresession-editor appscode/stashappscodecom-restoresession-editor -n default --create-namespace --version=v0.37.0 --values values.yaml
```
