# Klusterlet Editor

[Klusterlet Editor by AppsCode](https://appscode.com) - Klusterlet Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/operatoropenclustermanagementio-klusterlet-editor --version=v0.33.0
$ helm upgrade -i operatoropenclustermanagementio-klusterlet-editor appscode/operatoropenclustermanagementio-klusterlet-editor -n default --create-namespace --version=v0.33.0
```

## Introduction

This chart deploys a Klusterlet Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `operatoropenclustermanagementio-klusterlet-editor`:

```bash
$ helm upgrade -i operatoropenclustermanagementio-klusterlet-editor appscode/operatoropenclustermanagementio-klusterlet-editor -n default --create-namespace --version=v0.33.0
```

The command deploys a Klusterlet Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `operatoropenclustermanagementio-klusterlet-editor`:

```bash
$ helm uninstall operatoropenclustermanagementio-klusterlet-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `operatoropenclustermanagementio-klusterlet-editor` chart and their default values.

|     Parameter      | Description |                       Default                       |
|--------------------|-------------|-----------------------------------------------------|
| apiVersion         |             | <code>operator.open-cluster-management.io/v1</code> |
| kind               |             | <code>Klusterlet</code>                             |
| metadata.name      |             | <code>klusterlet</code>                             |
| metadata.namespace |             | <code>""</code>                                     |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i operatoropenclustermanagementio-klusterlet-editor appscode/operatoropenclustermanagementio-klusterlet-editor -n default --create-namespace --version=v0.33.0 --set apiVersion=operator.open-cluster-management.io/v1
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i operatoropenclustermanagementio-klusterlet-editor appscode/operatoropenclustermanagementio-klusterlet-editor -n default --create-namespace --version=v0.33.0 --values values.yaml
```
