# Oracle Editor

[Oracle Editor by AppsCode](https://appscode.com) - Oracle Editor

## TL;DR;

```bash
$ helm repo add appscode https://charts.appscode.com/stable/
$ helm repo update
$ helm search repo appscode/kubedbcom-oracle-editor --version=v0.36.0
$ helm upgrade -i kubedbcom-oracle-editor appscode/kubedbcom-oracle-editor -n default --create-namespace --version=v0.36.0
```

## Introduction

This chart deploys a Oracle Editor on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Prerequisites

- Kubernetes 1.20+

## Installing the Chart

To install/upgrade the chart with the release name `kubedbcom-oracle-editor`:

```bash
$ helm upgrade -i kubedbcom-oracle-editor appscode/kubedbcom-oracle-editor -n default --create-namespace --version=v0.36.0
```

The command deploys a Oracle Editor on the Kubernetes cluster in the default configuration. The [configuration](#configuration) section lists the parameters that can be configured during installation.

> **Tip**: List all releases using `helm list`

## Uninstalling the Chart

To uninstall the `kubedbcom-oracle-editor`:

```bash
$ helm uninstall kubedbcom-oracle-editor -n default
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the `kubedbcom-oracle-editor` chart and their default values.

|                                   Parameter                                   | Description |                                                                 Default                                                                 |
|-------------------------------------------------------------------------------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| form.alert.additionalRuleLabels                                               |             | <code>{}</code>                                                                                                                         |
| form.alert.annotations                                                        |             | <code>{}</code>                                                                                                                         |
| form.alert.enabled                                                            |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.enabled                                            |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.diskAlmostFull.duration                      |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.diskAlmostFull.enabled                       |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.diskAlmostFull.severity                      |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.diskAlmostFull.val                           |             | <code>95</code>                                                                                                                         |
| form.alert.groups.database.rules.diskUsageHigh.duration                       |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.database.rules.diskUsageHigh.enabled                        |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.diskUsageHigh.severity                       |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.database.rules.diskUsageHigh.val                            |             | <code>80</code>                                                                                                                         |
| form.alert.groups.database.rules.oracleInstanceDown.duration                  |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.database.rules.oracleInstanceDown.enabled                   |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.oracleInstanceDown.severity                  |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.oracleRestarted.duration                     |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.database.rules.oracleRestarted.enabled                      |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.oracleRestarted.severity                     |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.database.rules.oracleRestarted.val                          |             | <code>60</code>                                                                                                                         |
| form.alert.groups.database.rules.oracleServiceDown.duration                   |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.database.rules.oracleServiceDown.enabled                    |             | <code>true</code>                                                                                                                       |
| form.alert.groups.database.rules.oracleServiceDown.severity                   |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.opsManager.enabled                                          |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.opsManager.rules.opsRequestFailed.duration                  |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.opsManager.rules.opsRequestFailed.enabled                   |             | <code>true</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestFailed.severity                  |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.duration              |             | <code>0m</code>                                                                                                                         |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.enabled               |             | <code>true</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestOnProgress.severity              |             | <code>info</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.duration |             | <code>30m</code>                                                                                                                        |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.enabled  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.opsManager.rules.opsRequestStatusProgressingToLong.severity |             | <code>critical</code>                                                                                                                   |
| form.alert.groups.provisioner.enabled                                         |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseCritical.duration                 |             | <code>15m</code>                                                                                                                        |
| form.alert.groups.provisioner.rules.appPhaseCritical.enabled                  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseCritical.severity                 |             | <code>warning</code>                                                                                                                    |
| form.alert.groups.provisioner.rules.appPhaseNotReady.duration                 |             | <code>1m</code>                                                                                                                         |
| form.alert.groups.provisioner.rules.appPhaseNotReady.enabled                  |             | <code>true</code>                                                                                                                       |
| form.alert.groups.provisioner.rules.appPhaseNotReady.severity                 |             | <code>critical</code>                                                                                                                   |
| form.alert.labels.release                                                     |             | <code>prometheus</code>                                                                                                                 |
| metadata.resource.group                                                       |             | <code>kubedb.com</code>                                                                                                                 |
| metadata.resource.version                                                     |             | <code>v1alpha2</code>                                                                                                                   |
| metadata.resource.name                                                        |             | <code>oracles</code>                                                                                                                    |
| metadata.resource.kind                                                        |             | <code>Oracle</code>                                                                                                                     |
| metadata.resource.scope                                                       |             | <code>Namespaced</code>                                                                                                                 |
| metadata.release.name                                                         |             | <code>RELEASE-NAME</code>                                                                                                               |
| metadata.release.namespace                                                    |             | <code>default</code>                                                                                                                    |
| resources.autoscalingKubedbComOracleAutoscaler                                |             | <code>{"apiVersion":"autoscaling.kubedb.com/v1alpha1","kind":"OracleAutoscaler","metadata":{"name":"oracle","namespace":"demo"}}</code> |
| resources.catalogAppscodeComOracleBinding                                     |             | <code>{"apiVersion":"catalog.appscode.com/v1alpha1","kind":"OracleBinding","metadata":{"name":"oracle","namespace":"demo"}}</code>      |
| resources.certManagerIoIssuer_ca                                              |             | <code>{"apiVersion":"cert-manager.io/v1","kind":"Issuer","metadata":{"name":"oracle-ca","namespace":"demo"}}</code>                     |
| resources.coreKubestashComBackupBlueprint                                     |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupBlueprint","metadata":{"name":"oracle","namespace":"demo"}}</code>      |
| resources.coreKubestashComBackupConfiguration                                 |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"BackupConfiguration","metadata":{"name":"oracle","namespace":"demo"}}</code>  |
| resources.coreKubestashComRestoreSession                                      |             | <code>{"apiVersion":"core.kubestash.com/v1alpha1","kind":"RestoreSession","metadata":{"name":"oracle","namespace":"demo"}}</code>       |
| resources.kubedbComOracle                                                     |             | <code>{"apiVersion":"kubedb.com/v1alpha2","kind":"Oracle","metadata":{"name":"oracle","namespace":"oracle"}}</code>                     |
| resources.monitoringCoreosComServiceMonitor                                   |             | <code>{"apiVersion":"monitoring.coreos.com/v1","kind":"ServiceMonitor","metadata":{"name":"oracle","namespace":"demo"}}</code>          |
| resources.secret_auth                                                         |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"oracle-auth","namespace":"demo"}}</code>                                   |
| resources.secret_config                                                       |             | <code>{"apiVersion":"v1","kind":"Secret","metadata":{"name":"oracle-config","namespace":"demo"}}</code>                                 |


Specify each parameter using the `--set key=value[,key=value]` argument to `helm upgrade -i`. For example:

```bash
$ helm upgrade -i kubedbcom-oracle-editor appscode/kubedbcom-oracle-editor -n default --create-namespace --version=v0.36.0 --set form.alert.enabled=warning
```

Alternatively, a YAML file that specifies the values for the parameters can be provided while
installing the chart. For example:

```bash
$ helm upgrade -i kubedbcom-oracle-editor appscode/kubedbcom-oracle-editor -n default --create-namespace --version=v0.36.0 --values values.yaml
```
